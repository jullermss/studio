export interface CardIcon {
  url: string;
  position:
    | 'top-left'
    | 'top-right'
    | 'right-top'
    | 'right-bottom'
    | 'bottom-right'
    | 'bottom-left'
    | 'left-bottom'
    | 'left-top';
}
