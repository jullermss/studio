import { TemplateRef } from '@angular/core';
import { CardIcon } from './card-icon.model';
import { NavigationButton } from '../navigation-button/navigation-button.model';
import { CardImage } from './card-image.model';

export interface Card {
  header: string;
  underlinedHeader?: boolean;
  subHeader?: string;
  description?: string;
  template?: TemplateRef<any>;
  icon?: CardIcon;
  name?: string;
  color?: 'yellow' | 'green' | undefined;
  navigationLinks?: NavigationButton[];
  image?: CardImage;
}
