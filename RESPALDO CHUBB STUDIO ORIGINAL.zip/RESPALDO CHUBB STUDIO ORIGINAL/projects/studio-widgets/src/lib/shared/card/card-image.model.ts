export interface CardImage {
  url: string;
  position: 'top' | 'right' | 'bottom' | 'left';
}
