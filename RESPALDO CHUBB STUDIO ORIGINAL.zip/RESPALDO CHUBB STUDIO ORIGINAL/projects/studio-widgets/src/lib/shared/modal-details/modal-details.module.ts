import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ModalDetailComponent } from './modal-detail.component';
import { MatExpansionModule, MatFormFieldModule } from '@angular/material';

@NgModule({
  declarations: [ModalDetailComponent],
  exports: [ModalDetailComponent],
  imports: [CommonModule, MatExpansionModule, MatFormFieldModule],
  entryComponents: [ModalDetailComponent],
})
export class ModalDetailsModule {}
