import { Component, Input, OnInit } from '@angular/core';
import { ISelectedPlanModel } from '../../../../../../src/app/models/selected-plan';
import { ICoverageIcon } from '../../../../../../src/app/models/coverage-icon.model';

@Component({
  selector: 'csw-studio-modal-detail',
  templateUrl: './modal-detail.component.html',
  styleUrls: ['./modal-detail.component.scss'],
})
export class ModalDetailComponent implements OnInit {
  @Input() planDetails: ISelectedPlanModel;
  @Input() covers_details: any;
  @Input() detalle_header: string;
  @Input() coverage_icons: ICoverageIcon[];
  showCov = false;
  panelOpenState = false;
  constructor() {}

  ngOnInit() {}

  showCoverages() {
    this.showCov = !this.showCov ? true : false;
  }
  _getCoverageIcon(coveage_name: string) {
    let icon = this.coverage_icons[this.coverage_icons.length - 1].icon;
    for (const coverage_icon of this.coverage_icons) {
      if (coveage_name === coverage_icon.name) {
        icon = coverage_icon.icon;
      }
    }
    return icon;
  }
  async dismiss() {
    // using the injected ModalController this page
    // can "dismiss" itself and optionally pass back data
    /*await this.modalCtrl.dismiss({
      dismissed: true,
    });*/
  }
}
