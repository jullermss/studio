import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ModalEsitefComponent } from './modal-esitef.component';
import { ModalDetailsModule } from '../modal-details/modal-details.module';
import { PipesModule } from '../../../../../../src/app/pipes/pipes.module';

@NgModule({
  declarations: [ModalEsitefComponent],
  exports: [ModalEsitefComponent],
  imports: [CommonModule, ModalDetailsModule, PipesModule],
  entryComponents: [ModalEsitefComponent],
})
export class ModalEsitefModule {}
