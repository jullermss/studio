import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

import { ModalCoveragesComponent } from '../modal-coverages/modal-coverages.component';
import { ModalDetailComponent } from '../modal-details/modal-detail.component';
import { ISelectedPlanModel } from '../../../../../../src/app/models/selected-plan';
import { ICoverageIcon } from '../../../../../../src/app/models/coverage-icon.model';
import { IPolicyModel } from '../../../../../../src/app/models/policy.model';

@Component({
  selector: 'csw-studio-modal-esitef',
  templateUrl: './modal-esitef.component.html',
  styleUrls: ['./modal-esitef.component.scss'],
})
export class ModalEsitefComponent implements OnInit {
  esitef_url: string;
  @Input() back_arrow_svg: string;
  @Input() header_text: string;
  @Input() link_detalle_text: string;
  @Input() planDetails: ISelectedPlanModel;
  @Input() policy: IPolicyModel;
  @Input() frequency: string;
  @Input() detalle_header: string;
  @Input() coverage_icons: ICoverageIcon[];
  @Input() covers_details: any;
  @Output() modalPaymentEmitter = new EventEmitter<string>();

  constructor() {}

  async dismiss(event: string) {
    // using the injected ModalController this page
    // can "dismiss" itself and optionally pass back data
    /*await this.modalCtrl.dismiss({
      dismissed: true,
      event: event,
    });*/
  }
  async showDetailsModal() {
    /*const modal = await this.modalCtrl.create({
      component: ModalDetailComponent,
      cssClass: 'modal-details',
      componentProps: {
        planDetails: this.planDetails,
        covers_details: this.covers_details,
        detalle_header: this.detalle_header,
        coverage_icons: this.coverage_icons,
      },
    });
    return await modal.present();*/

  }
  ngOnInit() {}

  onLoadIframe() {
    setTimeout(() => {
      this.modalPaymentEmitter.emit('HIDE_LOADING');
    }, 2000);
  }
}
