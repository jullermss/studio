import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';

import { ISelectedPlanModel } from '../../../../../../src/app/models/selected-plan';
import { ICoverageIcon } from '../../../../../../src/app/models/coverage-icon.model';

@Component({
  selector: 'csw-studio-modal-coverages',
  templateUrl: './modal-coverages.component.html',
  styleUrls: ['./modal-coverages.component.scss'],
})
export class ModalCoveragesComponent implements OnInit {
  @Input() planDetails: ISelectedPlanModel;
  @Input() indexSelected: number;
  @Input() coverage_icons: ICoverageIcon[];
  slideOpts = null;
  constructor() {}
  ngOnInit() {
    this.slideOpts = {
      initialSlide: this.indexSelected,
      speed: 400,
      slidesPerView: 1.2,
      spaceBetween: 0.5,
      centeredSlides: true,
    };
  }

  async dismiss() {
    // using the injected ModalController this page
    // can "dismiss" itself and optionally pass back data
    /*await this.modalCtrl.dismiss({
      dismissed: true,
    });*/
  }
  // Get the screen width responsive subject
  _getWidthScreen() {
    return `${window.screen.width}px`;
  }

  _getCoverageIcon(coveage_name: string) {
    let icon = this.coverage_icons[this.coverage_icons.length - 1].icon;
    for (const coverage_icon of this.coverage_icons) {
      if (coveage_name === coverage_icon.name) {
        icon = coverage_icon.icon;
      }
    }
    return icon;
  }
}
