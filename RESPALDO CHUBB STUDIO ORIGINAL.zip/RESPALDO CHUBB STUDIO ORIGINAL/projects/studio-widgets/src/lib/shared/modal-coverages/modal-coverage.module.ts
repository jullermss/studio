import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ModalCoveragesComponent } from './modal-coverages.component';
import { PlanDetailsWidgetComponent } from '../../widgets/plan-details-widget/plan-details-widget.component';


@NgModule({
  declarations: [ModalCoveragesComponent],
  exports: [ModalCoveragesComponent],
  imports: [CommonModule],
  entryComponents: [ModalCoveragesComponent],
})
export class ModalCoverageModule {}
