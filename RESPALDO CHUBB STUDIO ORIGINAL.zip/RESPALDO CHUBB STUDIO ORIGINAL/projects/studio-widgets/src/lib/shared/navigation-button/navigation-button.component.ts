import {
  Component,
  Inject,
  Input,
  OnInit,
  ViewEncapsulation,
} from '@angular/core';
import { Router } from '@angular/router';
import { AnalyticsService } from '@crux/services';
import { STUDIO_BASE_HREF } from '@studio/constants/studio-base-href';

@Component({
  selector: 'csw-navigation-button',
  templateUrl: './navigation-button.component.html',
  styleUrls: ['./navigation-button.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class NavigationButtonComponent implements OnInit {
  @Input() text: string;

  // ToDo: need to be route or function or url + target (self, blank, etc)
  @Input() routeOrFunction: any;

  @Input() analyticsEvent: any;

  @Input() color: 'purple' | string;

  constructor(
    private _router: Router,
    private _analytics: AnalyticsService,
    @Inject(STUDIO_BASE_HREF) private _baseHref
  ) {}

  ngOnInit() {}

  click(e: Event) {
    if (this.analyticsEvent) {
      this._analytics.eventTrack.next(this.analyticsEvent);
    }

    if (this.routeOrFunction) {
      if (typeof this.routeOrFunction === 'function') {
        this.routeOrFunction();
      } else {
        this._router.navigate([this._baseHref + '/' + this.routeOrFunction]);
      }
    }
  }

  getColorModification(color: string): string {
    return color ? `navigation-button--${color}` : '';
  }
}
