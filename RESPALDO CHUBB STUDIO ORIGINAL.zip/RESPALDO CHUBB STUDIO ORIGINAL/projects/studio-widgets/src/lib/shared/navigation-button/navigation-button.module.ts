import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavigationButtonComponent } from './navigation-button.component';
import { IconModule } from '@crux/components';

@NgModule({
  imports: [CommonModule, IconModule],
  exports: [NavigationButtonComponent],
  declarations: [NavigationButtonComponent],
})
export class NavigationButtonModule {}
