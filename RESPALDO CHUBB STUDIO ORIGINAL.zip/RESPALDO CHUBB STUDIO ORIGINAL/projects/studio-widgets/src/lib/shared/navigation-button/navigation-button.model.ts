export interface NavigationButton {
  text: string;
  route: string;
  analyticsEvent?: any;
}
