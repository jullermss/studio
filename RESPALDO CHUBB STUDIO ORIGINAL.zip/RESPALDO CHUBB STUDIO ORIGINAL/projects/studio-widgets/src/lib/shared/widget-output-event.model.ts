export interface WidgetOutputEvent {
  type: string;
  payload: any;
}
