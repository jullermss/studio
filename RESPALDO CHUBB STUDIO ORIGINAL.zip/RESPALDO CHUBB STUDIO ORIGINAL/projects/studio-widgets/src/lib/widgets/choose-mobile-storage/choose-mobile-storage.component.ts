import {
  Component,
  EventEmitter,
  Input,
  OnDestroy,
  OnInit,
  Output,
} from '@angular/core';
import { Observable } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { componentDestroyed } from '@crux/components';
import { WidgetOutputEvent } from '../../shared/widget-output-event.model';
import { IQuoteModel } from '../../../../../../src/app/models/quote.model';
import {
  ICurrentError,
  IErrorCustom,
} from '../../../../../../src/app/models/error.model';
import { Store } from '@ngrx/store';
import { StudioState } from '../../../../../../src/app/state/intial-state';
import {
  LoadingIndicatorHideAction,
  LoadingIndicatorShowAction,
} from '../../../../../../src/app/state/actions';

@Component({
  selector: 'csw-choose-mobile-storage',
  templateUrl: './choose-mobile-storage.component.html',
  styleUrls: ['./choose-mobile-storage.component.scss'],
})
export class ChooseMobileStorageComponent implements OnInit, OnDestroy {
  quote: IQuoteModel;

  @Input() title: string;
  @Input() previous_widget: string;
  @Input() phone_image: string;
  @Input() back_arrow_svg: string;
  @Input() quote$: Observable<any>;
  @Input() error_widget: string;
  @Output() output = new EventEmitter<WidgetOutputEvent>();

  slideOpts = {
    initialSlide: 1,
    speed: 400,
    slidesPerView: 3.9,
    spaceBetween: 0.3,
    centeredSlides: true,
  };

  constructor(private _store: Store<StudioState>) {}

  ngOnInit() {
    this.quote$
      .pipe(takeUntil(componentDestroyed(this)))
      .subscribe((response: IQuoteModel) => {
        if (response.make !== 'unknown') {
          this.quote = response;
        }
      });
  }

  ngOnDestroy(): void {}

  _handleStorageSelection(storage: string): void {
    if (storage === 'OTRA') {
      const errorObject: ICurrentError = {
        code: '004',
      };
      this.output.emit({
        type: 'GO_ERROR',
        payload: {
          errorObject: errorObject,
        },
      });
    } else {
      console.log('selecting storage jose', storage);
      this.output.emit({
        type: 'UPDATE_CHOSEN_STORAGE',
        payload: {
          chosenStorage: storage,
        },
      });
    }
  }

  _goBack(): void {
    this.output.emit({
      type: 'GO_BACK',
      payload: {
        previousWidget: this.previous_widget,
      },
    });
  }

  _getWidthScreen() {
    return `${window.screen.width}px`;
  }
}
