import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ChooseMobileStorageComponent } from './choose-mobile-storage.component';

import { FlexLayoutModule } from '@angular/flex-layout';
@NgModule({
  imports: [CommonModule, FlexLayoutModule],
  declarations: [ChooseMobileStorageComponent],
  bootstrap: [ChooseMobileStorageComponent],
})
export class ChooseMobileStorageModule {
  static rootComponent = ChooseMobileStorageComponent;
}
