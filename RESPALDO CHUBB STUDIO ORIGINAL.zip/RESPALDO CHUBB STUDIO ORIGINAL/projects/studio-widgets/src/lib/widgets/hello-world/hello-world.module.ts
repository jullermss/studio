import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HelloWorldComponent } from './hello-world.component';
import { CardModule } from '../../shared/card/card.module';

@NgModule({
  imports: [CommonModule, CardModule],
  declarations: [HelloWorldComponent],
  bootstrap: [HelloWorldComponent],
})
export class HelloWorldModule {
  static rootComponent = HelloWorldComponent;
}
