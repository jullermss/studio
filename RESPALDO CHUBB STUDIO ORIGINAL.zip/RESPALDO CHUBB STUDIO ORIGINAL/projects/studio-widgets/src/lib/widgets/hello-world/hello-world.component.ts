import { Component, Input, ViewEncapsulation } from '@angular/core';
import { NavigationButton } from '../../shared/navigation-button/navigation-button.model';
import { CardIcon } from '../../shared/card/card-icon.model';
import { Observable } from 'rxjs';

@Component({
  selector: 'csw-hello-world-widget',
  templateUrl: './hello-world.component.html',
  styleUrls: ['./hello-world.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class HelloWorldComponent {
  @Input() noAppsText: string;

  @Input() title: string;

  @Input() icon: CardIcon;

  @Input() apps$: Observable<any>;

  constructor() {}
}
