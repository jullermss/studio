import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule,FormsModule } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import {  
          MatInputModule,
          MatRadioModule, 
          MatButtonModule, 
          MatDatepickerModule, 
          MatNativeDateModule,
          MatSelectModule 
        } from '@angular/material';
import { OnlyLettersDirective } from './only-letters.directive';

import { PersonInfoWidgetComponent } from './person-info-widget.component';

@NgModule({
  imports: [
    CommonModule,
    MatInputModule,
    MatButtonModule,
    MatDatepickerModule,
    MatNativeDateModule,
    ReactiveFormsModule,
    FlexLayoutModule,
    MatRadioModule,
    MatSelectModule,
    FormsModule
  ],
  declarations: [OnlyLettersDirective, PersonInfoWidgetComponent],
  bootstrap: [PersonInfoWidgetComponent],
})
export class PersonInfoWidgetModule {
  static rootComponent = PersonInfoWidgetComponent;
}
