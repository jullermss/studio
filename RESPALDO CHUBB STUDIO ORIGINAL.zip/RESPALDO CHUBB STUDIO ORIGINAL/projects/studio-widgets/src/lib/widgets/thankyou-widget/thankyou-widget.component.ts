import {
  Component,
  Input,
  OnInit,
  OnDestroy,
  Output,
  EventEmitter,
} from '@angular/core';
import { componentDestroyed } from '@crux/components';
import { WidgetOutputEvent } from '../../shared/widget-output-event.model';
import { Observable } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { thankYouHero } from '../../../../../../src/app/models/thank-you/thank-you-hero.model';

@Component({
  selector: 'csw-thankyou-widget',
  templateUrl: './thankyou-widget.component.html',
  styleUrls: ['./thankyou-widget.component.scss'],
})
export class ThankYouWidgetComponent implements OnInit, OnDestroy {
  
  @Input() title: string;
  @Input() subtitle: string;
  @Input() sendEmailText: string;
  @Input() thankYouHero: thankYouHero;

  constructor() {}

  ngOnInit() {}

  ngOnDestroy(): void {}
}
