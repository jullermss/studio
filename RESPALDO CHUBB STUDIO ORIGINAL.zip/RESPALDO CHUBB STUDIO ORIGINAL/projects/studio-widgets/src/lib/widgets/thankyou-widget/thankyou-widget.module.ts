import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ThankYouWidgetComponent } from './thankyou-widget.component';
import { FlexLayoutModule } from '@angular/flex-layout';

@NgModule({
  imports: [CommonModule, FlexLayoutModule],
  declarations: [ThankYouWidgetComponent],
  bootstrap: [ThankYouWidgetComponent],
})
export class ThankYouWidgetModule {
  static rootComponent = ThankYouWidgetComponent;
}
