import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddStudioAppsComponent } from './add-studio-apps.component';
import { CardModule } from '../../shared/card/card.module';
import { ButtonModule, FormBuilderModule } from '@crux/components';
import { ReactiveFormsModule } from '@angular/forms';
import { ModalCoverageModule } from '../../shared/modal-coverages/modal-coverage.module';
import { ModalEsitefModule } from '../../shared/modal-esitef/modal-esitef.module';
import { ModalDetailComponent } from '../../shared/modal-details/modal-detail.component';
import { ModalDetailsModule } from '../../shared/modal-details/modal-details.module';

@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    ButtonModule,
    CardModule,
    FormBuilderModule,
    ModalCoverageModule,
    ModalEsitefModule,
    ModalDetailsModule,
  ],
  declarations: [AddStudioAppsComponent],
  bootstrap: [AddStudioAppsComponent],
})
export class AddStudioAppsModule {
  static rootComponent = AddStudioAppsComponent;
}
