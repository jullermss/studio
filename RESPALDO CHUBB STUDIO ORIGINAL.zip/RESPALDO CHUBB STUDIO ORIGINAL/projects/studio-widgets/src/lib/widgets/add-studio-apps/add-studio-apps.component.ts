import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ViewEncapsulation,
} from '@angular/core';
import { Observable, Subject } from 'rxjs';
import {
  FormBuilderConfig,
  FormBuilderInputControl,
  FormBuilderTooltip,
} from '@crux/components';
import { FormGroup } from '@angular/forms';
import { CardIcon } from '../../shared/card/card-icon.model';

@Component({
  selector: 'csw-add-studio-apps-widget',
  templateUrl: './add-studio-apps.component.html',
  styleUrls: ['./add-studio-apps.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class AddStudioAppsComponent implements OnInit {
  @Input() title: string;

  @Input() icon: CardIcon;

  @Output() output = new EventEmitter();

  addStudioAppFormConfig: FormBuilderConfig;

  formGroup = new FormGroup({});

  submit$: Subject<boolean> = new Subject<boolean>();

  formSubmit(formGroup: FormGroup): void {
    this.output.emit({
      type: 'ADD_NEW_STUDIO_APP',
      payload: formGroup.value,
    });
  }

  formSubmitTrigger(): void {
    this.submit$.next(null);
  }

  constructor() {}

  ngOnInit() {
    this.addStudioAppFormConfig = {
      controls: [
        {
          key: 'name',
          name: 'name',
          type: 'input',
          label: 'App Name',
          placeholder: 'Enter your App Name',
          required: true,
          layout: 'column',
          validationMessages: {
            required: 'App Name is required',
          },
          options: <FormBuilderInputControl>{
            type: 'text',
          },
        },
      ],
    };
  }
}
