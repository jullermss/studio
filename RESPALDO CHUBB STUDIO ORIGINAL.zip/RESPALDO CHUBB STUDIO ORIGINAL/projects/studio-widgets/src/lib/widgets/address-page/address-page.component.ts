import {
  Component,
  EventEmitter,
  Input,
  OnDestroy,
  OnInit,
  Output,
} from '@angular/core';
import { WidgetOutputEvent } from '../../shared/widget-output-event.model';
import {
  FormBuilder,
  FormGroup,
  Validators,
  AbstractControl,
} from '@angular/forms';
import {
  IPersonModel,
  PersonModel,
} from '../../../../../../src/app/models/person.model';
import { IAddressForm } from '../../../../../../src/app/models/address-form.model';
import { ValidatorService } from '../../../../../../src/app/services/validator.service';
import {
  AddressBrazil,
  IAddressBrazil,
} from '../../../../../../src/app/models/address-brasil.model';
import { AddressService } from '../../../../../../src/app/services/address.service';
import { map, takeUntil } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { ISelectedPlanModel } from '../../../../../../src/app/models/selected-plan';
import { componentDestroyed } from '@crux/components';
import { PolicyModel } from '../../../../../../src/app/models/policy.model';

@Component({
  selector: 'csw-studio-address-page',
  templateUrl: './address-page.component.html',
  styleUrls: ['./address-page.component.scss'],
})
export class AddressPageComponent implements OnInit, OnDestroy {
  @Input() title: string;
  @Input() subtitle: string;
  @Input() back_arrow_svg: string;
  @Input() previous_widget;
  @Input() next_widget;
  @Input() FormFields: IAddressForm;

  planDetails: ISelectedPlanModel;
  @Input() planSelected$: Observable<ISelectedPlanModel>;
  policy: PolicyModel;
  @Input() policy$: Observable<PolicyModel>;
  @Output() output = new EventEmitter<WidgetOutputEvent>();
  firtsLineAddress = '';
  secondLineAddress = '';
  numberAddress = '';
  complementAddress = '';
  city = '';
  state = '';
  neighborhood = '';
  country = '';
  addressForm: FormGroup;
  submitted = false;
  constructor(
    private fb: FormBuilder,
    private validatorService: ValidatorService,
    private addressService: AddressService
  ) {}

  ngOnInit() {
    this.policy$
      .pipe(takeUntil(componentDestroyed(this)))
      .subscribe((response: PolicyModel) => {
        this.policy = response;
      });
    this.addressForm = this.fb.group({
      cpf: [
        '',
        Validators.compose([Validators.required, this.validatorService.cpfBR]),
      ],
      cep: ['', Validators.required],
      number: ['', Validators.required],
      complement: '',
    });
    this.addressForm.get('cep').setAsyncValidators(this.validateCep.bind(this));
    this.planSelected$
      .pipe(takeUntil(componentDestroyed(this)))
      .subscribe((response: ISelectedPlanModel) => {
        this.planDetails = response;
      });
    this.refillFields();
  }

  get cpfInput() {
    return this.addressForm.get('cpf');
  }
  get cepInput() {
    return this.addressForm.get('cep');
  }
  get numberInput() {
    return this.addressForm.get('number');
  }
  validateCep(control: AbstractControl) {
    return this.addressService.getAddressByCep(control.value).pipe(
      map((address: IAddressBrazil) => {
        console.log(address);
        this.fillAddress(address);
        return address ? null : { cep: true };
      })
    );
  }
  private fillAddress(address?: IAddressBrazil) {
    this.firtsLineAddress = '';
    this.secondLineAddress = '';
    this.firtsLineAddress = address ? address.addressLine1 + ', ' : '';
    this.secondLineAddress += address ? address.city + ', ' : '';
    this.secondLineAddress += address ? address.state + ', ' : '';
    this.secondLineAddress += address ? address.neighborhood + ', ' : '';
    this.secondLineAddress += address ? address.zipCode : '';
    this.state = address ? address.state : '';
    this.city = address ? address.city : '';
    this.neighborhood = address ? address.neighborhood : '';
  }
  private addNumberAddress() {
    this.numberAddress = this.addressForm.get('number').value + '  ';
  }
  private addComplementAddress() {
    this.complementAddress = this.addressForm.get('complement').value + ' ';
  }
  onSubmit() {
    console.log('submitted');
  }

  refillFields() {
    if (this.policy.personInfo.uniqueIdentifier !== '') {
      this.addressForm
        .get('cpf')
        .setValue(this.policy.personInfo.uniqueIdentifier);
    }
    if (this.policy.personInfo.address.zipCode !== '') {
      this.addressForm
        .get('cep')
        .setValue(this.policy.personInfo.address.zipCode);
    }
    if (this.policy.personInfo.address.complement !== '') {
      this.addressForm
        .get('complement')
        .setValue(this.policy.personInfo.address.complement);
      this.complementAddress = this.policy.personInfo.address.complement + ' ';
    }
    if (this.policy.personInfo.address.addressLine1 !== '') {
      this.firtsLineAddress = this.policy.personInfo.address.addressLine1;
    }
    if (this.policy.personInfo.address.addressLine2 !== '') {
      this.secondLineAddress = this.policy.personInfo.address.addressLine2;
    }
    if (this.policy.personInfo.address.number !== '') {
      this.addressForm
        .get('number')
        .setValue(this.policy.personInfo.address.number);
      this.numberAddress = this.policy.personInfo.address.number + '';
    }
  }

  ngOnDestroy(): void {}
  _goBack(): void {
    console.log('going-back from widget');
    this.output.emit({
      type: 'GO_BACK',
      payload: {
        previousWidget: this.previous_widget,
      },
    });
  }
  _goNext(): void {
    this.output.emit({
      type: 'GO_NEXT',
      payload: {
        nextWidget: this.next_widget,
        policyObject: new PolicyModel(
          this.planDetails.quoteId,
          this.planDetails.storageValue + this.planDetails.storageMeasurement,
          new PersonModel({
            firstName: this.policy.personInfo.firstName,
            lastName: this.policy.personInfo.lastName,
            phone: this.policy.personInfo.phone,
            email: this.policy.personInfo.email,
            dateOfBirth: this.policy.personInfo.dateOfBirth,
            uniqueIdentifier: this.addressForm.get('cpf').value,
            address: new AddressBrazil({
              addressLine1: this.firtsLineAddress,
              addressLine2: this.secondLineAddress,
              zipCode: this.addressForm.get('cep').value,
              complement: this.addressForm.get('complement').value,
              number: this.addressForm.get('number').value,
              city: this.city,
              state: this.state,
              neighborhood: this.neighborhood,
              country: 'BR',
            }),
          })
        ),
      },
    });
  }
}
