import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddressPageComponent } from './address-page.component';
import { ExtendedModule } from '@angular/flex-layout';
import {
  MatButtonModule,
  MatIconModule,
  MatInputModule,
  MatTooltipModule,
} from '@angular/material';
import { ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [AddressPageComponent],
  bootstrap: [AddressPageComponent],
  imports: [
    CommonModule,
    ExtendedModule,
    MatIconModule,
    MatButtonModule,
    MatInputModule,
    MatTooltipModule,
    ReactiveFormsModule,
  ],
})
export class AddressPageModule {
  static rootComponent = AddressPageComponent;
}
