import {
  Component,
  EventEmitter,
  Input,
  OnDestroy,
  OnInit,
  Output,
} from '@angular/core';
import { WidgetOutputEvent } from '../../shared/widget-output-event.model';
import {
  Form,
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { PolicyModel } from '../../../../../../src/app/models/policy.model';
import { Observable } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { componentDestroyed } from '@crux/components';
import { ILoginForm } from '../../../../../../src/app/models/login-form.model';

@Component({
  selector: 'csw-studio-sign-up-page',
  templateUrl: './sign-up-page.component.html',
  styleUrls: ['./sign-up-page.component.scss'],
})
export class SignUpPageComponent implements OnInit, OnDestroy {
  @Input() title: string;
  @Input() back_arrow_svg: string;
  @Input() previous_widget: string;
  @Input() FormFields: ILoginForm;
  @Input() next_widget;
  @Output() output = new EventEmitter<WidgetOutputEvent>();
  hidepass = true;
  hiderepass = true;
  password_done = true;
  policy: PolicyModel;
  @Input() policy$: Observable<PolicyModel>;
  signUpForm: FormGroup;
  constructor(private fb: FormBuilder) {}
  ngOnInit() {
    this.policy$
      .pipe(takeUntil(componentDestroyed(this)))
      .subscribe((response: PolicyModel) => {
        this.policy = response;
      });
    this.signUpForm = this.fb.group(
      {
        email: ['', [Validators.required, Validators.email]],
        pass: [
          '',
          Validators.compose([
            Validators.required,
            Validators.pattern(
              '(?=\\D*\\d)(?=.*[@#$%*&])(?=[^a-z]*[a-z])(?=[^A-Z]*[A-Z]).{8,30}'
            ),
          ]),
        ],
        repass: ['', Validators.required],
      },
      {
        validator: this.MustMatch('pass', 'repass'),
      }
    );
    this.signUpForm.get('email').setValue(this.policy.personInfo.email);
  }
  ngOnDestroy(): void {}
  _goBack(): void {
    console.log('going-back from widget');
    this.output.emit({
      type: 'GO_BACK',
      payload: {
        previousWidget: this.previous_widget,
      },
    });
  }
  _goNext(): void {
    this.output.emit({
      type: 'GO_NEXT',
      payload: {
        nextWidget: this.next_widget,
      },
    });
  }

  get passInput() {
    return this.signUpForm.get('pass');
  }

  get hasNumber() {
    return /\d/.test(this.signUpForm.get('pass').value);
  }
  get hasUpper() {
    return /[A-Z]/.test(this.signUpForm.get('pass').value);
  }
  get hasSpecial() {
    return /[@#$%*.]/.test(this.signUpForm.get('pass').value);
  }
  get hasLength() {
    return this.signUpForm.get('pass').value.length >= 8;
  }

  get repassInput() {
    return this.signUpForm.get('repass');
  }
  getPasswordErrorMessage() {
    return this.signUpForm.get('pass').errors.required
      ? this.FormFields.pass.requiredText
      : this.signUpForm.get('pass').errors.pattern
        ? this.FormFields.pass.invalidText
        : '';
  }

  getRePasswordErrorMessage() {
    return this.signUpForm.get('repass').errors.required
      ? this.FormFields.repass.requiredText
      : this.signUpForm.get('repass').value !==
        this.signUpForm.get('pass').value
        ? this.FormFields.repass.passwordNoMatch
        : '';
  }

  MustMatch(controlName: string, matchingControlName: string) {
    return (formGroup: FormGroup) => {
      const control = formGroup.controls[controlName];
      const matchingControl = formGroup.controls[matchingControlName];

      if (matchingControl.errors && !matchingControl.errors.mustMatch) {
        // return if another validator has already found an error on the matchingControl
        return;
      }

      // set error on matchingControl if validation fails
      if (control.value !== matchingControl.value) {
        matchingControl.setErrors({ mustMatch: true });
      } else {
        matchingControl.setErrors(null);
      }
    };
  }
}
