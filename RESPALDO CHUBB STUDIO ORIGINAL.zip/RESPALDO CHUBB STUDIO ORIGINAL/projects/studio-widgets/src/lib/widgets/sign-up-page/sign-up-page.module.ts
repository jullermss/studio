import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SignUpPageComponent } from './sign-up-page.component';
import { ExtendedModule } from '@angular/flex-layout';
import {
  MatButtonModule,
  MatIconModule,
  MatInputModule,
  MatTooltipModule,
} from '@angular/material';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [SignUpPageComponent],
  bootstrap: [SignUpPageComponent],
  imports: [
    CommonModule,
    ExtendedModule,
    MatIconModule,
    MatButtonModule,
    MatInputModule,
    MatTooltipModule,
    ReactiveFormsModule,
    FormsModule,
  ],
})
export class SignUpPageModule {
  static rootComponent = SignUpPageComponent;
}
