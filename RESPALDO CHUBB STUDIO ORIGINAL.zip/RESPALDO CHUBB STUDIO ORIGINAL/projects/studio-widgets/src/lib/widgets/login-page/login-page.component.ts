import {
  Component,
  OnInit,
  Input,
  OnDestroy,
  Output,
  EventEmitter,
} from '@angular/core';
import { Observable } from 'rxjs';
import { WidgetOutputEvent } from '../../shared/widget-output-event.model';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ILoginForm } from '../../../../../../src/app/models/login-form.model';

@Component({
  selector: 'csw-studio-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.scss'],
})
export class LoginPageComponent implements OnInit, OnDestroy {
  @Input() title: string;
  @Input() back_arrow_svg: string;
  @Input() previous_widget;
  @Output() output = new EventEmitter<WidgetOutputEvent>();
  @Input() button_text: string;
  @Input() welcome_text: string;
  @Input() FormFields: ILoginForm;
  loginForm: FormGroup;
  submitted = false;
  hide = true;

  constructor(private fb: FormBuilder) {}
  ngOnInit() {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      pass: ['', Validators.required],
    });
  }

  get emailInput() {
    return this.loginForm.get('email');
  }
  getEmailErrorMessage() {
    return this.loginForm.get('email').errors.required
      ? this.FormFields.email.requiredText
      : this.loginForm.get('email').errors.email
        ? this.FormFields.email.invalidText
        : '';
  }

  getPasswordErrorMessage() {
    return this.loginForm.get('pass').errors.required
      ? this.FormFields.pass.requiredText
      : '';
  }
  onSubmit() {
    this.submitted = true;
  }

  get passInput() {
    return this.loginForm.get('pass');
  }
  ngOnDestroy(): void {}

  _goBack(): void {
    console.log('going-back from widget');
    this.output.emit({
      type: 'GO_BACK',
      payload: {
        previousWidget: this.previous_widget,
      },
    });
  }
  _handelClickBegin(): void {
    this.output.emit({
      type: 'GO_TO_BEGIN',
      payload: {
        beginRoute: this.FormFields.begin.nextWidget,
      },
    });
  }
}
