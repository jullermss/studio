import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginPageComponent } from './login-page.component';
import { ExtendedModule } from '@angular/flex-layout';
import {ReactiveFormsModule} from '@angular/forms';
import {MatButtonModule, MatIconModule, MatInputModule, MatTooltipModule} from '@angular/material';

@NgModule({
  declarations: [LoginPageComponent],
  bootstrap: [LoginPageComponent],
    imports: [
        CommonModule,
        ExtendedModule,
        MatIconModule,
        MatButtonModule,
        MatInputModule,
        MatTooltipModule,
        ReactiveFormsModule],
})
export class LoginPageModule {
  static rootComponent = LoginPageComponent;
}
