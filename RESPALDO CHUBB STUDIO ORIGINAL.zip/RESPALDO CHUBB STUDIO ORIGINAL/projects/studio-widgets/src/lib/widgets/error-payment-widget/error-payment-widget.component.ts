import {
  Component,
  Input,
  OnInit,
  OnDestroy,
  Output,
  EventEmitter,
} from '@angular/core';
import { componentDestroyed } from '@crux/components';
import { Observable } from 'rxjs';
import { Location } from '@angular/common';


@Component({
  selector: 'csw-error-payment-widget',
  templateUrl: './error-payment-widget.component.html',
  styleUrls: ['./error-payment-widget.component.scss'],
})
export class ErrorPaymentWidgetComponent implements OnInit, OnDestroy {
  
  @Input() title: string;
  @Input() subtitle: string;
  @Input() backBtnText: string;


  constructor(
    private _location: Location
  ) {}

  ngOnInit() {}

  goBack(){
    this._location.back();
  }

  ngOnDestroy(): void {}
}
