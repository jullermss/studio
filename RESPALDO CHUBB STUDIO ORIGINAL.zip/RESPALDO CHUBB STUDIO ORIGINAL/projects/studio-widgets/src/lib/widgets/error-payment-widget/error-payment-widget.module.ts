import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ErrorPaymentWidgetComponent } from './error-payment-widget.component';
import { FlexLayoutModule } from '@angular/flex-layout';

@NgModule({
  imports: [CommonModule, FlexLayoutModule],
  declarations: [ErrorPaymentWidgetComponent],
  bootstrap: [ErrorPaymentWidgetComponent],
})
export class ErrorPaymentWidgetModule {
  static rootComponent = ErrorPaymentWidgetComponent;
}
