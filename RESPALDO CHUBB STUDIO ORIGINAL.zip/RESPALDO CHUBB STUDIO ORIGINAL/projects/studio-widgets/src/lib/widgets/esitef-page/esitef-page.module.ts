import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EsitefPageComponent } from './esitef-page.component';
import { ExtendedModule } from '@angular/flex-layout';
import {
  MatButtonModule,
  MatIconModule,
  MatInputModule,
  MatTooltipModule,
} from '@angular/material';
import { ReactiveFormsModule } from '@angular/forms';
import { ModalEsitefModule } from '../../shared/modal-esitef/modal-esitef.module';
import { ModalEsitefComponent } from '../../shared/modal-esitef/modal-esitef.component';
import { NgxViacepModule } from '@brunoc/ngx-viacep';

@NgModule({
  declarations: [EsitefPageComponent],
  bootstrap: [EsitefPageComponent],
  imports: [
    CommonModule,
    ExtendedModule,
    MatIconModule,
    MatButtonModule,
    MatInputModule,
    MatTooltipModule,
    ReactiveFormsModule,
    ModalEsitefModule,
    NgxViacepModule,
  ],
  entryComponents: [ModalEsitefComponent],
})
export class EsitefPageModule {
  static rootComponent = EsitefPageComponent;
}
