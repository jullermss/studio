import {
  Component,
  OnInit,
  Input,
  OnDestroy,
  Output,
  EventEmitter,
  AfterViewInit,
} from '@angular/core';
import { WidgetOutputEvent } from '../../shared/widget-output-event.model';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ModalEsitefComponent } from '../../shared/modal-esitef/modal-esitef.component';
import { Observable } from 'rxjs';
import { ISelectedPlanModel } from '../../../../../../src/app/models/selected-plan';
import { takeUntil } from 'rxjs/operators';
import { componentDestroyed } from '@crux/components';
import { ICoverageIcon } from '../../../../../../src/app/models/coverage-icon.model';
import { PolicyModel } from '../../../../../../src/app/models/policy.model';

@Component({
  selector: 'csw-studio-esitef-page',
  templateUrl: './esitef-page.component.html',
  styleUrls: ['./esitef-page.component.scss'],
})
export class EsitefPageComponent implements OnInit, OnDestroy, AfterViewInit {
  planDetails: ISelectedPlanModel;
  @Input() title: string;
  @Input() back_arrow_svg: string;
  @Input() previous_widget: string;
  @Input() header_text: string;
  @Input() link_detalle_text: string;
  @Input() detalle_header: string;
  @Input() covers_details: string;
  @Input() coverage_icons: ICoverageIcon[];
  @Input() frequency: string;
  @Input() loadingMsg: string;
  @Output() output = new EventEmitter<WidgetOutputEvent>();
  @Input() planSelected$: Observable<ISelectedPlanModel>;
  policy: PolicyModel;
  @Input() policy$: Observable<PolicyModel>;
  constructor() {}

  ngOnInit() {
    setTimeout(() => {
      this.__showLoading();
    }, 0);
    this.planSelected$
      .pipe(takeUntil(componentDestroyed(this)))
      .subscribe((response: ISelectedPlanModel) => {
        this.planDetails = response;
      });
    this.policy$
      .pipe(takeUntil(componentDestroyed(this)))
      .subscribe((response: PolicyModel) => {
        this.policy = response;
        this.presentModal().then(() => {
          console.log('cargado modal de esitef', this.policy);
        });
      });
  }
  ngAfterViewInit(): void {}
  ngOnDestroy(): void {}

  async presentModal() {
    const modalEmitter = new EventEmitter();
    modalEmitter.subscribe((res) => {
      this.output.emit({
        type: 'HIDE_LOADING',
        payload: null,
      });
    });
    /*const modal = await this.modalController.create({
      component: ModalEsitefComponent,
      showBackdrop: false,
      componentProps: {
        back_arrow_svg: this.back_arrow_svg,
        header_text: this.header_text,
        link_detalle_text: this.link_detalle_text,
        frequency: this.frequency,
        detalle_header: this.detalle_header,
        covers_details: this.covers_details,
        planDetails: this.planDetails,
        policy: this.policy,
        coverage_icons: this.coverage_icons,
        modalPaymentEmitter: modalEmitter,
      },
      animated: false,
      cssClass: 'modal-esitef',
    });
    modal.onDidDismiss().then((data) => {
      switch (data.data['event']) {
        case 'back':
          console.log('going back to the page from payment modal');
          this._goBack();
          break;
        case 'payed':
          console.log('payed OK');
          break;
        default:
          console.log('go to the defualt page defined');
      }
      console.log('Cerrando el modal detalles');
    });
    return await modal.present();*/
  }

  _goBack(): void {
    console.log('going-back from widget');
    this.output.emit({
      type: 'GO_BACK',
      payload: {
        previousWidget: this.previous_widget,
      },
    });
  }
  __showLoading(): void {
    this.output.emit({
      type: 'SHOW_LOADING',
      payload: {
        loadingMsg: this.loadingMsg,
      },
    });
  }
}
