import { NavigationButton } from '../../shared/navigation-button/navigation-button.model';
import { Content } from '../content-header/content-header.model';

export interface ContentNavigation {
  styles?: {
    [key: string]: string;
  };

  title: Content<string>;

  subTitle?: Content<string>;

  links?: Content<NavigationButton>[];
}
