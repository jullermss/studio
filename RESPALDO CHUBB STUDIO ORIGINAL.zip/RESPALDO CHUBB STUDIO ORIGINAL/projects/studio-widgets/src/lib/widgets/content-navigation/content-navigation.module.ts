import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ContentNavigationComponent } from './content-navigation.component';
import { NavigationButtonModule } from '../../shared/navigation-button/navigation-button.module';

@NgModule({
  imports: [CommonModule, NavigationButtonModule],
  declarations: [ContentNavigationComponent],
  bootstrap: [ContentNavigationComponent],
})
export class ContentNavigationModule {
  static rootComponent = ContentNavigationComponent;
}
