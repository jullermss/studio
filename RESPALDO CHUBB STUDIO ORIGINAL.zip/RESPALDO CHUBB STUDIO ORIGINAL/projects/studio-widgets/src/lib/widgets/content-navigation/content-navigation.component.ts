import { Component, Input, ViewEncapsulation } from '@angular/core';
import { NavigationButton } from '../../shared/navigation-button/navigation-button.model';
import { ContentNavigation } from './content-navigation.model';
import { Content } from '../content-header/content-header.model';

@Component({
  selector: 'csw-content-navigation',
  templateUrl: './content-navigation.component.html',
  styleUrls: ['./content-navigation.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class ContentNavigationComponent implements ContentNavigation {
  @Input() links: Content<NavigationButton>[];

  @Input() styles: { [p: string]: string };

  @Input() subTitle: Content<string>;

  @Input() title: Content<string>;

  constructor() {}
}
