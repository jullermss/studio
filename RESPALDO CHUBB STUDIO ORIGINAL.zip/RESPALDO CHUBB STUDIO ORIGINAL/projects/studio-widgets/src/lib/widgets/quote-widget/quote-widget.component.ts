import { Component, ViewEncapsulation, Input } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { QuoteOptionModel } from "../../../../../../src/app/models/quote/quote-option.model";
import { Beneficio } from "../../../../../../src/app/models/quote/beneficio.model";

@Component({
    selector: 'csw-quote-widget',
    templateUrl: './quote-widget.component.html',
    styleUrls: ['./quote-widget.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class QuoteWidgetComponent {
  @Input() quoteOptions: QuoteOptionModel[];
  @Input() beneficios: Beneficio[];

  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;

  displayedColumns: string[] = ['nombre', 'montoOpcion1', 'montoOpcion2'];

  constructor(private _formBuilder: FormBuilder) {}

  ngOnInit() {
    this.firstFormGroup = this._formBuilder.group({
      firstCtrl: ['', Validators.required]
    });
    this.secondFormGroup = this._formBuilder.group({
      secondCtrl: ['', Validators.required]
    });
  }
}