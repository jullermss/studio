import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { QuoteWidgetComponent } from './quote-widget.component';
import { MatStepperModule, MatInputModule, MatFormFieldModule, MatNativeDateModule, MatTableModule,MatSelectModule, MatRadioModule,MatCheckboxModule } from '@angular/material';
import { ReactiveFormsModule } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { BenefitsComponent } from './benefits/benefits.component';
import { QuotePaymentComponent } from './payment/quote-payment.component';
import {PersonInfoComponent} from './details/person-info.component'

@NgModule({
  declarations: [
    QuoteWidgetComponent, 
    BenefitsComponent,
    QuotePaymentComponent,
    PersonInfoComponent
  ],
  imports: [
    CommonModule, 
    MatStepperModule, 
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    FlexLayoutModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatTableModule,
    MatSelectModule,
    MatRadioModule,
    MatCheckboxModule
  ],
  bootstrap: [QuoteWidgetComponent],
  providers: [MatDatepickerModule]
})
export class QuoteWidgetModule {
  static rootComponent = QuoteWidgetComponent;
}
