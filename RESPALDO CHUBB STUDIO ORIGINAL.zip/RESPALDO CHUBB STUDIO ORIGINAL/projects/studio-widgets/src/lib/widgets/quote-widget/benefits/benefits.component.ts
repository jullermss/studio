import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'studio-benefits',
  templateUrl: './benefits.component.html',
  styleUrls: ['./benefits.component.scss']
})
export class BenefitsComponent implements OnInit {

  displayedColumns: string[] = ['nombre', 'montoOpcion1', 'montoOpcion2'];
  quoteOptions: any[];
  beneficios: any[];

  constructor() { 
    this.beneficios = [
      {nombre: 'Robo con violencia', montoOpcion1: 'UF 200', montoOpcion2: 'UF 500'},
      {nombre: 'Robo con violencia', montoOpcion1: 'UF 200', montoOpcion2: 'UF 500'}
    ];
  }

  ngOnInit() {
    this.quoteOptions = [
      {planName: 'dwe', daysOfCoverage: 12, totalAmount: 3232, UFAmount: 433},
      {planName: 'qcrrt', daysOfCoverage: 33, totalAmount: 3356, UFAmount: 222}
    ];
  }

}
