import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule,FormsModule } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import {  
          MatInputModule,
          MatRadioModule, 
          MatButtonModule, 
          MatDatepickerModule, 
          MatNativeDateModule,
          MatSelectModule 
        } from '@angular/material';
import { OnlyLettersDirective } from './only-letters.directive';

import { PersonInfoComponent } from './person-info.component';

@NgModule({
  imports: [
    CommonModule,
    MatInputModule,
    MatButtonModule,
    MatDatepickerModule,
    MatNativeDateModule,
    ReactiveFormsModule,
    FlexLayoutModule,
    MatRadioModule,
    MatSelectModule,
    FormsModule
  ],
  declarations: [OnlyLettersDirective, PersonInfoComponent],
  bootstrap: [PersonInfoComponent],
})
export class PersonInfoModule {
  static rootComponent = PersonInfoComponent;
}
