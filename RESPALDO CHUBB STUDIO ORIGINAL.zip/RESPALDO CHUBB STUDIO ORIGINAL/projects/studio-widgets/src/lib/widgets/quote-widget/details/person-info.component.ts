import {
  Component,
  Input,
  OnInit,
  OnDestroy,
  Output,
  EventEmitter,
} from '@angular/core';
import { componentDestroyed } from '@crux/components';
import { WidgetOutputEvent } from '../../../shared/widget-output-event.model';
import { FormBuilder, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { Observable, timer } from 'rxjs';
import { IPlanModel } from '../../../../../../../src/app/models/plan.model';
import { takeUntil, switchMap, map, switchMapTo } from 'rxjs/operators';
import { IPhoneDetails } from '../../../../../../../src/app/models/phone-details.model';
import { PolicyModel } from '../../../../../../../src/app/models/policy.model';
import { ValidatorService } from '../../../../../../../src/app/services/validator.service';
import { MatRadioChange, MatRadioButton } from '@angular/material';

interface OBJECT_MODEL {
  value: any;
  viewValue: string;
}



@Component({
  selector: 'studio-quote-person-info',
  templateUrl: './person-info.component.html',
  styleUrls: ['./person-info.component.scss'],
})

export class PersonInfoComponent implements OnInit, OnDestroy {
  profileForm: FormGroup;
  selectedPlan: IPlanModel;
  phoneDetails: IPhoneDetails;
  policy: PolicyModel;
  @Input() back_arrow_svg: string;
  @Input() previousWidget: string;
  @Input() nextWidget: string;
  @Input() selectedPlan$: Observable<IPlanModel>;
  @Input() phoneDetails$: Observable<IPhoneDetails>;
  @Input() policy$: Observable<PolicyModel>;
  @Input() nameFieldErrorText: string;
  @Input() phoneFiledErrorText: string;
  @Input() emailFieldErrors: any;
  @Input() dateOfBirthErrorText: string;
  @Input() title: string;
  @Input() subtitle: string;
  @Output() output = new EventEmitter<WidgetOutputEvent>();
  favoriteSeason: string;
  addressConfirmation:Boolean;
  rutConfirmation:Boolean;
  sameInsuredOptions: OBJECT_MODEL[] = [
    {value:true, viewValue:"Si"}, 
    {value:false, viewValue:"No"}
  ];
  regionX: OBJECT_MODEL[] = [
    {value: 'id-1', viewValue: 'Región 1'},
    {value: 'id-2', viewValue: 'Región 2'},
    {value: 'id-3', viewValue: 'Región 3'}
  ];

  ciudadX: OBJECT_MODEL[] = [
    {value: 'id-1', viewValue: 'Ciudad 1'},
    {value: 'id-2', viewValue: 'Ciudad 2'},
    {value: 'id-3', viewValue: 'Ciudad 3'}
  ];

  comunaX: OBJECT_MODEL[] = [
    {value: 'id-1', viewValue: 'Comuna 1'},
    {value: 'id-2', viewValue: 'Comuna 2'},
    {value: 'id-3', viewValue: 'Comuna 3'}
  ];

  constructor(
    private validateService: ValidatorService,
    private fb: FormBuilder) {}

  ngOnInit() {
    //this.getPhoneDetails();
    //this.getSelectedPlan();
    this.addressConfirmation=false;
    this.rutConfirmation=false;

    this.profileForm = this.fb.group(
      {
        rut: ['', Validators.required],
        name: ['', Validators.required],
        firstname: ['', Validators.required],
        lastname: ['', Validators.required],
        email: ['', Validators.required],
        phone:['', Validators.required],
        address:['', Validators.required],
        number:['', Validators.required],
        apartmentNumber:['', Validators.required],
        food:['', Validators.required],
        ciudad:['', Validators.required],
        region:['', Validators.required],
        comuna:['', Validators.required],
        RUT_dateOfBirth:['', Validators.required],
        RUT_name:['', Validators.required],
        RUT_firstname:['', Validators.required],
        RUT_lastname:['', Validators.required],
        RUT_rut:['', Validators.required],

      //   email: ['',
      //   [ Validators.email, Validators.required ],
      //   [ this.checkEmailAvailabilityValidator.bind(this) ]
      // ],
        // repeatEmail: ['', Validators.required],
        // phoneNumber: ['', !this.phoneDetails.phoneNumber && Validators.required],
        dateOfBirth: ['', Validators.required]
      }
      // {
      //   validator: this.mustMatch('email', 'repeatEmail'),
      // }
    );

    //this.getPolicy();
  }

  ngOnDestroy(): void {}

  // _submitProfile() {
  //   this.output.emit({
  //     type: 'SAVE_PERSON_INFO',
  //     payload: this.updatePersonInfoObjectForState(this.profileForm.value)
  //   });
  // }

  _submitBuyerForm(): void{
    console.log(`This is ProfilerForm :${JSON.stringify(this.profileForm.value)} ` );
  }

  execute_validation(e : MatRadioChange):void{
    console.log(e.value);
    console.log(e.source.name);

    console.log(e.source.checked);
    console.log(e.source.inputId);

    switch(e.source.name){
      case 'AddressConfirmation':
        this.addressConfirmation=!e.value;
      break;

      case 'RutConfirmation':
        this.rutConfirmation=!e.value;
    }
   
  }

  //(change)="rut_name_validation($event)"

  // _goBack() {
  //   this.output.emit({
  //     type: 'GO_BACK',
  //     payload: {
  //       previousWidget: this.previousWidget,
  //     },
  //   });
  // }

  // getPhoneDetails(): void {
  //   this.phoneDetails$
  //     .pipe(takeUntil(componentDestroyed(this)))
  //     .subscribe((response: IPhoneDetails) => {
  //       this.phoneDetails = response;
  //     });
  // }

  // getSelectedPlan(): void {
  //   this.selectedPlan$
  //     .pipe(takeUntil(componentDestroyed(this)))
  //     .subscribe((response: IPlanModel) => {
  //       this.selectedPlan = response;
  //     });
  // }

  // getPolicy(): void {
  //   this.policy$
  //     .pipe(takeUntil(componentDestroyed(this)))
  //     .subscribe((response: PolicyModel) => {
  //       this.policy = response;
  //       this.profileForm.patchValue(
  //         this.updatePersonInfoObjectForView(this.policy.personInfo));
  //     });
  // }

  // mustMatch(controlName: string, matchingControlName: string) {
  //   return (formGroup: FormGroup) => {
  //     const control = formGroup.controls[controlName];
  //     const matchingControl = formGroup.controls[matchingControlName];

  //     if (matchingControl.errors && !matchingControl.errors.mustMatch) {
  //       // return if another validator has already found an error on the matchingControl
  //       return;
  //     }

  //     // set error on matchingControl if validation fails
  //     if (control.value !== matchingControl.value) {
  //       matchingControl.setErrors({ mustMatch: true });
  //     } else {
  //       matchingControl.setErrors(null);
  //     }
  //   };
  // }

  updatePersonInfoObjectForState(personInfo) {
    const { name, email, phoneNumber, dateOfBirth } = personInfo;
    const phone = phoneNumber || this.phoneDetails.phoneNumber;
    // Separate firstName and lastName
    let [ firstName, lastName ] = name.trim().split(/\s+/);
    // Remove spaces from both
    firstName = firstName.trim();
    lastName = lastName ? lastName.trim() : '';

    return {
      firstName,
      lastName,
      email,
      phone,
      dateOfBirth: typeof dateOfBirth === 'string' ? dateOfBirth : dateOfBirth.toISOString()
    };
  }

  updatePersonInfoObjectForView(personInfoFromState) {
    const { firstName, lastName, email, phone, dateOfBirth } = personInfoFromState;
    return {
      name: `${firstName} ${lastName}`,
      email,
      repeatEmail: email,
      phoneNumber: phone,
      dateOfBirth
    };
  }

  // checkEmailAvailabilityValidator(control: AbstractControl) {
  //   return timer(500).pipe(
  //     switchMap(() => this.validateService.checkEmailAvailability(control.value)),
  //     map(res => {
  //       return res ? null : { emailExists: true };
  //     })
  //   );
  // }

  get name() {
    return this.profileForm.get('name');
  }


  get email() {
    return this.profileForm.get('email');
  }

  // get repeatEmail() {
  //   return this.profileForm.get('repeatEmail');
  // }

  // get phoneNumber() {
  //   return this.profileForm.get('phoneNumber');
  // }
}
