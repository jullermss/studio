import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'studio-quote-payment',
  templateUrl: './quote-payment.component.html',
  styleUrls: ['./quote-payment.component.scss']
})
export class QuotePaymentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
