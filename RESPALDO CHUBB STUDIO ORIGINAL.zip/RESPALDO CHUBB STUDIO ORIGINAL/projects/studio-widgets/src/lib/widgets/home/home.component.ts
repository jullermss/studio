import { Component, Input, ViewEncapsulation, OnInit, EventEmitter, Output } from '@angular/core';
import { NavigationButton } from '../../shared/navigation-button/navigation-button.model';
import { CardIcon } from '../../shared/card/card-icon.model';
import { Observable } from 'rxjs';
import { homeForm } from '../../../../../../src/app/models/home/home-form.model';
import { homeRibbon } from '../../../../../../src/app/models/home/home-ribbon.model';
import { homeInsurancePhones } from '../../../../../../src/app/models/home/home-insurance-phones.model';
import { homeCoverageRequirement } from '../../../../../../src/app/models/home/home-coverage-requirements.model';
import { WidgetOutputEvent } from '../../../../../../src/app/components/shared/widget/widget-output-event.model';

@Component({
  selector: 'csw-hello-world-widget',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class HomeWidgetComponent implements OnInit{
  @Input() title: string;
  @Input() headerTitle: string;
  @Input() heroSubheader: string;
  @Input() contentSubheader: string;
  @Input() homeForm: homeForm;
  @Input() ribbon: homeRibbon;
  @Input() insurancePhones: homeInsurancePhones;
  @Input() coverages: homeCoverageRequirement;
  @Input() requirements: homeCoverageRequirement;
  @Output() output = new EventEmitter<WidgetOutputEvent>();


  constructor() {}

  
  ngOnInit(){}

  shopNow(){

    this.output.emit({
      type: 'next',
      payload: this.homeForm.compraBtn.nextWidget
    });
    
  }
}
