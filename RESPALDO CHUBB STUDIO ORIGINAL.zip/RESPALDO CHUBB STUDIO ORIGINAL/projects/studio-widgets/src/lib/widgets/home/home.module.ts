import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeWidgetComponent } from './home.component';
import { CardModule } from '../../shared/card/card.module';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MatTabsModule } from '@angular/material';
import { MAT_TABS_CONFIG } from '@angular/material';

@NgModule({
  imports: [CommonModule, CardModule,FlexLayoutModule, MatTabsModule],
  declarations: [HomeWidgetComponent],
  bootstrap: [HomeWidgetComponent],
  
})
export class HomeWidgetModule {
  static rootComponent = HomeWidgetComponent;
}
