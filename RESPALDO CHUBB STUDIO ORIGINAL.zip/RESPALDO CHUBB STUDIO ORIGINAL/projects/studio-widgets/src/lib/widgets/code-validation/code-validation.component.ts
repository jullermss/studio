import {
  Component,
  Input,
  OnDestroy,
  OnInit,
  Output,
  EventEmitter,
} from '@angular/core';
import { Observable } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { componentDestroyed } from '@crux/components';
import { WidgetOutputEvent } from '../../shared/widget-output-event.model';
import { FormBuilder, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { IAuthModel } from '../../../../../../src/app/models/auth.model';

import { PopoverComponent } from '../../shared/popover/popover.component';
import { IPhoneDetails } from '../../../../../../src/app/models/phone-details.model';
import { IImeiStep } from '../../../../../../src/app/models/imei-step.model';
import { IErrorInputMsg } from '../../../../../../src/app/models/input_error_msg.model';

@Component({
  selector: 'csw-code-validation',
  templateUrl: './code-validation.component.html',
  styleUrls: ['./code-validation.component.scss'],
})
export class CodeValidationComponent implements OnInit, OnDestroy {
  auth: IAuthModel;
  codeForm: FormGroup;
  phoneDetails: IPhoneDetails;
  @Input() back_arrow_svg: string;
  @Input() auth$: Observable<IAuthModel>;
  @Input() phoneDetails$: Observable<IPhoneDetails>;
  @Input() labelCode: string;
  @Input() labelImei: string;
  @Input() previous_widget: string;
  @Input() quote_button_text: string;
  @Input() code_field_errors: IErrorInputMsg;
  @Input() imei_field_errors: IErrorInputMsg;
  @Input() imei_steps: IImeiStep[];
  @Input() title: string;
  @Input() popover_text: string;
  @Output() output = new EventEmitter<WidgetOutputEvent>();

  constructor(
    private fb: FormBuilder
  ) {}

  ngOnInit() {
    this.getPhoneDetails();

    if (this.phoneDetails.platform === 'Android') {
      this.codeForm = this.fb.group({
        code: ['', [Validators.required]]
      });
    } else {
      this.codeForm = this.fb.group({
        code: ['', [Validators.required]],
        imei: [
          '',
          {
            validators: [
              Validators.required,
              Validators.maxLength(15),
              Validators.minLength(15),
            ],
          },
        ],
      });
    }
    this.getAuthState();
  }

  ngOnDestroy(): void {}

  getPhoneDetails(): void {
    this.phoneDetails$
      .pipe(takeUntil(componentDestroyed(this)))
      .subscribe((response: IPhoneDetails) => {
        this.phoneDetails = response;
      });
  }

  getAuthState(): void {
    this.auth$
      .pipe(takeUntil(componentDestroyed(this)))
      .subscribe((response: IAuthModel) => {
        this.auth = response;
        if (this.auth.statusCode === '4004') {
          this.codeInput.setErrors({ codeValid: true });
        }
      });
  }

  getCodeErrorMessageImei() {
    return this.imeiInput.errors.required
      ? this.imei_field_errors.required_error_text
      : this.imeiInput.errors.minlength || this.imeiInput.errors.maxlength
        ? this.imei_field_errors.invalid_error_text
        : '';
  }

  _handleCodeValidation(): void {
    this.output.emit({
      type: 'VALIDATE_CODE',
      payload: {
        code: this.codeInput.value,
        imei: this.imeiInput && this.imeiInput.value,
      },
    });
  }

  _goBack() {
    this.output.emit({
      type: 'GO_BACK',
      payload: {
        previousWidget: this.previous_widget,
      },
    });
  }

  async _showToolKit(ev: any) {
    /*const popover = await this.popoverController.create({
      component: PopoverComponent,
      event: ev,
      translucent: true,
      showBackdrop: false,
      mode: 'ios',
      cssClass: 'custom-popup',
      componentProps: {
        textPopover: this.popover_text,
      },
    });
    return await popover.present();*/
  }

  get codeInput() {
    return this.codeForm.get('code');
  }

  get imeiInput() {
    return this.codeForm.get('imei');
  }
}
