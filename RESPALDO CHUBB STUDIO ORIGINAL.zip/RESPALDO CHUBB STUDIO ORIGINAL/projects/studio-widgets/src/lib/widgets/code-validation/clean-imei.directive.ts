import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: 'input[cswCleanImei]',
})
// @ts-ignore
export class CleanImeiDirective {
  constructor(private _el: ElementRef) {}

  @HostListener('input', ['$event'])
  // @ts-ignore
  onInputChange(event) {
    const initalValue = this._el.nativeElement.value;
    this._el.nativeElement.value = initalValue.replace(/-|\s/g, '');
    if (initalValue !== this._el.nativeElement.value) {
      event.stopPropagation();
    }
  }
}
