import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

import {
  MatInputModule,
  MatIconModule,
  MatTooltipModule, MatButtonModule,
} from '@angular/material';

import { CodeValidationComponent } from './code-validation.component';
import { PopoverModule } from '../../shared/popover/popover.module';
import { CleanImeiDirective } from './clean-imei.directive';



@NgModule({
  imports: [
    CommonModule,
    MatIconModule,
    MatInputModule,
    MatTooltipModule,
    MatButtonModule,
    ReactiveFormsModule,
    PopoverModule
  ],
  declarations: [
    CleanImeiDirective,
    CodeValidationComponent
  ],
  bootstrap: [CodeValidationComponent],
})
export class CodeValidationModule {
  static rootComponent = CodeValidationComponent;
}
