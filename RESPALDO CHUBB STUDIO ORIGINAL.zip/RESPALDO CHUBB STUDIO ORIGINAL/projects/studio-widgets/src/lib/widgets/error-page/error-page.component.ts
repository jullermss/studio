import {
  Component,
  EventEmitter,
  Input,
  OnDestroy,
  OnInit,
  Output,
} from '@angular/core';
import {
  ICurrentError,
  IErrorCustom,
} from '../../../../../../src/app/models/error.model';
import { WidgetOutputEvent } from '../../shared/widget-output-event.model';
import { Observable } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { componentDestroyed } from '@crux/components';

@Component({
  selector: 'csw-studio-error-page',
  templateUrl: './error-page.component.html',
  styleUrls: ['./error-page.component.scss'],
})
export class ErrorPageComponent implements OnInit, OnDestroy {
  errorObject: IErrorCustom;
  @Input() errorList: IErrorCustom[];
  @Input() error$: Observable<ICurrentError>;
  @Output() output = new EventEmitter<WidgetOutputEvent>();

  constructor() {}

  ngOnInit() {
    if (this.error$) {
      this.error$
        .pipe(takeUntil(componentDestroyed(this)))
        .subscribe((response: ICurrentError) => {
          this.errorObject = this.errorList.filter(
            (item) => item.code === response.code
          )[0];
        });
    }
  }
  // going back button
  _goBack(): void {
    this.output.emit({
      type: 'GO_BACK',
      payload: {
        previousWidget: this.errorObject.nextWidget,
      },
    });
  }

  ngOnDestroy(): void {}
}
