import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ExtendedModule } from '@angular/flex-layout';
import { ErrorPageComponent } from './error-page.component';

@NgModule({
  declarations: [ErrorPageComponent],
  bootstrap: [ErrorPageComponent],
  imports: [CommonModule, ExtendedModule],
})
export class ErrorPageModule {
  static rootComponent = ErrorPageComponent;
}
