import { Component, Input, ViewEncapsulation } from '@angular/core';
import { Content, ContentHeader } from './content-header.model';
import { NavigationButton } from '../../shared/navigation-button/navigation-button.model';

@Component({
  selector: 'csw-content-header',
  templateUrl: './content-header.component.html',
  styleUrls: ['./content-header.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class ContentHeaderComponent implements ContentHeader {
  @Input() description: Content<string>;

  @Input() links: Content<NavigationButton>[];

  @Input() styles: { [key: string]: string };

  @Input() title: Content<string>;

  @Input() subTitle: Content<string>;

  @Input() titleColor: string;

  constructor() {}
}
