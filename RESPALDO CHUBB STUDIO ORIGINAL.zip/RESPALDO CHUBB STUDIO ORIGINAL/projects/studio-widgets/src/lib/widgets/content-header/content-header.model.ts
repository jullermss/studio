import { NavigationButton } from '../../shared/navigation-button/navigation-button.model';

export interface ContentHeader {
  styles?: {
    [key: string]: string;
  };

  title: Content<string>;

  subTitle?: Content<string>;

  description?: Content<string>;

  links?: Content<NavigationButton>[];
}

// ToDo: generalize it, a lot of components are going to use it
export interface Content<T> {
  content: T;
  styles?: {
    [key: string]: string;
  };
}
