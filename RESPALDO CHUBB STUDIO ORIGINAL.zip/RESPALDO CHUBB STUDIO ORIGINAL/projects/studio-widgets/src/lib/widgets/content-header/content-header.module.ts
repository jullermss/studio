import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ContentHeaderComponent } from './content-header.component';
import { NavigationButtonModule } from '../../shared/navigation-button/navigation-button.module';

@NgModule({
  imports: [CommonModule, NavigationButtonModule],
  declarations: [ContentHeaderComponent],
  bootstrap: [ContentHeaderComponent],
  exports: [ContentHeaderComponent],
})
export class ContentHeaderModule {
  static rootComponent = ContentHeaderComponent;
}
