import {
  Component,
  OnInit,
  Input,
  OnDestroy,
  Output,
  EventEmitter,
  AfterContentInit,
} from '@angular/core';

import { Observable } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { componentDestroyed } from '@crux/components';
import { IQuoteModel } from '../../../../../../src/app/models/quote.model';
import { ISelectedPlanModel } from '../../../../../../src/app/models/selected-plan';
import { WidgetOutputEvent } from '../../shared/widget-output-event.model';
import { ICoverage } from '../../../../../../src/app/models/coverage.model';
import { ICoverageIcon } from '../../../../../../src/app/models/coverage-icon.model';

import { forEach } from 'lodash-es';
import { ModalCoveragesComponent } from '../../shared/modal-coverages/modal-coverages.component';

@Component({
  selector: 'csw-plan-details-widget',
  templateUrl: './plan-details-widget.component.html',
  styleUrls: ['./plan-details-widget.component.scss'],
})
export class PlanDetailsWidgetComponent
  implements OnInit, OnDestroy, AfterContentInit {
  slideOpts = {
    initialSlide: 0,
    speed: 400,
    slidesPerView: 2.5,
    spaceBetween: 0.5,
    // centeredSlides: true,
  };

  planDetails: ISelectedPlanModel;
  @Input() previous_widget: string;
  @Input() back_arrow_svg: string;
  @Input() terms: string;
  @Input() beneficie_header: string;
  @Input() price_header: string;
  @Input() phone_image: string;
  @Input() payment_frequency: string;
  @Input() next_widget: string;
  @Input() title: string;
  @Input() coverage_icons: ICoverageIcon[];
  @Input() storageSelected$: Observable<any>;
  @Input() planSelected$: Observable<ISelectedPlanModel>;
  @Output() output = new EventEmitter<WidgetOutputEvent>();
  constructor(
  ) {}

  ngOnInit() {
    this.planSelected$
      .pipe(takeUntil(componentDestroyed(this)))
      .subscribe((response: ISelectedPlanModel) => {
        this.planDetails = response;
      });
  }
  ngAfterContentInit() {
    this.output.emit({
      type: 'HIDE_LOADING',
      payload: {
        nextWidget: this.next_widget,
      },
    });
  }

  async presentModal(i) {
    /*const modal = await this.modalController.create({
      component: ModalCoveragesComponent,
      cssClass: 'modal-coverages',
      componentProps: {
        planDetails: this.planDetails,
        indexSelected: i,
        coverage_icons: this.coverage_icons,
      },
    });
    modal.onDidDismiss().then(() => {
      // const user = data['data']; // Here's your selected user!
      console.log('Cerrando el modal detalles');
    });
    return await modal.present();*/
  }

  _goBack(): void {
    this.output.emit({
      type: 'GO_BACK',
      payload: {
        previousWidget: this.previous_widget,
      },
    });
  }

  _goNext(): void {
    this.output.emit({
      type: 'GO_NEXT',
      payload: {
        nextWidget: this.next_widget,
      },
    });
  }

  ngOnDestroy(): void {}
  _getWidthScreen() {
    return `${window.screen.width}px`;
  }

  _getCoverageIcon(coveage_name: string) {
    let icon = this.coverage_icons[this.coverage_icons.length - 1].icon;
    for (const coverage_icon of this.coverage_icons) {
      if (coveage_name === coverage_icon.name) {
        icon = coverage_icon.icon;
      }
    }
    return icon;
  }

  __getfilterPrincipalCoverage() {
    return this.planDetails.coverages.filter((x) => x.isPrincipal);
  }
}
