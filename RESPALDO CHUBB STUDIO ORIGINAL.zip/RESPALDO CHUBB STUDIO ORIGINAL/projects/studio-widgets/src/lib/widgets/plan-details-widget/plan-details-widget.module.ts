import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PlanDetailsWidgetComponent } from './plan-details-widget.component';
import { FlexLayoutModule } from '@angular/flex-layout';

import { ModalCoverageModule } from '../../shared/modal-coverages/modal-coverage.module';

@NgModule({
  declarations: [PlanDetailsWidgetComponent],
  bootstrap: [PlanDetailsWidgetComponent],
  imports: [CommonModule, FlexLayoutModule, ModalCoverageModule],
})
export class PlanDetailsWidgetModule {
  static rootComponent = PlanDetailsWidgetComponent;
}
