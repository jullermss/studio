import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InitialPageComponent } from './initial-page.component';
import { ExtendedModule, FlexLayoutModule } from '@angular/flex-layout';

@NgModule({
  declarations: [InitialPageComponent],
  bootstrap: [InitialPageComponent],
  imports: [CommonModule, ExtendedModule],
})
export class InitialPageModule {
  static rootComponent = InitialPageComponent;
}
