export const environment = {
  production: true,
  development: false,
  servicingFooterUrl: 'https://www.chubb.com',
  siteKey: '6Ldof44UAAAAALrwahkqrvYPSJGg3asIkybV4gRD',
  backend: '/api',
  uri: {
    validatePolicy: '/validatepolicy',
    downloadCOI: '/downloadcoi',
    endorsement: '/endorsement',
    documentlistCoi: '/documentlistcoi',
    verification: '/validateaccount',
    policySummary: '/policysummary',
    documentlistPolicy: '/documentlistpolicy',
    userprofile: '/userprofile',
    updateuseprofile: '/updateuseprofile',
    sciDownloadCOI: '/scidownloadcoi',
    registerUser: '/registeruser',
    retrieveUsername: '/retrieveusername',
    documentpolicy: '/documentpolicy',
    documentcoi: '/documentcoi',
    userPolicies: '/userpolicies?username=',
    passwordreset: '/passwordreset',
    addressLookUp:
      '/lookupAddress?Data.AddressLine1=$searchTerm$&Data.Country=$country$&Data.PostalCode=$postalCode$&MaxCandidates=$numRows$',
    validateZip: '/validateZip',
    policySearch: '/policySearch',
    createFNOL: '/claims/createFNOL',
    uploadDocument: '/claims/documents/',
    submitFNOL: '/claims/submitFNOL/',
    csrPolicySearch: '/csrPolicySearch',
    pageNotFound: 'page-not-found',
  },
  // ADB2C Configurations
  clientID: 'a20590e6-1fab-4898-ad2d-0a0ea835da7e',
  redirectUrl: 'https://commercialservice.chubb.com/Dashboard',
  authority:
    'https://login.microsoftonline.com/tfp/CBAADB2C08.onmicrosoft.com/B2C_1A_SPSignIn',
  extraQueryParameter: 'p=B2C_1A_SPSignIn&scope=openid&nux=1',
  b2cRead: 'https://b2c.chubbdigital.com/ServicingportalAPI/read',
  b2cWrite: 'https://b2c.chubbdigital.com/ServicingportalAPI/write',
  /**
   * Analytics
   */
  gtmTrackingId: 'GTM-PXWGT34',
  appInsightsInstrumentationKey: 'bdd2917a-a0be-46a0-9edd-2bea33492123',
};
