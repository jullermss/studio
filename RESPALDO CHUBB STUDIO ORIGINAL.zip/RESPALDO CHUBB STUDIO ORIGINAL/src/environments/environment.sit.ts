// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

export const environment = {
  production: false,
  development: false,
  servicingFooterUrl: 'https://www.chubb.com',
  siteKey: '6Ldof44UAAAAALrwahkqrvYPSJGg3asIkybV4gRD',
  backend: 'https://studio-beta-sit.chubb.com/api',
  uri: {
    validatePolicy: '/validatepolicy',
    downloadCOI: '/downloadcoi',
    endorsement: '/endorsement',
    documentlistCoi: '/documentlistcoi',
    verification: '/validateaccount',
    policySummary: '/policysummary',
    documentlistPolicy: '/documentlistpolicy',
    userprofile: '/userprofile',
    updateuseprofile: '/updateuseprofile',
    sciDownloadCOI: '/scidownloadcoi',
    registerUser: '/registeruser',
    retrieveUsername: '/retrieveusername',
    documentpolicy: '/documentpolicy',
    documentcoi: '/documentcoi',
    userPolicies: '/userpolicies?username=',
    passwordreset: '/passwordreset',
    addressLookUp:
      '/lookupAddress?Data.AddressLine1=$searchTerm$&Data.Country=$country$&Data.PostalCode=$postalCode$&MaxCandidates=$numRows$',
    validateZip: '/validateZip',
    policySearch: '/policySearch',
    createFNOL: '/claims/createFNOL',
    uploadDocument: '/claims/documents/',
    submitFNOL: '/claims/submitFNOL/',
    csrPolicySearch: '/csrPolicySearch',
    pageNotFound: 'page-not-found',
  },
  // ADB2C Configurations
  // SIT client ID and redirect
  clientID: 'ebb378c2-1a72-4bde-b69b-55c7a67b1a05',
  redirectUrl:
    'https://studio-beta-sit.chubb.com/us/chubb/default/default/en-US/Dashboard',
  authority:
    'https://login.microsoftonline.com/tfp/cbaadb2c08sit.onmicrosoft.com/B2C_1A_SPSignIn',
  extraQueryParameter: 'p=B2C_1A_SPSignIn&scope=openid&nux=1',
  b2cRead: 'https://sitb2c.chubbdigital.com/ServicingportalAPI/read',
  b2cWrite: 'https://sitb2c.chubbdigital.com/ServicingportalAPI/write',
  /**
   * Analytics
   */
  gtmTrackingId: 'GTM-WW3F2JZ',
  appInsightsInstrumentationKey: '5b66f1c5-ccc2-47c6-a61b-5f62e3c6fee9',
};
