export const environment = {
  production: false,
  development: true,
  servicingFooterUrl: 'https://www.chubb.com',
  siteKey: '6Ld-MI4UAAAAAIBIHTZjtRsCBr67E44sys7ymlRy',
  backend: 'https://studio-beta-sit.chubb.com/api',
  apiBaseUrl:
    'https://latamapp360devapi.latammicroapidevase.p.azurewebsites.net',
  uri: {
    validatePolicy: '/validatepolicy',
    downloadCOI: '/downloadcoi',
    endorsement: '/endorsement',
    documentlistCoi: '/documentlistcoi',
    verification: '/validateaccount',
    policySummary: '/policysummary',
    documentlistPolicy: '/documentlistpolicy',
    userprofile: '/userprofile',
    updateuseprofile: '/updateuseprofile',
    sciDownloadCOI: '/scidownloadcoi',
    registerUser: '/registeruser',
    retrieveUsername: '/retrieveusername',
    documentpolicy: '/documentpolicy',
    documentcoi: '/documentcoi',
    userPolicies: '/userpolicies?username=',
    passwordreset: '/passwordreset',
    addressLookUp:
      '/lookupAddress?Data.AddressLine1=$searchTerm$&Data.Country=$country$&Data.PostalCode=$postalCode$&MaxCandidates=$numRows$',
    validateZip: '/validateZip',
    policySearch: '/policySearch',
    createFNOL: '/claims/createFNOL',
    uploadDocument: '/claims/documents/',
    submitFNOL: '/claims/submitFNOL/',
    csrPolicySearch: '/csrPolicySearch',
    pageNotFound: 'page-not-found',
  },
  // ADB2C Configurations
  // SIT client ID and redirect
  clientID: 'c34566e8-1d46-467b-bf94-6a32164e68be',
  redirectUrl: 'https://service-sit.chubbsmallbusiness.com/Dashboard',
  authority:
    'https://login.microsoftonline.com/tfp/cbaadb2c08sit.onmicrosoft.com/B2C_1A_SPSignIn',
  extraQueryParameter: 'p=B2C_1A_SPSignIn&scope=openid&nux=1',
  b2cRead: 'https://sitb2c.chubbdigital.com/ServicingportalAPI/read',
  b2cWrite: 'https://sitb2c.chubbdigital.com/ServicingportalAPI/write',
  /**
   * Analytics
   */
  gtmTrackingId: 'GTM-WW3F2JZ',
  appInsightsInstrumentationKey: '',
};
