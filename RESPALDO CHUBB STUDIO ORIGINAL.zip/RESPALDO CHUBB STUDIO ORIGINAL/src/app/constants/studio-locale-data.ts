import { InjectionToken } from '@angular/core';

export const STUDIO_LOCALE_DATA = new InjectionToken<any>(`Studio Locale Data`);
