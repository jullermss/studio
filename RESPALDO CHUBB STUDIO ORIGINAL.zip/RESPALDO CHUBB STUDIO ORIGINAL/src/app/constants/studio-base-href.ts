import { InjectionToken } from '@angular/core';

export const STUDIO_BASE_HREF = new InjectionToken<any>(`Studio Base Href`);
