import { Routes } from '@angular/router';
import { LayoutComponent } from './layout';
import { AuthenticationGuard } from './authentication';
import { RouteGuard } from './guards';
// @ts-ignore
import { AppContextGuard } from '@studio/guards/app-context.guard';
import { environment } from '../environments/environment';
import { ChooseStorageResolver } from './pages/choose-storage/choose-storage.resolver';
import { PlanDetailsResolver } from './pages/plan-details/plan-details.resolver';
import { RedirectService } from './services/redirect.service';
import { CodeValidationResolver } from './pages/code-validation/code-validation.resolver';
import { PersonInfoResolver } from './pages/person-info/person-info.resolver';
export const appRoutes: Routes = [
  {
    path: '',
    component: LayoutComponent,
    canActivate: [AppContextGuard],
    canActivateChild: [RouteGuard],
    children: [
      {
        path: '',
        redirectTo: 'home',
        pathMatch: 'full',
      },
      {
        path: 'initial-page',
        loadChildren:
          'app/pages/initial-page/initial-page.module#InitialPageModule',
        data: {
          tile: 'Initial Page',
        },
      },
      {
        path: 'apps',
        loadChildren:
          'app/pages/studio-apps/studio-apps.module#StudioAppsModule',
        canActivate: [AuthenticationGuard],
        data: {
          title: 'Apps',
          routeSettings: {
            name: 'apps',
          },
        },
      },
      {
        path: 'quote-page',
        loadChildren: 'app/pages/quote/quote.module#QuotePageModule',
        data: {
          title: 'quote-page',
          routeSettings: {
            name: 'quote-page'
          }
        }
      },
      {
        path: 'home',
        loadChildren: 'app/pages/home/home.module#HomeModule',
        data: {
          title: 'Home',
          routeSettings: {
            name: 'home',
          },
        },
      },
      {
        path: environment.uri.pageNotFound,
        loadChildren:
          'app/pages/page-not-found/page-not-found.module#PageNotFoundModule',
        data: {
          title: 'Page Not Found',
        },
      },
      {
        path: 'initial-page',
        loadChildren:
          'app/pages/initial-page/initial-page.module#InitialPageModule',
        data: {
          tile: 'Initial Page',
          routeSettings: {
            name: 'initial-page',
          },
        },
      },
      {
        path: 'login-page',
        loadChildren: 'app/pages/login-page/login-page.module#LoginPageModule',
        data: {
          tile: 'Login Page',
          routeSettings: {
            name: 'login-page',
          },
        },
      },

      {
        path: 'esitef-page',
        loadChildren:
          'app/pages/esitef-page/esitef-page.module#EsitefPageModule',
        data: {
          tile: 'Esitef Page',
          routeSettings: {
            name: 'esitef-page',
          },
        },
      },
      {
        path: 'address-page',
        loadChildren:
          'app/pages/address-page/address-page.module#AddressPageModule',
        data: {
          tile: 'Address Page',
          routeSettings: {
            name: 'address-page',
          },
        },
      },
      {
        path: 'sign-up-page',
        loadChildren:
          'app/pages/sign-up-page/sign-up-page.module#SignUpPageModule',
        data: {
          tile: 'Sign Up Page',
          routeSettings: {
            name: 'sign-up-page',
          },
        },
      },
      {
        path: 'choose-storage',
        loadChildren:
          'app/pages/choose-storage/choose-storage.module#ChooseStorageModule',
        data: {
          tile: 'Choose Storage',
          routeSettings: {
            name: 'choose-storage',
          },
        },
        resolve: { resolverData: ChooseStorageResolver },
      },
      {
        path: 'plan-details',
        loadChildren:
          'app/pages/plan-details/plan-details.module#PlanDetailsModule',
        data: {
          tile: 'Plan Details',
          routeSettings: {
            name: 'plan-details',
          },
        },
        resolve: { resolverData: PlanDetailsResolver },
      },
      {
        path: 'code-validation',
        loadChildren:
          'app/pages/code-validation/code-validation.module#CodeValidationModule',
        data: {
          title: 'Code Validation',
          routeSettings: {
            name: 'code-validation',
          },
        },
        resolve: { resolverData: CodeValidationResolver },
      },
      {
        path: 'person-info',
        loadChildren:
          'app/pages/person-info/person-info.module#PersonInfoModule',
        data: {
          title: 'Person Info Page',
          routeSettings: {
            name: 'person-info',
          },
        },
        resolve: { resolverData: PersonInfoResolver },
      },
      {
        path: 'thank-you',
        loadChildren: 'app/pages/thankyou/thankyou.module#ThankYouModule',
        data: {
          title: 'Thank You',
          routeSettings: {
            name: 'thank-you',
          },
        },
      },
      {
        path: 'error-page',
        loadChildren: 'app/pages/error-page/error-page.module#ErrorPageModule',
        data: {
          tile: 'Error Page',
          routeSettings: {
            name: 'error-page',
          },
        },
      },
      {
        path: 'error-payment',
        loadChildren: 'app/pages/error-payment/error-payment.module#ErrorPaymentModule',
        data: {
          title: 'Error Payment',
          routeSettings: {
            name: 'error-payment',
          },
        },
      },
    ],
  },
  {
    path: environment.uri.pageNotFound,
    loadChildren:
      'app/pages/page-not-found/page-not-found.module#PageNotFoundModule',
    data: {
      title: 'Page Not Found',
    },
  },
  {
    path: '**',
    redirectTo: `/${environment.uri.pageNotFound}`,
    pathMatch: 'full',
  },
];

RedirectService.init(appRoutes);
