import { Injectable } from '@angular/core';
import { from, of, Observable } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { NgxViacepService } from '@brunoc/ngx-viacep';
import {
  AddressBrazil,
  Country2DigitsEnum,
} from '../models/address-brasil.model';

@Injectable({
  providedIn: 'root',
})
export class AddressService {
  constructor(private viacepService: NgxViacepService) {}
  /**
   *
   * @param cep
   */
  getAddressByCep(cep: string): Observable<any> {
    return from(this.viacepService.buscarPorCep(cep)).pipe(
      catchError(() => {
        return of(null);
      }),
      map((data) => {
        if (!data) {
          return null;
        }
        return new AddressBrazil({
          zipCode: data.cep,
          addressLine1: data.logradouro,
          city: data.localidade,
          neighborhood: data.bairro,
          state: data.uf,
          country: Country2DigitsEnum.BRAZIL,
        });
      })
    );
  }
}
