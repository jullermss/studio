import { Injectable } from '@angular/core';
import { Platform } from '@angular/cdk/platform';

/**
 * @desc FOR_EVA
 */
declare var scxmlHandler;

@Injectable({
  providedIn: 'root',
})
export class EvaHelperService {
  private formatBytes(bytes, decimals = 1) {
    if (bytes === 0) {
      return '0 Bytes';
    }
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
  }

  async getIMEI(): Promise<string | number | null> {
    try {
      const cellularDetails = await scxmlHandler.getCellularDetails();
      if (cellularDetails) {
        if (cellularDetails.imei) {
          return new Promise((resolve) => {
            resolve(cellularDetails.imei);
          });
        }
      }
    } catch (e) {
      return new Promise((resolve) => {
        resolve('12345678901243');
      });
    }

    return new Promise((resolve, reject) => {
      reject(null);
    });
  }

  getPlatform() {
    return this._platform;
  }

  constructor(private _platform: Platform) {}
}
