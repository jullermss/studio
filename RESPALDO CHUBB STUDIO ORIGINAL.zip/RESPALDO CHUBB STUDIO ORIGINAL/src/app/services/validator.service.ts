import { Injectable } from '@angular/core';
import { AbstractControl, ValidationErrors } from '@angular/forms';
import { HttpClient, HttpParams } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { debounceTime, switchMap, catchError } from 'rxjs/operators';
import { of } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class ValidatorService {
  private baseUrl: string = environment.apiBaseUrl;

  constructor(private http: HttpClient) {}

  phoneBR(control: AbstractControl): ValidationErrors | null {
    if (control.value === '') {
      return null;
    }
    const phoneWithoutMask = control.value.replace(/\D+/g, '');
    const isValid =
      /^\(\d{2}\)(| )\d{4,5}\-\d{4}$/.test(control.value) &&
      !/(.)\1{10}/.test(phoneWithoutMask);
    return isValid ? null : { phoneBR: true };
  }

  cpfBR(control: AbstractControl): ValidationErrors | null {
    if (control.value === '') {
      return null;
    }

    if (!control.value.match(/^[0-9]{11}$/)) {
      return { cpf: true };
    }

    let add = 0;
    for (let i = 0; i < 9; i++) {
      // tslint:disable-next-line:radix
      add += parseInt(control.value.charAt(i)) * (10 - i);
    }
    let rev = 11 - (add % 11);
    rev = rev === 10 || rev === 11 ? 0 : rev;
    // tslint:disable-next-line:radix
    return rev !== parseInt(control.value.charAt(9)) ? { cpf: true } : null;
  }

  checkEmailAvailability(email) {
    return this.http.get(`${this.baseUrl}/user/checkEmailAvailability/${email}`).pipe(
      catchError(() => {
        return of(null);
      })
    );
  }
}
