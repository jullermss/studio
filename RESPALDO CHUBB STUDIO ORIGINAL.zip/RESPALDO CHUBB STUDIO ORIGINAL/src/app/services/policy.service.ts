import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { CruxHttpClientService } from '@crux/services';
import { IPolicyModel } from '../models/policy.model';
import { Observable } from 'rxjs';
import { ICreatePolicyResponse } from '../models/ICreatePolicyResponse';
import { ICreatePolicyRequest } from '../models/ICreatePolicyRequest';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class PolicyService {
  private baseUrl: string = environment.apiBaseUrl;
  constructor(private httpClient: HttpClient) {}
  /**
   * This service create the policy and get the esitef iframe
   * policy object
   * @param policySate
   */
  createPolicy(policySate: IPolicyModel): Observable<ICreatePolicyResponse> {
    const policyRequestObject: ICreatePolicyRequest = {
      quoteHistoryId: policySate.quoteId,
      phoneStorage: policySate.phoneStorage,
      insured: policySate.personInfo,
    };
    const url = `${this.baseUrl}${environment.uri.createPolicy}`;
    return this.httpClient.post<ICreatePolicyResponse>(
      url,
      policyRequestObject
    );
  }
}
