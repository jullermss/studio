import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { IQuoteModel } from '../models/quote.model';
import { IStorageDetails } from '../models/storage-details.model';
import { IPhoneDetails } from '../models/phone-details.model';

@Injectable({
  providedIn: 'root',
})
export class MockDataServicesService {
  mockQuote = {
    id: 'dde377cf-56ef-44d9-a8da-1d22a48d097e',
    make: 'SAMSUNG',
    model: 'Galaxy Grand Prime Plus',
    availableStorage: [
      {
        storage: '8GB',
        storageValue: '8',
        storageMeasurement: 'GB',

        planDetails: {
          name: 'Plan 1',
          description: 'Plan 1 description',
          totalPremiumValue: '14.90',
          maxCoverageValue: '750.00',
          premiumFrequency: 'Monthly',
          coverages: [
            {
              name: 'Robo',
              description:
                '<ul>\n<li>Valor fijo alrededor del 20% del valor del dispositivo por reemplazo.</li>\n</ul>',
              title: 'Robo con Violencia',
              deductibleValue: '165.00',
              isPrincipal: true,
            },
            {
              name: 'Daño',
              description:
                '<ul>\n<li>Valor fijo alrededor del 10% del valor del dispositivo por reparación del equipo.</li>\n<li>Valor fijo alrededor del 20% del valor del dispositivo por reemplazo.</li>\n</ul>',
              title: 'Daño Parcial o Total',
              deductibleValue: '85.00',
              isPrincipal: true,
            },
            {
              name: 'RoboMochila',
              description:
                '<ul>\n<li>Valor fijo alrededor del 10% del valor del dispositivo por reparación del equipo.</li>\n<li>Valor fijo alrededor del 20% del valor del dispositivo por reemplazo.</li>\n</ul>',
              title: 'Robo de Bolso/Mochila',
              deductibleValue: null,
              isPrincipal: false,
            },
            {
              name: 'RoboAtm',
              description:
                '<ul>\n<li>Valor fijo alrededor del 10% del valor del dispositivo por reparación del equipo.</li>\n<li>Valor fijo alrededor del 20% del valor del dispositivo por reemplazo.</li>\n</ul>',
              title: 'Robo de Efectivo ATM/Ventanilla',
              deductibleValue: null,
              isPrincipal: false,
            },
          ],
          benefits: [
            {
              name: 'McAfee',
              title: 'Protección de Información',
              description: `<ul>
                                    <li>Herramientas de control parental móvil o asistencia cibernética.</li>
                                    <li>Buscar, bloquear y borrar el dispositivo perdido.</li>
                                    <li>Navegación segura.</li>
                                    <li>Gestión de contraseñas clave con tecnología biometrica.</li>
                                    <li>Optimizador de batería</li>
                                    </ul>`,
              subtitle: 'Servicios Digitales McAfee',
            },
          ],
        },
      },
      {
        storage: '16GB',
        storageValue: '16',
        storageMeasurement: 'GB',
        planDetails: {
          name: 'Plan 1',
          description: 'Plan 1 description',
          totalPremiumValue: '14.90',
          maxCoverageValue: '750.00',
          premiumFrequency: 'Monthly',
          coverages: [
            {
              name: 'Robo',
              description:
                '<ul>\n<li>Valor fijo alrededor del 20% del valor del dispositivo por reemplazo.</li>\n</ul>',
              title: 'Robo con Violencia',
              deductibleValue: '165.00',
              isPrincipal: true,
            },
            {
              name: 'Daño',
              description:
                '<ul>\n<li>Valor fijo alrededor del 10% del valor del dispositivo por reparación del equipo.</li>\n<li>Valor fijo alrededor del 20% del valor del dispositivo por reemplazo.</li>\n</ul>',
              title: 'Daño Parcial o Total',
              deductibleValue: '85.00',
              isPrincipal: true,
            },
            {
              name: 'RoboMochila',
              description:
                '<ul>\n<li>Valor fijo alrededor del 10% del valor del dispositivo por reparación del equipo.</li>\n<li>Valor fijo alrededor del 20% del valor del dispositivo por reemplazo.</li>\n</ul>',
              title: 'Robo de Bolso/Mochila',
              deductibleValue: null,
              isPrincipal: false,
            },
            {
              name: 'RoboAtm',
              description:
                '<ul>\n<li>Valor fijo alrededor del 10% del valor del dispositivo por reparación del equipo.</li>\n<li>Valor fijo alrededor del 20% del valor del dispositivo por reemplazo.</li>\n</ul>',
              title: 'Robo de Efectivo ATM/Ventanilla',
              deductibleValue: null,
              isPrincipal: false,
            },
          ],
          benefits: [
            {
              name: 'McAfee',
              title: 'Protección de Información',
              description: `<ul>
                                    <li>Herramientas de control parental móvil o asistencia cibernética.</li>
                                    <li>Buscar, bloquear y borrar el dispositivo perdido.</li>
                                    <li>Navegación segura.</li>
                                    <li>Gestión de contraseñas clave con tecnología biometrica.</li>
                                    <li>Optimizador de batería</li>
                                    </ul>`,
              subtitle: 'Servicios Digitales McAfee',
            },
          ],
        },
      },
      {
        storage: '32GB',
        storageValue: '32',
        storageMeasurement: 'GB',
        planDetails: {
          name: 'Plan 1',
          description: 'Plan 1 description',
          totalPremiumValue: '14.90',
          maxCoverageValue: '750.00',
          premiumFrequency: 'Monthly',
          coverages: [
            {
              name: 'Robo',
              description:
                '<ul>\n<li>Valor fijo alrededor del 20% del valor del dispositivo por reemplazo.</li>\n</ul>',
              title: 'Robo con Violencia',
              deductibleValue: '165.00',
              isPrincipal: true,
            },
            {
              name: 'Daño',
              description:
                '<ul>\n<li>Valor fijo alrededor del 10% del valor del dispositivo por reparación del equipo.</li>\n<li>Valor fijo alrededor del 20% del valor del dispositivo por reemplazo.</li>\n</ul>',
              title: 'Daño Parcial o Total',
              deductibleValue: '85.00',
              isPrincipal: true,
            },
            {
              name: 'RoboMochila',
              description:
                '<ul>\n<li>Valor fijo alrededor del 10% del valor del dispositivo por reparación del equipo.</li>\n<li>Valor fijo alrededor del 20% del valor del dispositivo por reemplazo.</li>\n</ul>',
              title: 'Robo de Bolso/Mochila',
              deductibleValue: null,
              isPrincipal: false,
            },
            {
              name: 'RoboAtm',
              description:
                '<ul>\n<li>Valor fijo alrededor del 10% del valor del dispositivo por reparación del equipo.</li>\n<li>Valor fijo alrededor del 20% del valor del dispositivo por reemplazo.</li>\n</ul>',
              title: 'Robo de Efectivo ATM/Ventanilla',
              deductibleValue: null,
              isPrincipal: false,
            },
          ],
          benefits: [
            {
              name: 'McAfee',
              title: 'Protección de Información',
              description: `<ul>
                                    <li>Herramientas de control parental móvil o asistencia cibernética.</li>
                                    <li>Buscar, bloquear y borrar el dispositivo perdido.</li>
                                    <li>Navegación segura.</li>
                                    <li>Gestión de contraseñas clave con tecnología biometrica.</li>
                                    <li>Optimizador de batería</li>
                                    </ul>`,
              subtitle: 'Servicios Digitales McAfee',
            },
          ],
        },
      },
    ],
  } as IQuoteModel;

  mockPhoneDetailsList: IPhoneDetails[] = [
    {
      imei: '551501081234566',
      make: 'SAMSUNG',
      model: 'Galaxy Grand Prime Plus',
      language: 'EN',
      platform: 'Android',
      storage: '',
      phoneNumber: '8114142451',
    },
    {
      imei: '351501081234556',
      make: 'Apple',
      model: 'X',
      language: 'EN',
      platform: 'IOS',
      storage: '8GB',
      phoneNumber: '',
    },
    {
      imei: '351501081234557',
      make: 'SAMSUNG',
      model: 'Galaxy J7 Core',
      language: 'EN',
      platform: 'Android',
      storage: '',
      phoneNumber: '8991757472',
    },
    {
      imei: '',
      make: 'SAMSUNG',
      model: 'Galaxy J7 Core',
      language: 'EN',
      platform: 'Android',
      storage: '',
      phoneNumber: '8991757472',
    },
  ];

  constructor() {}

  /**
   *
   * @param storageType
   */
  getQuote(storageType?: string): Observable<IQuoteModel> {
    const quoteData = this.mockQuote.availableStorage.filter(
      (storage: IStorageDetails) => {
        return storageType ? storage.storage === storageType : true;
      }
    );

    return of({
      ...this.mockQuote,
      storage: quoteData,
    });
  }

  /**
   *
   */
  getPhoneDetails(): Observable<IPhoneDetails> {
    const index = Math.floor(
      Math.random() * (this.mockPhoneDetailsList.length - 1)
    );
    return of(this.mockPhoneDetailsList[index]);
  }
}
