import { Inject, Injectable } from '@angular/core';
import { Route, Router, Routes } from '@angular/router';
import { IDictionary } from '../models/dictionary.model';
import { IRedirectToModel } from '../models/redirect-to.model';
import { STUDIO_BASE_HREF } from '../constants/studio-base-href';

@Injectable({
  providedIn: 'root',
})
export class RedirectService {
  static routes: IDictionary<IRouteSettings> = {};
  constructor(
    private router: Router,
    @Inject(STUDIO_BASE_HREF) private _baseHref
  ) {}

  static init(routes: Routes, parentPath: string = '') {
    routes.forEach((eachRoute: Route) => {
      if (eachRoute.hasOwnProperty('children')) {
        RedirectService.init(eachRoute.children, eachRoute.path);
      } else {
        if (
          !eachRoute.hasOwnProperty('data') ||
          !eachRoute.data.hasOwnProperty('routeSettings')
        ) {
          return;
        }
        const routeSettings = eachRoute.data.routeSettings;
        routeSettings.path =
          parentPath !== ''
            ? `${parentPath}/${eachRoute.path}`
            : eachRoute.path; // now all route paths are added to this prop
        if (routeSettings.name === undefined) {
          return;
        }
        if (RedirectService.routes.hasOwnProperty(routeSettings.name)) {
          console.warn(
            'Multiples route setting definition with the same name.',
            eachRoute
          );
        }
        RedirectService.routes[routeSettings.name] = routeSettings;
      }
    });
  }

  redirectTo(redirectTo: IRedirectToModel): Promise<boolean> {
    const route: IRouteSettings = RedirectService.routes[redirectTo.routeName];
    const path = route.path.replace(
      ':country/:partner/:product/:channel/:locale',
      this._baseHref
    );
    return this.router.navigate([path], redirectTo.extraOptions);
  }
}

export interface IRouteSettings {
  name: string;
  path?: string;
  useBaseUrAsPrefix: boolean;
}
