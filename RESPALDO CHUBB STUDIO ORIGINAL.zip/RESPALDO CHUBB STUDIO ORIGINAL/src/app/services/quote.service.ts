import { Injectable } from '@angular/core';
import { CruxHttpClientService } from '@crux/services';
import { Observable } from 'rxjs';
import { IQuoteModel } from '../models/quote.model';
import { environment } from '../../environments/environment';
import { IGetQuoteRequestModel } from '../models/IGetQuoteRequest';
import { IApiResponse } from '../models/api-response';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class QuoteService {
  private baseUrl: string = environment.apiBaseUrl;

  constructor(private httpClient: CruxHttpClientService) {}

  /**
   * phone imei
   * @param imei
   */
  getQuote(imei: string): Observable<IQuoteModel> {
    const getQuoteRequestModel: IGetQuoteRequestModel = {
      imei: imei,
    };
    const url = `${this.baseUrl}${environment.uri.quote}`;
    console.log(url);
    // @ts-ignore
    return this.httpClient
      .post<IApiResponse>(url, { body: getQuoteRequestModel })
      .pipe(
        map((response: IApiResponse) => {
          if (response.isSuccessStatusCode) {
            return response.data;
          }
        })
      );
  }
}
