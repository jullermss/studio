import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { IApiResponse } from '../models/api-response';

@Injectable({
  providedIn: 'root',
})
export class CodeValidationService {
  private baseUrl: string = environment.apiBaseUrl;

  constructor(private http: HttpClient) {}

  /**
   * code provide by user
   * @param code
   */
  validateCode(code) {
    return this.http.post<IApiResponse>(`${this.baseUrl}/user/registerByCode`, { code });
  }
}
