import { Injectable } from '@angular/core';
import { IQuoteModel } from '../models/quote.model';
import { ISelectedPlanModel } from '../models/selected-plan';
import { forEach } from 'lodash-es';

@Injectable({
  providedIn: 'root',
})
export class MapperService {
  constructor() {}

  public quoteToSelectedPlan(
    quote: IQuoteModel,
    storage: any
  ): ISelectedPlanModel {
    let storageSelectedPos = 0;
    for (let i = 0; i <= quote.availableStorage.length; i++) {
      if (quote.availableStorage[i].storage === storage.selectedStorage) {
        storageSelectedPos = i;
        break;
      }
    }
    const planModel: ISelectedPlanModel = {
      quoteId: quote.id,
      make: quote.make,
      model: quote.model,
      coverages:
        quote.availableStorage[storageSelectedPos].planDetails.coverages,
      storageMeasurement:
        quote.availableStorage[storageSelectedPos].storageMeasurement,
      storageValue: quote.availableStorage[storageSelectedPos].storageValue,
      totalPremiumValue:
        quote.availableStorage[storageSelectedPos].planDetails
          .totalPremiumValue,
      benefits: quote.availableStorage[storageSelectedPos].planDetails.benefits,
      maxCoverageValue:
        quote.availableStorage[storageSelectedPos].planDetails.maxCoverageValue,
      premiumFrequency:
        quote.availableStorage[storageSelectedPos].planDetails.premiumFrequency,
    };
    return planModel;
  }
}
