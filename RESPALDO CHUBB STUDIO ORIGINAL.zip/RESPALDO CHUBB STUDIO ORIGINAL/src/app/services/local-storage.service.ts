import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class LocalStorageService {
  get(key: string): any {
    try {
      const data = localStorage.getItem(key);
      if (!data) {
        return null;
      }

      return JSON.parse(data);
    } catch (e) {
      throw new Error('Error getting data from localStorage');
    }
  }

  set(key: string, data: any): void {
    try {
      localStorage.setItem(key, JSON.stringify(data));
    } catch (e) {
      throw new Error('Error saving data to localStorage');
    }
  }

  remove(key: string): void {
    try {
      localStorage.removeItem(key);
    } catch (e) {
      throw new Error('Error removing data from localStorage');
    }
  }

  clearAll(): void {
    try {
      localStorage.clear();
    } catch (e) {
      throw new Error('Error clearing data from localStorage');
    }
  }
}
