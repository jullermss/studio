// IMPORTANT: THIS FILE IS AUTO GENERATED! DO NOT EDIT MANUALLY
/* tslint:disable */
export const VERSION = {
    "dirty": false,
    "raw": "5cd8b58",
    "hash": "5cd8b58",
    "distance": null,
    "tag": null,
    "semver": null,
    "suffix": "5cd8b58",
    "semverString": null,
    "version": "0.0.1",
    "crux": {
        "components": "v3.0.4-beta.0",
        "services": "v3.0.0",
        "themes": "v3.0.0",
        "toolkit": "v1.0.0"
    }
};
/* tslint:enable */
