import {
  StudioState,
  authInitialState,
  loadingIndicatorState,
  sectionsReady,
  studioAppsInitialState,
} from './state/intial-state';
import { quoteInitialState } from './state/intial-state/quote.state';
import { storageInitialState } from './state/intial-state/storage.state';
import { planInitialState } from './state/intial-state/plan.state';
import { IRedirectToModel } from './models/redirect-to.model';
import { phoneDetailsInitialState } from './state/intial-state/phone-details.state';
import { errorInitialState } from './state/intial-state/error.state';
import { policyInitialState } from './state/intial-state/policy.state';

// @ts-ignore
export const initialState: StudioState = {
  apps: studioAppsInitialState,
  auth: authInitialState,
  error: errorInitialState,
  loadingIndicator: loadingIndicatorState,
  quote: quoteInitialState,
  plan: planInitialState,
  phoneDetails: phoneDetailsInitialState,
  redirect: {} as IRedirectToModel,
  storage: storageInitialState,
  policy: policyInitialState,
  sectionsReady: sectionsReady,
};
