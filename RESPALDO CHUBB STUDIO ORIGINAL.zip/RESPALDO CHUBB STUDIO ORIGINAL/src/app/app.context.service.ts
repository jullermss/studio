import { Injectable } from '@angular/core';
import _get from 'lodash-es/get';
import _merge from 'lodash-es/merge';
import _some from 'lodash-es/some';
import _set from 'lodash-es/set';
import * as STUDIOJS from '../../studio';
import { HttpClient } from '@angular/common/http';
import { mergeMap, filter, map, tap, catchError } from 'rxjs/operators';
import { Observable, of, throwError } from 'rxjs';
import { Title } from '@angular/platform-browser';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';

@Injectable({
  providedIn: 'root',
})
export class AppContextService {
  constructor(
    private _http: HttpClient,
    private _title: Title,
    private _router: Router,
    private _activatedRoute: ActivatedRoute
  ) {}

  private _appContext: any;

  get(context: string): any {
    return _get(this._appContext, context);
  }

  load(configPath: string): Observable<any> {
    return this._http.get(`./assets/config${configPath}/studio.json`).pipe(
      mergeMap((res) => {
        this._appContext = this.merge(res, STUDIOJS.default);

        for (const [key, value] of Object.entries(res)) {
          if (value.hasOwnProperty('__$$selfUrl')) {
            return this.getSelfJson(
              this._appContext,
              value['__$$selfUrl'],
              key
            );
          }

          if (_some(value, '__$$selfUrl')) {
            const childWithSelfUrl = this.childHasSelfUrl(value, key);
            const selfUrl = _get(
              this._appContext,
              `${childWithSelfUrl}.__$$selfUrl`
            );
            return this.getSelfJson(
              this._appContext,
              selfUrl,
              childWithSelfUrl
            );
          }
        }

        return of(this._appContext);
      }),
      catchError((err: any) => {
        return throwError(err);
      })
    );
  }

  private merge(jsonObject: any, jsObject: any): any {
    let mergedObj: any = {};
    if (jsObject && jsonObject) {
      mergedObj = _merge(jsonObject, jsObject);
    } else if (jsObject) {
      mergedObj = jsObject;
    } else if (jsonObject) {
      mergedObj = jsonObject;
    }

    return mergedObj;
  }

  private childHasSelfUrl(obj, parentKey) {
    for (const [key, value] of Object.entries(obj)) {
      if (value.hasOwnProperty('__$$selfUrl')) {
        return `${parentKey}.${key}`;
      }
    }
    return parentKey;
  }

  private getSelfJson(
    appContext: any,
    path: string,
    key: string
  ): Observable<any> {
    return this._http.get(path).pipe(
      tap((partnerJson) => {
        if (partnerJson.hasOwnProperty('__$$defaultUrl')) {
          this.getDefaultJson(partnerJson['__$$defaultUrl']).then(
            (defaultJson) => {
              delete partnerJson['__$$defaultUrl'];
              const combinedSelfJson = Object.assign(defaultJson, partnerJson);
              _set(appContext, key, combinedSelfJson);
            }
          );
        } else {
          _set(appContext, key, partnerJson);
        }
      })
    );
  }

  private getDefaultJson(path: string) {
    return this._http.get(path).toPromise();
  }

  trackRouterEvents(): void {
    this._router.events
      .pipe(
        filter((event) => event instanceof NavigationEnd),
        map(() => this._activatedRoute),
        map((route) => {
          while (route.firstChild) {
            route = route.firstChild;
          }
          return route;
        }),
        filter((route) => route.outlet === 'primary'),
        mergeMap((route) => route.data)
      )
      .subscribe((event) => this.setTitle(event['title']));
  }

  setTitle(title: string): void {
    const appTitle = `${this.get(`common.documentTitle`)} ${
      title ? `- ${title}` : ''
    }`;
    this._title.setTitle(appTitle);
  }
}
