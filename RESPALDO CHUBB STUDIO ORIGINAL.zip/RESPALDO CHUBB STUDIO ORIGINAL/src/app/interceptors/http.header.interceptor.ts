import { Injectable } from '@angular/core';
import {
  HttpEvent,
  HttpRequest,
  HttpHandler,
  HttpInterceptor,
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { AppContextService } from '../app.context.service';
import { IDictionary } from '../models/dictionary.model';
import { environment } from '../../environments/environment';

@Injectable()
export class HttpHeaderInterceptor implements HttpInterceptor {
  constructor(private _appContext: AppContextService) {}

  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    // Headers from studio.json
    const staticHeaders: IDictionary<string> =
      this._appContext.get('httpHeaders') || {};
    staticHeaders['Ocp-Apim-Subscription-Key'] =
      environment.app360ApiSupscriptionKey;
    const authReq = req.clone({
      setHeaders: staticHeaders,
    });
    return next.handle(authReq);
  }
}
