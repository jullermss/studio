import {
  CommonModule,
  DatePipe,
  Location,
  LocationStrategy,
  PathLocationStrategy,
} from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {
  ErrorHandler,
  LOCALE_ID,
  NgModule,
  NgModuleFactoryLoader,
  SystemJsNgModuleLoader,
} from '@angular/core';
import {
  CRUX_APP_BUILD,
  CRUX_LOCALE_DATA,
  FooterModule,
} from '@crux/components';

// Required for Touch functionality of CRUX Components
import 'hammerjs';
import { AppComponent } from './app.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import {
  HttpClient,
  HTTP_INTERCEPTORS,
  HttpClientModule,
} from '@angular/common/http';
import {
  cruxHttpClient,
  CruxHttpClientService,
  CustomTimingService,
  AnalyticsModule,
  GoogleTagManagerService,
  ApplicationInsightsService,
} from '@crux/services';
import { environment } from '../environments/environment';
import { StoreModule } from '@ngrx/store';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { initialState } from './app.state';
import { AppContextService } from './app.context.service';
import { LoadingService } from './components/shared/loading/loading.service';
import { LoadingModule } from './components/shared/loading/loading.module';
/**
 * @todo @studio/{components,services, layout, interceptors} failed to work.
 * Need to figure out why.
 */
import { ComponentsModule, AppNavbarModule } from './components';
import { AuthenticationGuard } from './authentication';
import { LayoutModule } from './layout';
import { HttpHeaderInterceptor } from './interceptors';
import { EffectsModule } from '@ngrx/effects';
import { LoadingIndicatorEffects } from './state/effects';
import { StudioUriPatternFactory } from './factories/studio-uri-pattern.factory';
import {
  studioLocale,
  StudioLocaleFactory,
  studioLocaleId,
} from './factories/studio-locale.factory';
import { ToastModule } from './components/shared/toast/toast.module';
import { StudioErrorHandler } from './error-handlers/studio.error-handler';
import { FlexLayoutModule } from '@angular/flex-layout';
import { STUDIO_BASE_HREF } from './constants/studio-base-href';
import {
  loadingIndicatorReducer,
  sectionsReadyReducer,
  studioAppsyReducer,
} from './state/reducers';
import { RouteGuard, AppContextGuard } from './guards';
import { authReducer } from './state/reducers/auth.reducer';
import { quoteReducer } from './state/reducers/quote.reducer';
import { QuoteEffects } from './state/effects/quote.effects';
import { storageReducer } from './state/reducers/storage.reducer';
import { planReducer } from './state/reducers/plan.reducer';
import { PlanEffects } from './state/effects/plan.effects';
import { redirectToReducer } from './state/reducers/redirect.reducer';
import { RedirectToEffects } from './state/effects/redirect.effects';
import { StorageEffects } from './state/effects/storage.effects';
import { PhoneDetailsEffects } from './state/effects/phone-details.effects';
import { phoneDetailsReducer } from './state/reducers/phone-details.reducer';
import { AuthEffects } from './state/effects/auth.effects';
import { errorReducer } from './state/reducers/error.reducer';
import { NgxViacepModule } from '@brunoc/ngx-viacep';
import { policyReducer } from './state/reducers/policy.reducer';
import { WINDOW_PROVIDERS } from './services/window.service';
import { PlatformModule } from '@angular/cdk/platform';
import { PolicyEffect } from './state/effects/policy.effect';
import { PipesModule } from './pipes/pipes.module';
import { HttpErrorResponseInterceptor } from './interceptors/http.error.response.interceptor';

export function baseHrefFactory() {
  const numberOfParams = 6;
  const pathName = window.location.pathname.split('/');

  return (
    '/' +
    (pathName.length >= numberOfParams
      ? pathName.slice(1, numberOfParams).join('/')
      : '')
  );
}

export const baseHrefProviders = [
  {
    provide: STUDIO_BASE_HREF,
    useFactory: baseHrefFactory,
  },
];

export const httpInterceptorProviders = [
  {
    provide: HTTP_INTERCEPTORS,
    useClass: HttpHeaderInterceptor,
    multi: true,
  },
  {
    provide: HTTP_INTERCEPTORS,
    useClass: HttpErrorResponseInterceptor,
    multi: true,
  },
];

@NgModule({
  declarations: [AppComponent],
  imports: [
    CommonModule,
    BrowserAnimationsModule,
    BrowserModule,
    FlexLayoutModule,
    NgxViacepModule,
    ToastModule,
    PipesModule,
    // Re-engineered app modules
    LayoutModule,

    // App Modules
    ComponentsModule,
    FooterModule,
    AppNavbarModule,
    ReactiveFormsModule,
    FormsModule,
    AppRoutingModule.forRoot(),
    // Analytics Module for instrumenting events
    AnalyticsModule.forRoot(
      [GoogleTagManagerService, ApplicationInsightsService],
      {
        applicationInsights: {
          instrumentationKey: environment.appInsightsInstrumentationKey,
        },
      }
    ),

    /**
     * store imports
     */

    StoreModule.forRoot(
      {
        apps: studioAppsyReducer,
        auth: authReducer,
        loadingIndicator: loadingIndicatorReducer,
        plan: planReducer,
        error: errorReducer,
        policy: policyReducer,
        quote: quoteReducer,
        redirectTo: redirectToReducer,
        phoneDetails: phoneDetailsReducer,
        storage: storageReducer,
        sectionsReady: sectionsReadyReducer,
      },
      { initialState }
    ),
    // @todo make it only for dev
    StoreDevtoolsModule.instrument({
      maxAge: 25,
    }),
    LoadingModule,
    HttpClientModule,
    EffectsModule.forRoot([
      AuthEffects,
      LoadingIndicatorEffects,
      QuoteEffects,
      PhoneDetailsEffects,
      PlanEffects,
      PolicyEffect,
      StorageEffects,
      RedirectToEffects,
      StorageEffects,
    ]),
    PlatformModule,
  ],
  providers: [
    AppContextGuard,
    WINDOW_PROVIDERS,
    AuthenticationGuard,
    Location,
    { provide: LocationStrategy, useClass: PathLocationStrategy },
    StudioUriPatternFactory,
    StudioLocaleFactory,
    RouteGuard,
    AppContextGuard,
    {
      provide: LOCALE_ID,
      deps: [AppContextService],
      useFactory: studioLocaleId,
    },
    {
      provide: CRUX_LOCALE_DATA,
      deps: [AppContextService],
      useFactory: studioLocale,
    },
    { provide: CRUX_APP_BUILD, useValue: { platform: 'DESKTOP' } },
    baseHrefProviders,
    httpInterceptorProviders,
    LoadingService,

    /**
     * Claims
     */
    DatePipe,
    CustomTimingService,
    {
      provide: CruxHttpClientService,
      useFactory: cruxHttpClient,
      deps: [HttpClient],
    },
    // For lazy loading modules
    { provide: NgModuleFactoryLoader, useClass: SystemJsNgModuleLoader },
    { provide: ErrorHandler, useClass: StudioErrorHandler },
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
