import { IPlanModel } from '@studio/models/plan.model';

export interface IStorageDetails {
  storage: string;
  storageValue: string;
  storageMeasurement: string;
  planDetails: IPlanModel;
}
