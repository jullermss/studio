export interface IAddressForm {
  cpf: IAddresFormInput;
  cep: IAddresFormInput;
  complement: IAddresFormInput;
  number: IAddresFormInput;
  button: IButtonAddress;
}

export interface IAddresFormInput {
  placeHolder: string;
  requiredText?: string;
  invalidText?: string;
}

export interface IButtonAddress {
  buttonText: string;
}
