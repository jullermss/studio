export interface IErrorCustom {
  title: string;
  code: string;
  errorSvg: string;
  errorTryLater: string;
  buttonText: string;
  nextWidget: string;
}

export interface ICurrentError {
  code: string;
}
