import { IStorageDetails } from './storage-details.model';

export interface IQuoteModel {
  id: string;
  make: string;
  model: string;
  availableStorage: IStorageDetails[];
}
