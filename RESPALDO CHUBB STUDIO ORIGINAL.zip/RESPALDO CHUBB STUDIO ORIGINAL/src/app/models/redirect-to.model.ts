import { NavigationExtras } from '@angular/router';

export interface IRedirectToModel {
  routeName: string;
  extraOptions?: NavigationExtras;
}
