import { IBenefit } from '@studio/models/benefit.model';
import { ICoverage } from '@studio/models/coverage.model';
import { IDictionary } from '@studio/models/dictionary.model';

export interface IPlanModel {
  name: string;
  description: string;
  totalPremiumValue: string;
  maxCoverageValue: string;
  premiumFrequency: string;
  coverages: ICoverage[];
  benefits: IBenefit[];
}
