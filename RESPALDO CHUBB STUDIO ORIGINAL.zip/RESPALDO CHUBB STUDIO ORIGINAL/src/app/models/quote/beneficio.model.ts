export interface Beneficio {
    nombre: string;
    montoOpcion1: string;
    montoOpcion2: string;
}