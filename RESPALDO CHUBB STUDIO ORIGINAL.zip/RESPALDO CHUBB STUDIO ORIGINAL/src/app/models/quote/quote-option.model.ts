export interface QuoteOptionModel {
    planName: string;
    daysOfCoverage: number;
    totalAmount: string;
    UFAmount: string;
}