export interface IGetQuoteRequestModel {
  imei: string;
  campaign?: string;
}
