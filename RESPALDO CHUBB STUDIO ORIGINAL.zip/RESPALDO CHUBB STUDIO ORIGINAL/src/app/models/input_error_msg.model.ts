export interface IErrorInputMsg {
    required_error_text: string;
    invalid_error_text: string;
}
