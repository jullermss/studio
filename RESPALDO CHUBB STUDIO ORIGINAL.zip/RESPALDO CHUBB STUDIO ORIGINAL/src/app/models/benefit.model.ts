export interface IBenefit {
  name: string;
  title: string;
  subtitle?: string;
  description: string;
}
