import { IUserModel } from './user.model';

export interface IAuthModel {
  token: string;
  isAuthenticated: boolean;
  expires: string;
  statusCode: string;
  user: IUserModel;
}
