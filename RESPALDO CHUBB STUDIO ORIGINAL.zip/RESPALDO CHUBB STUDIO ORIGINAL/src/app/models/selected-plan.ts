import { ICoverage } from './coverage.model';
import { IBenefit } from './benefit.model';

export interface ISelectedPlanModel {
  quoteId: string;
  make: string;
  model: string;
  storageValue: string;
  storageMeasurement: string;
  totalPremiumValue: string;
  maxCoverageValue: string;
  premiumFrequency: string;
  coverages: ICoverage[];
  benefits?: IBenefit[];
}
