export interface IUserModel {
  firstName: string;
  lastName: string;
  email: string;
  dateOfBirth: string;
  codeValidationError: boolean;
}
