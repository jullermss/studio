export interface IBackgroundImage {
  url: string;
  text: string;
}
