export interface IAddress {
  country: string;
  state: string;
  city: string;
  zipCode: string;
  addressLine1: string;
  addressLine2?: string;
  fullAddress?: string;
}

export interface IAddressBrazil extends IAddress {
  neighborhood: string;
  complement?: string;
  number?: string;
}

export class AddressBrazil implements IAddressBrazil {
  neighborhood: string;
  complement: string;
  number: string;
  addressLine1: string;
  addressLine2: string;
  city: string;
  country: string;
  state: string;
  zipCode: string;

  constructor(data?: IAddressBrazil) {
    Object.assign(this, data);
  }
}

export enum Country2DigitsEnum {
  BRAZIL = 'BR',
}
