export interface thankYouHero {
    heroTitle: string;
    heroText: string;
    heroBtn: string;
    heroBtnLink: string;
}
