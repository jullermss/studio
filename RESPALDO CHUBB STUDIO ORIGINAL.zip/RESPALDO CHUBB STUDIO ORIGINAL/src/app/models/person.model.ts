import { IAddressBrazil } from './address-brasil.model';

export interface IPersonModel {
  firstName?: string;
  lastName?: string;
  email?: string;
  dateOfBirth?: string;
  phone?: string;
  uniqueIdentifier?: string;
  address: IAddressBrazil;
}
export class PersonModel implements IPersonModel {
  firstName: string;
  lastName: string;
  email: string;
  dateOfBirth: string;
  phone: string;
  uniqueIdentifier?: string;
  address: IAddressBrazil;
  constructor(data?: IPersonModel) {
    Object.assign(this, data);
  }
}
