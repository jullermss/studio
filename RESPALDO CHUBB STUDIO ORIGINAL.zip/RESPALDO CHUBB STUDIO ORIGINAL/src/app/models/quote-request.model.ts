export interface IQuoteRequestModel {
  imei: string;
  campaign?: string;
}
