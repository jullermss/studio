export interface ICoverageIcon {
  name: string;
  icon: string;
}
