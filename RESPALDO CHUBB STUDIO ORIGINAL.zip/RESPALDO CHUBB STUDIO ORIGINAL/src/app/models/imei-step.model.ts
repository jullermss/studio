

export interface IImeiStep {
    step: string;
}
