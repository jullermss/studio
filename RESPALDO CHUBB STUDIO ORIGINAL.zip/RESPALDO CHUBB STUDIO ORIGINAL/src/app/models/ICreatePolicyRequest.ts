import { IPersonModel } from './person.model';

export interface ICreatePolicyRequest {
  policyHistoryId?: string;
  quoteHistoryId: string;
  phoneStorage: string;
  insured: IPersonModel;
}
