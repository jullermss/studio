export interface homeInsurancePhones {
    title: string;
    asistence: string;
    asistencePhone: string;
    sinister: string;
    sinisterPhone: string;

}
