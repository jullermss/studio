export interface homeForm {
    compraBtn: compraBtn;

}

export interface compraBtn {
    text: string;
    nextWidget: string;

}
