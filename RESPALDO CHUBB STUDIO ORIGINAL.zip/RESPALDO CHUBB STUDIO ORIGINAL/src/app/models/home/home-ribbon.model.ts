export interface homeRibbon {
    title: string;
    description: string;

}
