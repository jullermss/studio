export interface homeCoverageRequirement {
    logoClass: string;
    title: string;
    description: string;
    list: any;
    footerDescription: string;
}
