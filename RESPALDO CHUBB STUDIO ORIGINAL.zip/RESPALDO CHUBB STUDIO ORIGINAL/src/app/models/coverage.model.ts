export interface ICoverage {
  name: string;
  description: string;
  title: string;
  subtitle?: string;
  deductibleValue?: string;
  isPrincipal?: boolean;
}
