export interface IQuotePage {

}
