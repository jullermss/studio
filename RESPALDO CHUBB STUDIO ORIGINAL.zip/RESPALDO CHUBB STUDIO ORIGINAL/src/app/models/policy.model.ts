import { IPlanModel } from './plan.model';
import { IPersonModel } from './person.model';
import { ISelectedPlanModel } from '@studio/models/selected-plan';
import { IAddressBrazil } from '@studio/models/address-brasil.model';
import { ICreatePolicyResponse } from '@studio/models/ICreatePolicyResponse';

export interface IPolicyModel {
  quoteId: string;
  phoneStorage: string;
  personInfo: IPersonModel;
  policyValidationResponse?: ICreatePolicyResponse;
}

export class PolicyModel implements IPolicyModel {
  quoteId: string;
  phoneStorage: string;
  personInfo: IPersonModel;
  constructor(
    quoteId?: string,
    phoneStorage?: string,
    personInfo?: IPersonModel
  ) {
    this.quoteId = quoteId;
    this.phoneStorage = phoneStorage;
    this.personInfo = personInfo;
  }
}
