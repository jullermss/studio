export interface IApiResponse {
  id: string;
  date: Date;
  isSuccessStatusCode: boolean;
  statusCode: IStatusCode;
  data: string | object;
}

export interface IStatusCode {
  code: string;
  message: string;
}
