export interface IPhoneDetails {
  make: string;
  model: string;
  platform: string;
  imei?: string;
  storage?: string;
  language: string;
  phoneNumber: string;
}
