export interface ICreatePolicyResponse {
  id: string;
  dateUtc: Date;
  isSuccessStatusCode: boolean;
  status: IStatusCode;
  data: any;
}

export interface IStatusCode {
  code: string;
  message: string;
}
