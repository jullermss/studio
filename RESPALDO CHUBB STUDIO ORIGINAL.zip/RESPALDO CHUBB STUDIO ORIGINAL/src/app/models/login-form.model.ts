export interface ILoginForm {
  email: IEmailInput;
  pass: IPasswordInput;
  repass: IPasswordInput;
  button: IButtonLogin;
  forgotPass: IForgotPass;
  begin: IBeginLink;
}

export interface IEmailInput {
  placeHolder: string;
  requiredText: string;
  invalidText: string;
}
export interface IPasswordInput {
  placeHolder: string;
  requiredText: string;
  invalidText: string;
  passwordNoMatch?: string;
  passHint?: IPasswordHint;
}

export interface IButtonLogin {
  buttonText: string;
}

export interface IForgotPass {
  text: string;
}

export interface IBeginLink {
  text: string;
  textLink: string;
  nextWidget: string;
}

export interface IPasswordHint {
  header?: string;
  number?: string;
  upperCase?: string;
  length?: string;
  special?: string;
}
