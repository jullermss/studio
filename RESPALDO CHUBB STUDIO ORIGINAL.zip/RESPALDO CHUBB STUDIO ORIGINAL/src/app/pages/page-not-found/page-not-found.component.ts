import { Component, Input } from '@angular/core';
import { NavigationButton } from '../../../../projects/studio-widgets/src/lib//shared/navigation-button/navigation-button.model';
import { CardIcon } from '../../../../projects/studio-widgets/src/lib/shared/card/card-icon.model';
import { CardImage } from '../../../../projects/studio-widgets/src/lib/shared/card/card-image.model';

@Component({
  selector: 'studio-page-not-found',
  templateUrl: './page-not-found.component.html',
  styleUrls: ['./page-not-found.component.scss'],
})
export class PageNotFoundComponent {
  @Input()
  image: CardImage = {
    url: 'assets/images/page-not-found.png',
    position: 'top',
  };

  @Input() navigationLinks: NavigationButton[];

  @Input()
  icon: CardIcon = {
    url: './assets/icons/claims_icon.svg',
    position: 'top-left',
  };

  @Input() pageNotFoundTitle = `It's empty in here!`;

  @Input()
  pageNotFoundTitleDescription =
    'We are unable to find what you are looking for..';

  constructor() {}
}
