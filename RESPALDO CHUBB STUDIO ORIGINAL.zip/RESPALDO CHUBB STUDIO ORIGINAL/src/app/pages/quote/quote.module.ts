import { NgModule } from "@angular/core";
import { QuotePageComponent } from "./quote.component";
import { CommonModule } from "@angular/common";
import { QuoteRoutingModule } from "./quote-routing.module";
import { SectionModule } from '../../components/shared/section/section.module';

@NgModule({
    imports: [
        CommonModule, 
        QuoteRoutingModule,
        SectionModule
    ],
    declarations: [QuotePageComponent],
    exports: [QuotePageComponent]
})
export class QuotePageModule {}