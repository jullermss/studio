import { AppContextService } from '../../app.context.service';
import { Section } from '../../components/shared/section/section.model';
import { OnInit, Component, ViewEncapsulation, Inject } from "@angular/core";
import { STUDIO_BASE_HREF } from '@studio/constants/studio-base-href';

@Component({
    selector: 'studio-quote',
    templateUrl: './quote.component.html',
    styleUrls: ['./quote.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class QuotePageComponent implements OnInit {
    private _sections: Section[];
    
    get sections(): Section[] {
        if (!this._sections) {
            this._sections = this._appContext.get('pages.quotePage.sections');
        }
        return this._sections;
    }

    constructor(
        private _appContext: AppContextService,
        @Inject(STUDIO_BASE_HREF) private _baseHref
    ) {}

    ngOnInit() {
        console.dir(this._sections);
    }
}