import { ICoverage } from '../../../models/coverage.model';

export interface IPlanDetailsModel {
  phoneModel: string;
  planPrice: number;
  coverages: string[];
}
