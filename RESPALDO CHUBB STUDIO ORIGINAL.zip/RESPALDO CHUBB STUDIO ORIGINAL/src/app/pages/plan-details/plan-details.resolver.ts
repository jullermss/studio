import { Injectable } from '@angular/core';
import {
  Resolve,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
} from '@angular/router';
import { Observable, of } from 'rxjs';
import { IPlanDetailsModel } from './plan-details-models/plan-details.model';
import { StudioState } from '../../state/intial-state';
import { Store } from '@ngrx/store';
import { LoadPlansAction } from '../../state/actions/plan-details.action';
import { IQuoteModel } from '../../models/quote.model';
import { RedirectToAction } from '../../state/actions/redirect.action';

@Injectable({
  providedIn: 'root',
})
export class PlanDetailsResolver implements Resolve<boolean> {
  storage: any;
  quote: IQuoteModel;
  constructor(private _store: Store<StudioState>) {
    this._store.select('storage').subscribe((storage) => {
      this.storage = storage;
    });
    this._store.select('quote').subscribe((quote) => {
      this.quote = quote;
    });
  }

  resolve(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<boolean> | Promise<boolean> | boolean {
    if (Object.getOwnPropertyNames(this.quote).length === 0) {
      console.log('The quote is empty:');
      this._store.dispatch(new RedirectToAction({ routeName: 'initial-page' }));
    } else if (!this.storage) {
      console.log('The storage is empty:');
      this._store.dispatch(
        new RedirectToAction({ routeName: 'choose-storage' })
      );
    } else {
      this._store.dispatch(new LoadPlansAction(this.quote, this.storage));
      console.log('listen the quote state:', this.quote);
      return of(true);
    }
    return of(false);
  }
}
