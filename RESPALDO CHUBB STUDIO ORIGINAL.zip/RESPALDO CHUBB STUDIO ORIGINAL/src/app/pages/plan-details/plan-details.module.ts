import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PlanDetailsComponent } from './plan-details/plan-details.component';
import { SectionModule } from '../../components/shared/section';
import { PlanDetailsRoutingModule } from './plan-details-routing.module';

@NgModule({
  declarations: [PlanDetailsComponent],
  exports: [PlanDetailsComponent],
  imports: [CommonModule, SectionModule, PlanDetailsRoutingModule],
})
export class PlanDetailsModule {}
