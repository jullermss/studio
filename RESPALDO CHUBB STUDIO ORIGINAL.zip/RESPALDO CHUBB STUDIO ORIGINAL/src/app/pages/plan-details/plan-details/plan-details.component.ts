import { Component, OnInit } from '@angular/core';
import { Section } from '../../../components/shared/section';
import { AppContextService } from '../../../app.context.service';
import { ContainerBase } from '../../../components';
import { WidgetOutputEvent } from '../../../components/shared/widget/widget-output-event.model';
import { RedirectToAction } from '../../../state/actions/redirect.action';
import { Store } from '@ngrx/store';
import { StudioState } from '../../../state/intial-state';
import { LoadingIndicatorHideAction } from '../../../state/actions';

@Component({
  selector: 'studio-plan-details',
  templateUrl: './plan-details.component.html',
  styleUrls: ['./plan-details.component.scss'],
})
export class PlanDetailsComponent extends ContainerBase implements OnInit {
  private _sections: Section[];

  get sections(): Section[] {
    if (!this._sections) {
      this._sections = this._appContext.get('pages.planDetails.sections');
    }

    return this._sections;
  }

  constructor(
    private _appContext: AppContextService,
    private _store: Store<StudioState>
  ) {
    super();
  }

  ngOnInit() {}
  _handleWidgetAction(action: { widgetName: string; data: WidgetOutputEvent }) {
    const { type: widgetEventType, payload } = action.data;

    switch (widgetEventType) {
      case 'ADD_NEW_STUDIO_APP':
        break;
      case 'GO_BACK':
        this._store.dispatch(
          new RedirectToAction({ routeName: payload.previousWidget })
        );
        break;
      case 'GO_NEXT':
        this._store.dispatch(
          new RedirectToAction({ routeName: payload.nextWidget })
        );
        break;
      case 'HIDE_LOADING':
        this._store.dispatch(new LoadingIndicatorHideAction(true));
        break;
      default:
        console.error(`Can't handle ${widgetEventType} event`);
    }
  }
}
