import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SectionModule } from '../../components/shared/section';
import { PersonInfoRoutingModule } from './person-info.routing.module';
import { PersonInfoComponent } from './person-info.component';

@NgModule({
  imports: [CommonModule, PersonInfoRoutingModule, SectionModule],
  declarations: [PersonInfoComponent],
  exports: [PersonInfoComponent],
})
export class PersonInfoModule {}
