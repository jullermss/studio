import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { ContainerBase } from '../../components';
import { Section } from '../../components/shared/section';
import { AppContextService } from '../../app.context.service';
import { StudioState } from '../../state/intial-state';
import { WidgetOutputEvent } from '../../components/shared/widget/widget-output-event.model';
import { RedirectToAction } from '../../state/actions/redirect.action';
import { UpdatePersonInfo } from '../../state/actions/policy.action';

@Component({
  selector: 'studio-person-info',
  templateUrl: './person-info.component.html',
  styleUrls: ['./person-info.component.scss'],
})
export class PersonInfoComponent extends ContainerBase implements OnInit {
  private _sections: Section[];

  constructor(
    private _appContext: AppContextService,
    private _store: Store<StudioState>
  ) {
    super();
  }

  ngOnInit() {}

  get sections(): Section[] {
    if (!this._sections) {
      this._sections = this._appContext.get('pages.personInfo.sections');
    }

    return this._sections;
  }

  _handleWidgetAction(action: { widgetName: string; data: WidgetOutputEvent }) {
    const { type: widgetEventType, payload } = action.data;
    switch (widgetEventType) {
      case 'GO_BACK':
        console.log('registration');
        this._store.dispatch(
          new RedirectToAction({ routeName: payload.previousWidget })
        );
        break;
      case 'SAVE_PERSON_INFO':
        this._store.dispatch(new UpdatePersonInfo(payload));
        this._store.dispatch(new RedirectToAction({ routeName: 'address-page' }));
        break;
      default:
        console.error(`Can't handle ${widgetEventType} event`);
    }
  }
}
