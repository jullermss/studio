import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';
import { StudioState } from '../../state/intial-state';
import { Observable, of } from 'rxjs';
import { LoadInitialState } from '../../state/actions/person-info.actions';
import {
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  Resolve,
} from '@angular/router';

@Injectable({
  providedIn: 'root',
})
export class PersonInfoResolver implements Resolve<boolean> {
  constructor(private _store: Store<StudioState>) {}

  resolve(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<boolean> | Promise<boolean> | boolean {
    this._store.dispatch(new LoadInitialState());
    return of(true);
  }
}
