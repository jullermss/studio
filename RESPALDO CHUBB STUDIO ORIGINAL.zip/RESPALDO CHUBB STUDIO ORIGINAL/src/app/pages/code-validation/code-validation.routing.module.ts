import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CodeValidationComponent } from './code-validation.component';

const routes: Routes = [
  {
    path: '',
    component: CodeValidationComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CodeValidationRoutingModule {}
