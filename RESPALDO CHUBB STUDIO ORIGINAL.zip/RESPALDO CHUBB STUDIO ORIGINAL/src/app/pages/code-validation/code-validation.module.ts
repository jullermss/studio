import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CodeValidationRoutingModule } from './code-validation.routing.module';
import { CodeValidationComponent } from './code-validation.component';
import { SectionModule } from '../../components/shared/section';

@NgModule({
  imports: [CommonModule, CodeValidationRoutingModule, SectionModule],
  declarations: [CodeValidationComponent],
  exports: [CodeValidationComponent],
})
export class CodeValidationModule {}
