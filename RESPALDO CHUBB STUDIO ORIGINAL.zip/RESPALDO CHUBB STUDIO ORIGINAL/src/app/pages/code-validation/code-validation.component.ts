import { Component, OnInit } from '@angular/core';
import { Section } from '../../components/shared/section';
import { AppContextService } from '../../app.context.service';
import { ContainerBase } from '../../components';
import { Store } from '@ngrx/store';
import { StudioState } from '../../state/intial-state';
import { WidgetOutputEvent } from '../../components/shared/widget/widget-output-event.model';
import { ValidateCodeAction } from '../../state/actions/auth.actions';
import { RedirectToAction } from '../../state/actions/redirect.action';
import { UpdateIMEIAction } from '../../state/actions/phone-details.action';
import { EvaHelperService } from '../../services/eva-helper.service';

@Component({
  selector: 'studio-code-validation',
  templateUrl: './code-validation.component.html',
  styleUrls: ['./code-validation.component.scss'],
})
export class CodeValidationComponent extends ContainerBase implements OnInit {
  private _sections: Section[];

  constructor(
    private _appContext: AppContextService,
    private _store: Store<StudioState>,
    private _eva: EvaHelperService
  ) {
    super();
  }

  async ngOnInit() {
    try {
      await this._eva.getIMEI();
    } catch (e) {
      console.warn(`Failed to get IMEI `, e);
    }
  }

  get sections(): Section[] {
    if (!this._sections) {
      this._sections = this._appContext.get('pages.codeValidation.sections');
    }

    return this._sections;
  }

  _handleWidgetAction(action: { widgetName: string; data: WidgetOutputEvent }) {
    const { type: widgetEventType, payload } = action.data;

    switch (widgetEventType) {
      case 'VALIDATE_CODE':
        this._store.dispatch(new ValidateCodeAction(payload.code));
        if (payload.imei) {
          this._store.dispatch(new UpdateIMEIAction(payload.imei));
        }
        break;
      case 'GO_BACK':
        this._store.dispatch(
          new RedirectToAction({ routeName: payload.previousWidget })
        );
        break;
      default:
        console.error(`Can't handle ${widgetEventType} event`);
    }
  }
}
