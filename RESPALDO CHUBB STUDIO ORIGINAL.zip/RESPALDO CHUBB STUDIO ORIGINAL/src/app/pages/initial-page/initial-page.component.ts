import { Component, OnInit } from '@angular/core';
import { Section } from '../../components/shared/section';
import { AppContextService } from '../../app.context.service';
import { ContainerBase } from '../../components';
import { WidgetOutputEvent } from '../../components/shared/widget/widget-output-event.model';
import { Store } from '@ngrx/store';
import { StudioState } from '../../state/intial-state';
import { RedirectToAction } from '../../state/actions/redirect.action';

@Component({
  selector: 'studio-initial-page',
  templateUrl: './initial-page.component.html',
  styleUrls: ['./initial-page.component.scss'],
})
export class InitialPageComponent extends ContainerBase implements OnInit {
  private _sections: Section[];

  get sections(): Section[] {
    if (!this._sections) {
      this._sections = this._appContext.get('pages.initialPage.sections');
    }

    return this._sections;
  }

  constructor(
    private _appContext: AppContextService,
    private _store: Store<StudioState>
  ) {
    super();
  }

  ngOnInit() {}

  _handleWidgetAction(action: { widgetName: string; data: WidgetOutputEvent }) {
    const { type: widgetEventType, payload } = action.data;
    switch (widgetEventType) {
      case 'GO_TO_BEGIN':
        this._store.dispatch(
          new RedirectToAction({ routeName: payload.beginRoute })
        );
        break;
      case 'GO_TO_LOGIN':
        this._store.dispatch(
          new RedirectToAction({ routeName: payload.logInRoute })
        );
        break;
      default:
        console.error(`Can't handle ${widgetEventType} event`);
    }
  }
}
