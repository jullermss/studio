import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InitialPageComponent } from './initial-page.component';
import { SectionModule } from '../../components/shared/section';
import { InitialPageRoutingModule } from './initial-page-routing.module';

@NgModule({
  declarations: [InitialPageComponent],
  exports: [InitialPageComponent],
  imports: [CommonModule, SectionModule, InitialPageRoutingModule],
})
export class InitialPageModule {}
