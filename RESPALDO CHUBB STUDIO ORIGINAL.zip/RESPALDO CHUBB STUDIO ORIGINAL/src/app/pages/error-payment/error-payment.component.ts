import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { ContainerBase } from '../../components';
import { Section } from '../../components/shared/section';
import { AppContextService } from '../../app.context.service';
import { StudioState } from '../../state/intial-state';
import { WidgetOutputEvent } from '../../components/shared/widget/widget-output-event.model';
import { RedirectToAction } from '../../state/actions/redirect.action';

@Component({
  selector: 'studio-error-payment',
  templateUrl: './error-payment.component.html',
  styleUrls: ['./error-payment.component.scss']
})
export class ErrorPaymentComponent implements OnInit {
  private _sections: Section[];

  constructor(
    private _appContext: AppContextService,
    private _store: Store<StudioState>
  ) {}

  ngOnInit() {}

  get sections(): Section[] {
    if (!this._sections) {
      this._sections = this._appContext.get('pages.errorPayment.sections');
    }

    return this._sections;
  }

  _handleWidgetAction(action: { widgetName: string; data: WidgetOutputEvent }) {
    const { type: widgetEventType, payload } = action.data;
    
    /*
    this._store.dispatch(
      new RedirectToAction({
        routeName: payload
      })
    );
    */
  }
  
}
