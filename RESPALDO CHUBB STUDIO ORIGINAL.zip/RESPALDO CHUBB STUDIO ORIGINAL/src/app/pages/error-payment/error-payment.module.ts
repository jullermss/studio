import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SectionModule } from '../../components/shared/section';
import { ErrorPaymentComponent } from './error-payment.component';
import { ErrorPaymentRoutingModule } from './error-payment.routing.module';

@NgModule({
  declarations: [ErrorPaymentComponent],
  imports: [CommonModule, SectionModule, ErrorPaymentRoutingModule],
  exports: [ErrorPaymentComponent],
})
export class ErrorPaymentModule { }
