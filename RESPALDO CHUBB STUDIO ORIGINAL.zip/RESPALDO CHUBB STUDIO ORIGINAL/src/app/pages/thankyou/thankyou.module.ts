import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SectionModule } from '../../components/shared/section';
import { ThankYouComponent } from './thankyou.component';
import { ThankYouRoutingModule } from './thankyou.routing.module';

@NgModule({
  imports: [CommonModule, SectionModule, ThankYouRoutingModule],
  declarations: [ThankYouComponent],
  exports: [ThankYouComponent],
})
export class ThankYouModule {}
