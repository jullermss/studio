import { Component, OnInit } from '@angular/core';
import { Section } from '../../components/shared/section';
import { AppContextService } from '../../app.context.service';
import { ContainerBase } from '../../components';
import { WidgetOutputEvent } from '../../components/shared/widget/widget-output-event.model';
import { Store } from '@ngrx/store';
import { StudioState } from '../../state/intial-state';
import { RedirectToAction } from '../../state/actions/redirect.action';
import { UpdateSelectedStorageAction } from '../../state/actions/storage.action';
import { LoadingIndicatorHideAction } from '../../state/actions';

@Component({
  selector: 'studio-error-page',
  templateUrl: './error-page.component.html',
  styleUrls: ['./error-page.component.scss'],
})
export class ErrorPageComponent extends ContainerBase implements OnInit {
  private _sections: Section[];
  get sections(): Section[] {
    if (!this._sections) {
      this._sections = this._appContext.get('pages.errorPage.sections');
    }

    return this._sections;
  }
  constructor(
    private _appContext: AppContextService,
    private _store: Store<StudioState>
  ) {
    super();
  }

  ngOnInit() {
    this._store.dispatch(new LoadingIndicatorHideAction(true));
  }

  _handleWidgetAction(action: { widgetName: string; data: WidgetOutputEvent }) {
    const { type: widgetEventType, payload } = action.data;

    switch (widgetEventType) {
      case 'GO_BACK':
        console.log(`Goig Back to  `, payload.previousWidget);
        this._store.dispatch(
          new RedirectToAction({ routeName: payload.previousWidget })
        );
        break;
      default:
        console.error(`Can't handle ${widgetEventType} event`);
    }
  }
}
