import { Component, Inject, OnInit, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { AnalyticsService } from '@crux/services';
import { Section } from '../../components/shared/section/section.model';
import { AppContextService } from '../../app.context.service';
import { HomeHeader } from './home-header.model';
import { STUDIO_BASE_HREF } from '@studio/constants/studio-base-href';
import { StudioState } from '../../state/intial-state';
import { Store } from '@ngrx/store';
import { WidgetOutputEvent } from '../../../../src/app/components/shared/widget/widget-output-event.model';
import { RedirectToAction } from '../../state/actions/redirect.action';


@Component({
  selector: 'studio-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class HomeComponent implements OnInit {
  private _sections: Section[];
  private _header: HomeHeader;

  

  get sections(): Section[] {
    if (!this._sections) {
      this._sections = this._appContext.get('pages.home.sections');
    }

    return this._sections;
  }

  constructor(
    private _appContext: AppContextService,
    private router: Router,
    private _store: Store<StudioState>,
    private _analytics: AnalyticsService,
    @Inject(STUDIO_BASE_HREF) private _baseHref
  ) {}

  ngOnInit() {
  
  }

  _handleWidgetAction(action: { widgetName: string; data: WidgetOutputEvent }) {
    const { type: widgetEventType, payload } = action.data;
    console.log(payload);
    this._store.dispatch(
      new RedirectToAction({
        routeName: payload
      })
    );
  }
  
}
