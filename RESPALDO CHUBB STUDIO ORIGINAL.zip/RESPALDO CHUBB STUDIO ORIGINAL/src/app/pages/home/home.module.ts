import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeComponent } from './home.component';
import { HomeRoutingModule } from './home-routing.module';
import { CardModule } from '../../../../projects/studio-widgets/src/lib/shared/card/card.module';
import { SectionModule } from '../../components/shared/section/section.module';
import { NavigationButtonModule } from '../../../../projects/studio-widgets/src/lib/shared/navigation-button/navigation-button.module';
import { IconModule } from '@crux/components';

@NgModule({
  imports: [
    CommonModule,
    CardModule,
    SectionModule,
    HomeRoutingModule,
    NavigationButtonModule,
    IconModule,
  ],
  declarations: [HomeComponent],
  exports: [HomeComponent],
})
export class HomeModule {}
