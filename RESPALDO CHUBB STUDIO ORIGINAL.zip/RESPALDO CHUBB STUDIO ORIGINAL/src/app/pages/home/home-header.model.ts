import { NavigationButton } from '../../../../projects/studio-widgets/src/lib/shared/navigation-button/navigation-button.model';

export interface HomeHeader {
  greetingText: string;
  subheader: string;
  welcomeText: string;
  noAppsText: string;
  navigationLink: NavigationButton;
}
