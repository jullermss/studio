import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EsitefPageComponent } from './esitef-page.component';
import { SectionModule } from '../../components/shared/section';
import { EsitefPageRoutingModule } from './esitef-page-routing.module';

@NgModule({
  declarations: [EsitefPageComponent],
  imports: [CommonModule, SectionModule, EsitefPageRoutingModule],
  exports: [EsitefPageComponent],
})
export class EsitefPageModule {}
