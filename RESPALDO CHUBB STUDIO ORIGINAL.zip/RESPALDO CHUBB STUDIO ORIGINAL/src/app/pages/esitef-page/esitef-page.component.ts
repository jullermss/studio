import { Component, OnInit } from '@angular/core';
import { Section } from '../../components/shared/section';
import { AppContextService } from '../../app.context.service';
import { ContainerBase } from '../../components';
import { WidgetOutputEvent } from '../../components/shared/widget/widget-output-event.model';
import { Store } from '@ngrx/store';
import { StudioState } from '../../state/intial-state';
import { RedirectToAction } from '../../state/actions/redirect.action';
import { Loading } from '@studio/components/shared/loading/loading.model';
import {
  LoadingIndicatorHideAction,
  LoadingIndicatorShowAction,
} from '@studio/state/actions';

@Component({
  selector: 'studio-esitef-page',
  templateUrl: './esitef-page.component.html',
  styleUrls: ['./esitef-page.component.scss'],
})
export class EsitefPageComponent extends ContainerBase implements OnInit {
  private _sections: Section[];
  get sections(): Section[] {
    if (!this._sections) {
      this._sections = this._appContext.get('pages.esitefPage.sections');
    }

    return this._sections;
  }
  constructor(
    private _appContext: AppContextService,
    private _store: Store<StudioState>
  ) {
    super();
  }

  ngOnInit() {}
  _handleWidgetAction(action: { widgetName: string; data: WidgetOutputEvent }) {
    console.log(action);
    const { type: widgetEventType, payload } = action.data;
    switch (widgetEventType) {
      case 'SHOW_LOADING':
        const loading: Loading = {
          title: payload.loadingMsg,
          message: '',
        };
        this._store.dispatch(new LoadingIndicatorShowAction(loading));
        break;
      case 'HIDE_LOADING':
        this._store.dispatch(new LoadingIndicatorHideAction(true));
        break;
      case 'GO_BACK':
        console.log(`Going Back to  `, payload.previousWidget);
        this._store.dispatch(
          new RedirectToAction({ routeName: payload.previousWidget })
        );
        break;
      default:
        console.error(`Can't handle ${widgetEventType} event`);
    }
  }
}
