import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EsitefPageComponent } from './esitef-page.component';

describe('EsitefPageComponent', () => {
  let component: EsitefPageComponent;
  let fixture: ComponentFixture<EsitefPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [EsitefPageComponent],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EsitefPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
