import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginPageComponent } from './login-page.component';
import { SectionModule } from '../../components/shared/section';
import { LoginPageRoutingModule } from './login-page-routing.module';

@NgModule({
  declarations: [LoginPageComponent],
  imports: [CommonModule, SectionModule, LoginPageRoutingModule],
  exports: [LoginPageComponent],
})
export class LoginPageModule {}
