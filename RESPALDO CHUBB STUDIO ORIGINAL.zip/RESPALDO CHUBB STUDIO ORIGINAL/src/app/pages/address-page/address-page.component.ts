import { Component, OnInit } from '@angular/core';
import { Section } from '../../components/shared/section';
import { AppContextService } from '../../app.context.service';
import { ContainerBase } from '../../components';
import { WidgetOutputEvent } from '../../components/shared/widget/widget-output-event.model';
import { Store } from '@ngrx/store';
import { StudioState } from '../../state/intial-state';
import { RedirectToAction } from '../../state/actions/redirect.action';
import { LoadPolicyInfo } from '../../state/actions/policy.action';

@Component({
  selector: 'studio-address-page',
  templateUrl: './address-page.component.html',
  styleUrls: ['./address-page.component.scss'],
})
export class AddressPageComponent extends ContainerBase implements OnInit {
  private _sections: Section[];
  get sections(): Section[] {
    if (!this._sections) {
      this._sections = this._appContext.get('pages.addressPage.sections');
    }

    return this._sections;
  }
  constructor(
    private _appContext: AppContextService,
    private _store: Store<StudioState>
  ) {
    super();
  }

  ngOnInit() {}

  _handleWidgetAction(action: { widgetName: string; data: WidgetOutputEvent }) {
    console.log(action);
    const { type: widgetEventType, payload } = action.data;
    switch (widgetEventType) {
      case 'ADD_NEW_STUDIO_APP':
        break;
      case 'GO_NEXT':
        console.log(`Going next to  `, payload.nextWidget);
        this._store.dispatch(new LoadPolicyInfo(payload.policyObject));
        setTimeout(() => {
          this._store.dispatch(
            new RedirectToAction({ routeName: payload.nextWidget })
          );
        }, 1000);
        break;
      case 'GO_BACK':
        console.log(`Going Back to  `, payload.previousWidget);
        this._store.dispatch(
          new RedirectToAction({ routeName: payload.previousWidget })
        );
        break;
      default:
        console.error(`Can't handle ${widgetEventType} event`);
    }
  }
}
