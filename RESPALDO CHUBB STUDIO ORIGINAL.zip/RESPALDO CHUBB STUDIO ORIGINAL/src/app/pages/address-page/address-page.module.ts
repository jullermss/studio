import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddressPageComponent } from './address-page.component';
import { AddressPageRoutingModule } from './address-page-routing.module';
import { SectionModule } from '../../components/shared/section';
import { NgxViacepService } from '@brunoc/ngx-viacep';

@NgModule({
  declarations: [AddressPageComponent],
  imports: [CommonModule, AddressPageRoutingModule, SectionModule],
  exports: [AddressPageComponent],
})
export class AddressPageModule {}
