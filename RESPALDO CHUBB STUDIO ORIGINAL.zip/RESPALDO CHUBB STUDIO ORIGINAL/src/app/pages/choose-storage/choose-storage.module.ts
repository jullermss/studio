import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ChooseStorageComponent } from './choose-storage.component';
import { ChooseStorageRoutingModule } from './choose-storage-routing.module';
import { SectionModule } from '../../components/shared/section';

@NgModule({
  imports: [CommonModule, SectionModule, ChooseStorageRoutingModule],
  declarations: [ChooseStorageComponent],
  exports: [ChooseStorageComponent],
})
export class ChooseStorageModule {}
