import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ChooseStorageComponent } from './choose-storage.component';
import { RedirectService } from '../../services/redirect.service';

const routes: Routes = [
  {
    path: '',
    component: ChooseStorageComponent,
    data: {
      tile: 'Plan Details',
      routeSettings: {
        name: 'plan-details-1',
      },
    },
  },
];

RedirectService.init(routes);

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ChooseStorageRoutingModule {}
