export interface ChooseStorageModel {
  phoneModel: string;
  storage: string[];
}
