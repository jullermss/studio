import { Injectable } from '@angular/core';
import {
  ActivatedRouteSnapshot,
  Resolve,
  RouterStateSnapshot,
} from '@angular/router';
import { Observable, of } from 'rxjs';
import { Store } from '@ngrx/store';
import { StudioState } from '../../state/intial-state';
import { LoadQuoteAction } from '../../state/actions/quote.action';
import { IPhoneDetails } from '../../models/phone-details.model';
import { UpdateSelectedStorageAction } from '../../state/actions/storage.action';
import {
  RedirectToAction,
  RedirectToActions,
} from '../../state/actions/redirect.action';
import { ICurrentError, IErrorCustom } from '../../models/error.model';
import { UpdateErrorAction } from '../../state/actions/error.action';
import { IQuoteRequestModel } from '../../models/quote-request.model';
import { Loading } from '../../components/shared/loading/loading.model';
import { LoadingIndicatorShowAction } from '../../state/actions';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class ChooseStorageResolver implements Resolve<boolean> {
  phoneDetails: IPhoneDetails;
  errorObject: ICurrentError = {
    code: '001',
  };
  loading: Loading = {
    title: 'Obteniendo quote',
    message: '',
  };
  quoteRequestModel: IQuoteRequestModel;
  constructor(private _store: Store<StudioState>) {
    this._store.select('phoneDetails').subscribe((phoneDetails) => {
      this.phoneDetails = phoneDetails;
    });
  }

  // resolve for resolving the data device before open
  resolve(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<boolean> | Promise<boolean> | boolean {
    if (!this.phoneDetails.imei) {
      console.log('no existe imeil hay que pedirlo ..');
      this._store.dispatch(new LoadingIndicatorShowAction(this.loading));
      this._store.dispatch(new UpdateErrorAction(this.errorObject));
      this._store.dispatch(new RedirectToAction({ routeName: 'error-page' }));
      return false;
    }
    if (!this.phoneDetails.storage) {
      console.log('no hay storage hay que pedirlo ...');
      this._store.dispatch(new LoadingIndicatorShowAction(this.loading));
      this._store.dispatch(
        new LoadQuoteAction(
          (this.quoteRequestModel = { imei: this.phoneDetails.imei }),
          this.phoneDetails.storage
        )
      );
    } else {
      console.log('hay ambos ir directo a plan details');
      // Getting the quote and setting the quote state
      this._store.dispatch(new LoadingIndicatorShowAction(this.loading));
      this._store.dispatch(
        new LoadQuoteAction(
          (this.quoteRequestModel = { imei: this.phoneDetails.imei }),
          this.phoneDetails.storage
        )
      );
    }
    return of(false);
  }
}
