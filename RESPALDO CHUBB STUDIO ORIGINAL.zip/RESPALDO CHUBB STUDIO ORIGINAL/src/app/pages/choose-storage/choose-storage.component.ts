import { Component, OnInit } from '@angular/core';
import { Section } from '../../components/shared/section';
import { AppContextService } from '../../app.context.service';
import { ContainerBase } from '../../components';
import { WidgetOutputEvent } from '../../components/shared/widget/widget-output-event.model';
import { Store } from '@ngrx/store';
import { StudioState } from '../../state/intial-state';
import { UpdateSelectedStorageAction } from '../../state/actions/storage.action';
import { RedirectToAction } from '../../state/actions/redirect.action';
import { IRedirectToModel } from '../../models/redirect-to.model';
import { UpdateErrorAction } from '../../state/actions/error.action';

@Component({
  selector: 'studio-choose-storage',
  templateUrl: './choose-storage.component.html',
  styleUrls: ['./choose-storage.component.scss'],
})
export class ChooseStorageComponent extends ContainerBase implements OnInit {
  private _sections: Section[];

  get sections(): Section[] {
    if (!this._sections) {
      this._sections = this._appContext.get('pages.chooseStorage.sections');
    }

    return this._sections;
  }

  constructor(
    private _appContext: AppContextService,
    private _store: Store<StudioState>
  ) {
    super();
  }

  ngOnInit() {}

  _handleWidgetAction(action: { widgetName: string; data: WidgetOutputEvent }) {
    const { type: widgetEventType, payload } = action.data;

    switch (widgetEventType) {
      case 'UPDATE_CHOSEN_STORAGE':
        this._store.dispatch(
          new UpdateSelectedStorageAction(payload.chosenStorage)
        );
        break;
      case 'GO_BACK':
        console.log(`Goig Back to  `, payload.previousWidget);
        this._store.dispatch(
          new RedirectToAction({ routeName: payload.previousWidget })
        );
        break;
      case 'GO_ERROR':
        this._store.dispatch(new UpdateErrorAction(payload.errorObject));
        this._store.dispatch(new RedirectToAction({ routeName: 'error-page' }));
        break;
      default:
        console.error(`Can't handle ${widgetEventType} event`);
    }
  }
}
