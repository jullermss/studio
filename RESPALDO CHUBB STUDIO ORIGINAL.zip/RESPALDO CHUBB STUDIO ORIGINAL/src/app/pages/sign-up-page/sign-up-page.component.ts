import { Component, OnInit } from '@angular/core';
import { ContainerBase } from '../../components';
import { Section } from '../../components/shared/section';
import { AppContextService } from '../../app.context.service';
import { Store } from '@ngrx/store';
import { StudioState } from '../../state/intial-state';
import { WidgetOutputEvent } from '../../components/shared/widget/widget-output-event.model';
import { RedirectToAction } from '../../state/actions/redirect.action';

@Component({
  selector: 'studio-sign-up-page',
  templateUrl: './sign-up-page.component.html',
  styleUrls: ['./sign-up-page.component.scss'],
})
export class SignUpPageComponent extends ContainerBase implements OnInit {
  private _sections: Section[];
  get sections(): Section[] {
    if (!this._sections) {
      this._sections = this._appContext.get('pages.signUpPage.sections');
    }

    return this._sections;
  }
  constructor(
    private _appContext: AppContextService,
    private _store: Store<StudioState>
  ) {
    super();
  }

  ngOnInit() {}
  _handleWidgetAction(action: { widgetName: string; data: WidgetOutputEvent }) {
    console.log(action);
    const { type: widgetEventType, payload } = action.data;
    switch (widgetEventType) {
      case 'ADD_NEW_STUDIO_APP':
        break;
      case 'GO_NEXT':
        setTimeout(() => {
          this._store.dispatch(
            new RedirectToAction({ routeName: payload.nextWidget })
          );
        }, 2000);
        break;
      case 'GO_BACK':
        console.log(`Going Back to  `, payload.previousWidget);
        this._store.dispatch(
          new RedirectToAction({ routeName: payload.previousWidget })
        );
        break;
      default:
        console.error(`Can't handle ${widgetEventType} event`);
    }
  }
}
