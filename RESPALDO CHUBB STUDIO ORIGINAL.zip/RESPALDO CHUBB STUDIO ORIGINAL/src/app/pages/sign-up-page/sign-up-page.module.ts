import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SignUpPageComponent } from './sign-up-page.component';
import { SignUpPageRoutingModule } from './sign-up-page-routing.module';
import { SectionModule } from '../../components/shared/section';

@NgModule({
  declarations: [SignUpPageComponent],
  imports: [CommonModule, SignUpPageRoutingModule, SectionModule],
  exports: [SignUpPageComponent],
})
export class SignUpPageModule {}
