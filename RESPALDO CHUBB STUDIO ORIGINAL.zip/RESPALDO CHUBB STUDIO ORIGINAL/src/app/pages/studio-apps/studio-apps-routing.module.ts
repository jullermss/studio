import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { StudioAppsComponent } from './studio-apps.component';

const routes: Routes = [
  {
    path: '',
    component: StudioAppsComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class StudioAppsRoutingModule {}
