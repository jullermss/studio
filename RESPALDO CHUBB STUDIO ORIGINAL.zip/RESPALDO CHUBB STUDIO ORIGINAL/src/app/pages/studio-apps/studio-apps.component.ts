import { Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { ContentHeader } from '../../../../projects/studio-widgets/src/lib/widgets/content-header/content-header.model';
import { AppContextService } from '../../app.context.service';
import { Store } from '@ngrx/store';
import { StudioState } from '../../state/intial-state';
import { ContainerBase } from '../../components';
import { Section } from '../../components/shared/section';
import { WidgetOutputEvent } from '../../components/shared/widget/widget-output-event.model';
import { AddStudioAppsSuccessAction } from '../../state/actions';

@Component({
  selector: 'studio-apps',
  templateUrl: './studio-apps.component.html',
  styleUrls: ['./studio-apps.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class StudioAppsComponent extends ContainerBase
  implements OnInit, OnDestroy {
  private _header: ContentHeader;

  private _sections: Section[];

  get sections(): Section[] {
    if (!this._sections) {
      this._sections = this._appContext.get('pages.apps.sections');
    }

    return this._sections;
  }

  get header(): ContentHeader {
    if (!this._header) {
      this._header = this._appContext.get('pages.apps.header');
    }

    return this._header;
  }

  constructor(
    private _appContext: AppContextService,
    private _store: Store<StudioState>
  ) {
    super();
  }

  ngOnInit(): void {}

  ngOnDestroy(): void {}

  private _addNewStudioApp(name: string): void {
    this._store.dispatch(
      new AddStudioAppsSuccessAction({
        name,
      })
    );
  }

  _handleWidgetAction(action: { widgetName: string; data: WidgetOutputEvent }) {
    const { type: widgetEventType, payload } = action.data;

    switch (widgetEventType) {
      case 'ADD_NEW_STUDIO_APP':
        this._addNewStudioApp(payload.name);
        break;
      default:
        console.error(`Can't handle ${widgetEventType} event`);
    }
  }
}
