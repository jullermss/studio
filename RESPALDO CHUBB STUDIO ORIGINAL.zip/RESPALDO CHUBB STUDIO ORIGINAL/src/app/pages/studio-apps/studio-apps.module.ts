import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StudioAppsRoutingModule } from './studio-apps-routing.module';
import { SectionModule } from '../../components/shared/section';
import { ContentHeaderModule } from '../../../../projects/studio-widgets/src/lib/widgets/content-header/content-header.module';
import { StudioAppsComponent } from './studio-apps.component';

@NgModule({
  imports: [
    CommonModule,
    SectionModule,
    ContentHeaderModule,
    StudioAppsRoutingModule,
  ],
  declarations: [StudioAppsComponent],
  exports: [StudioAppsComponent],
})
export class StudioAppsModule {}
