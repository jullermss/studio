export const sectionsReady = {};
