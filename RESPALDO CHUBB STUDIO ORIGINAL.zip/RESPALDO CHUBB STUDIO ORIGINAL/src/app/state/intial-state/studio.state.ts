import { IQuoteModel } from '@studio/models/quote.model';
import { IRedirectToModel } from '@studio/models/redirect-to.model';
import { ISelectedPlanModel } from '@studio/models/selected-plan';
import { IPhoneDetails } from '@studio/models/phone-details.model';
import { IAuthModel } from '@studio/models/auth.model';
import { ICurrentError, IErrorCustom } from '@studio/models/error.model';
import { IPolicyModel } from '@studio/models/policy.model';

export interface StudioState {
  apps: any[];
  auth: IAuthModel;
  error: ICurrentError;
  loadingIndicator: boolean;
  quote: IQuoteModel;
  plan: ISelectedPlanModel;
  phoneDetails: IPhoneDetails;
  redirect: IRedirectToModel;
  policy: IPolicyModel;
  storage: any;
  sectionsReady: any;
}
