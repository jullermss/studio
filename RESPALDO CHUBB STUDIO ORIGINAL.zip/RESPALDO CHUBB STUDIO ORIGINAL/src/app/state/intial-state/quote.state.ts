import { IQuoteModel } from '../../models/quote.model';

export const quoteInitialState = {
  make: 'unknow',
  model: 'unknow',
  availableStorage: null,
} as IQuoteModel;
