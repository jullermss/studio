import { IPhoneDetails } from '../../models/phone-details.model';

export const phoneDetailsInitialState = {} as IPhoneDetails;
