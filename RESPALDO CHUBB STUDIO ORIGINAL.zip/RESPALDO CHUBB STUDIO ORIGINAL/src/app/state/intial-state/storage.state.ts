export const storageInitialState = null;
