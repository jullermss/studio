import { IUserModel } from '../../models/user.model';

export const userInitialState = {
  firstName: '',
  lastName: '',
  email: '',
  dateOfBirth: '',
  codeValidationError: false,
} as IUserModel;
