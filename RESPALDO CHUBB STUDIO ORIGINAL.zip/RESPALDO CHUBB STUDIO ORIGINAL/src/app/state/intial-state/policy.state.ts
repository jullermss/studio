import { IPolicyModel } from '../../models/policy.model';
import { PersonModel } from '../../models/person.model';
import {
  AddressBrazil,
  IAddressBrazil,
} from '../../models/address-brasil.model';
import { ICreatePolicyResponse } from '../../models/ICreatePolicyResponse';

export const policyInitialState = {
  phoneStorage: '',
  personInfo: new PersonModel({
    email: '',
    phone: '',
    uniqueIdentifier: '',
    lastName: '',
    firstName: '',
    address: new AddressBrazil({
      neighborhood: '',
      complement: '',
      number: '',
      addressLine1: '',
      addressLine2: '',
      city: '',
      country: '',
      state: '',
      zipCode: '',
    }),
  }),
  policyValidationResponse: null,
} as IPolicyModel;
