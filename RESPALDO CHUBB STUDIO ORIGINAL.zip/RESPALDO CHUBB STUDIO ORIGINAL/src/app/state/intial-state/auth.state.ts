import { IAuthModel } from '../../models/auth.model';

export const authInitialState = {
  token: '',
  isAuthenticated: false,
  expires: '',
  statusCode: '0',
  user: {
    firstName: '',
    lastName: '',
    dateOfBirth: '',
    email: ''
  },
} as IAuthModel;
