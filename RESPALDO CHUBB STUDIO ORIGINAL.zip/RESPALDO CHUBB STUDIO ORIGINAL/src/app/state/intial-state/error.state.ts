import { ICurrentError } from '../../models/error.model';

export const errorInitialState = {
  code: '003',
} as ICurrentError;
