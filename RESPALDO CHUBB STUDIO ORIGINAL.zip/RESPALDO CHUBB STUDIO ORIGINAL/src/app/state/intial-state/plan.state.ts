import { IPlanModel } from '../../models/plan.model';
import { ISelectedPlanModel } from '../../models/selected-plan';

export const planInitialState = {} as ISelectedPlanModel;
