export const studioAppsInitialState = [
  {
    name: 'Servicing',
  },
  {
    name: 'Claims',
  },
  {
    name: 'Billing & Payments',
  },
];
