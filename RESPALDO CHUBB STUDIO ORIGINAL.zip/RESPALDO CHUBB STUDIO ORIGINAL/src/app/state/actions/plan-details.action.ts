import { Action } from '@ngrx/store';
import { StudioAppsActions } from './studio-apps.action';
import { IQuoteModel } from '../../models/quote.model';
import { RedirectToActions, RedirectToAction } from './redirect.action';
import { ISelectedPlanModel } from '../../models/selected-plan';

export enum PlansActions {
  LOAD_PLAN_DETAILS = '[PLAN] LOAD PLAN DETAILS',
  LOAD_PLAN_DETAILS_SUCCESS = '[PLAN] LOAD PLAN DETAILS SUCCESS',
  UPDATE_PLAN_DETAILS = '[PLAN] UPDATE PLAN DETAILS',
}

export class LoadPlansAction implements Action {
  readonly type: string = PlansActions.LOAD_PLAN_DETAILS;
  constructor(public payload: IQuoteModel, public storage: any) {}
}

export class UpdatePlansAction implements Action {
  readonly type: string = PlansActions.UPDATE_PLAN_DETAILS;
  constructor(public payload: ISelectedPlanModel) {}
}

export class LoadPlansActionSuccess implements Action {
  readonly type: string = PlansActions.LOAD_PLAN_DETAILS_SUCCESS;
  payload?: any;
}

export type PlanActionsType = LoadPlansAction | LoadPlansActionSuccess;
