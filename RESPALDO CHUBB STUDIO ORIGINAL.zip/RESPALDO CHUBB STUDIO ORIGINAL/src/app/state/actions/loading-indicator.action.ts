import { Action } from '@ngrx/store';
import { Loading } from '../../components/shared/loading/loading.model';

export enum LoadingIndicatorActions {
  LOADING_INDICATOR_SHOW = '[LOADING INDICATOR] LOADING INDICATOR SHOW',
  LOADING_INDICATOR_SHOW_SUCCESS = '[LOADING INDICATOR] LOADING INDICATOR SHOW SUCCESS',
  LOADING_INDICATOR_HIDE = '[LOADING INDICATOR] LOADING INDICATOR HIDE',
  LOADING_INDICATOR_HIDE_SUCCESS = '[LOADING INDICATOR] LOADING INDICATOR HIDE SUCCESS',
}

export class LoadingIndicatorShowAction implements Action {
  readonly type: string = LoadingIndicatorActions.LOADING_INDICATOR_SHOW;

  constructor(public payload: Loading) {}
}

export class LoadingIndicatorShowSuccessAction implements Action {
  readonly type: string =
    LoadingIndicatorActions.LOADING_INDICATOR_SHOW_SUCCESS;

  constructor(public payload: boolean) {}
}

export class LoadingIndicatorHideAction implements Action {
  readonly type: string = LoadingIndicatorActions.LOADING_INDICATOR_HIDE;

  constructor(public payload: boolean) {}
}

export class LoadingIndicatorHideSuccessAction implements Action {
  readonly type: string =
    LoadingIndicatorActions.LOADING_INDICATOR_HIDE_SUCCESS;

  constructor(public payload: boolean) {}
}

export type LoadingIndicatorActionType =
  | LoadingIndicatorShowAction
  | LoadingIndicatorShowSuccessAction
  | LoadingIndicatorHideAction
  | LoadingIndicatorHideSuccessAction;
