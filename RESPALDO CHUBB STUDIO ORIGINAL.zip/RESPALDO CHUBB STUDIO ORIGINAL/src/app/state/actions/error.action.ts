import { Action } from '@ngrx/store';

import { ICurrentError } from '../../models/error.model';

export enum ErrorActions {
  LOAD_ERROR_DETAILS = '[ERROR] LOAD ERROR STATE',
  UPDATE_ERROR_DETAILS = '[ERROR] UPDATE ERROR DETAILS',
}

export class LoadErrorAction implements Action {
  readonly type: string = ErrorActions.LOAD_ERROR_DETAILS;
  constructor(public payload: ICurrentError) {}
}
export class UpdateErrorAction implements Action {
  readonly type: string = ErrorActions.UPDATE_ERROR_DETAILS;
  constructor(public payload: ICurrentError) {}
}

export type ErrActionsType = LoadErrorAction;
