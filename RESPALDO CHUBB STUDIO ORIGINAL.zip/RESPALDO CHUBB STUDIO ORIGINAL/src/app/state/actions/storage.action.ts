import { Action } from '@ngrx/store';
import { IQuoteModel } from '../../models/quote.model';

export enum StorageActions {
  UPDATE_SELECTED_STORAGE = '[STORAGE] UPDATE SELECTED STORAGE',
}

export class UpdateSelectedStorageAction implements Action {
  readonly type: string = StorageActions.UPDATE_SELECTED_STORAGE;

  constructor(public payload: string) {}
}

export type StorageActionsType = UpdateSelectedStorageAction;
