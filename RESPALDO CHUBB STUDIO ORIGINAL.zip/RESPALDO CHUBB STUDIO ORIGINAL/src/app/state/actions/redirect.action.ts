import { Action } from '@ngrx/store';
import { IRedirectToModel } from '../../models/redirect-to.model';

export enum RedirectToActions {
  REDIRECT_TO = '[REDIRECT] REDIRECT TO',
  REDIRECT_TO_SUCCESS = '[REDIRECT] REDIRECT TO SUCCESS',
}

export class RedirectToAction implements Action {
  readonly type: string = RedirectToActions.REDIRECT_TO;

  constructor(public payload: IRedirectToModel) {}
}

export class RedirectToActionSuccess implements Action {
  readonly type: string = RedirectToActions.REDIRECT_TO_SUCCESS;
}

export type RedirectActionsType = RedirectToAction | RedirectToActionSuccess;
