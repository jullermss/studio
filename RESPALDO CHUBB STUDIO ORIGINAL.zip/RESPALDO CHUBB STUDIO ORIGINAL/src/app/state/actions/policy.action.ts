import { Action } from '@ngrx/store';
import { IPolicyModel } from '../../models/policy.model';
import { IPersonModel } from '../../models/person.model';

export enum PolicyActions {
  LOAD_POLICY_INITIAL_STATE = '[POLICY] LOAD INITIAL STATE',
  LOAD_POLICY_INFO = '[POLICY] LOAD POLICY INFO',
  UPDATE_POLICY_INFO = '[POLICY] UPDATE POLICY INFO',
  UPDATE_PERSON_INFO = '[POLICY] UPDATE PERSON INFO'
}

export class LoadPolicyInitialState implements Action {
  readonly type: string = PolicyActions.LOAD_POLICY_INITIAL_STATE;
}
export class LoadPolicyInfo implements Action {
  readonly type: string = PolicyActions.LOAD_POLICY_INFO;
  constructor(public payload: IPolicyModel) {}
}
export class UpdatePolicyInfo implements Action {
  readonly type: string = PolicyActions.UPDATE_POLICY_INFO;
  constructor(public payload: IPolicyModel) {}
}

export class UpdatePersonInfo implements Action {
  readonly type: string = PolicyActions.UPDATE_PERSON_INFO;
  constructor(public payload: IPersonModel) {}
}

export type PolicyActionsType = UpdatePolicyInfo | UpdatePersonInfo | LoadPolicyInitialState;
