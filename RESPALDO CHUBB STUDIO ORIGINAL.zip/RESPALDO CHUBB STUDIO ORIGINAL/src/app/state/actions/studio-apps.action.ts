import { Action } from '@ngrx/store';
import { IQuoteModel } from '../../models/quote.model';

export enum StudioAppsActions {
  LOAD_STUDIO_APPS = '[APPS] LOAD STUDIO APPS',
  LOAD_STUDIO_APPS_SUCCESS = '[APPS] LOAD STUDIO APPS SUCCESS',
  LOAD_STUDIO_APPS_FAILURE = '[APPS] LOAD STUDIO APPS FAILURE',
  ADD_STUDIO_APPS = '[APPS] ADD STUDIO APPS',
  ADD_STUDIO_APPS_SUCCESS = '[APPS] ADD STUDIO APPS SUCCESS',
  ADD_STUDIO_APPS_FAILURE = '[APPS] ADD STUDIO APPS FAILURE',
}

export class LoadStudioAppsAction implements Action {
  readonly type: string = StudioAppsActions.LOAD_STUDIO_APPS;
  constructor(public payload: IQuoteModel) {}
}

export class LoadStudioAppsSuccessAction implements Action {
  readonly type: string = StudioAppsActions.LOAD_STUDIO_APPS_SUCCESS;

  constructor(public payload: boolean) {}
}

export class LoadStudioAppsFailureAction implements Action {
  readonly type: string = StudioAppsActions.LOAD_STUDIO_APPS_FAILURE;

  constructor() {}
}

export class AddStudioAppsAction implements Action {
  readonly type: string = StudioAppsActions.ADD_STUDIO_APPS;
}

export class AddStudioAppsSuccessAction implements Action {
  readonly type: string = StudioAppsActions.ADD_STUDIO_APPS_SUCCESS;

  constructor(public payload: { name: string }) {}
}

export class AddStudioAppsFailureAction implements Action {
  readonly type: string = StudioAppsActions.ADD_STUDIO_APPS_FAILURE;

  constructor() {}
}

export type StudioAppsActionsType =
  | LoadStudioAppsAction
  | LoadStudioAppsSuccessAction
  | LoadStudioAppsFailureAction
  | AddStudioAppsAction
  | AddStudioAppsSuccessAction
  | AddStudioAppsFailureAction;
