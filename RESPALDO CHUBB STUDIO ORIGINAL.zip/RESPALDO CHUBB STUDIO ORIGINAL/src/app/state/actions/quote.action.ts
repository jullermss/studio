import { Action } from '@ngrx/store';
import { IQuoteModel } from '../../models/quote.model';
import { IQuoteRequestModel } from '../../models/quote-request.model';

export enum QuoteActions {
  LOAD_QUOTE = '[QUOTE] LOAD QUOTE',
  LOAD_QUOTE_SUCCESS = '[QUOTE] LOAD QUOTE SUCCESS',
  LOAD_QUOTE_FAILURE = '[QUOTE] LOAD QUOTE FAILURE',
  LOAD_QUOTE_COMPLETED = '[QUOTE] LOAD QUOTE COMPLETED',
}

export class LoadQuoteAction implements Action {
  readonly type: string = QuoteActions.LOAD_QUOTE;
  constructor(public payload: IQuoteRequestModel, public storage: string) {}
}

export class LoadQuoteSuccessAction implements Action {
  readonly type: string = QuoteActions.LOAD_QUOTE_SUCCESS;

  constructor(public payload: IQuoteModel) {}
}

export class LoadQuoteFailureAction implements Action {
  readonly type: string = QuoteActions.LOAD_QUOTE_FAILURE;

  constructor(public payload: any) {}
}

export type LoadQuoteActionsType =
  | LoadQuoteAction
  | LoadQuoteSuccessAction
  | LoadQuoteFailureAction;
