import { Action } from '@ngrx/store';

export enum AuthActions {
  LOAD_CODE_INITIAL_STATE = '[CODE] LOAD INITIAL STATE',
  VALIDATE_CODE_BEGINS = '[CODE] VALIDATE CODE BEGINS',
  VALIDATE_CODE_SUCCESS = '[CODE] VALIDATE CODE SUCCESS',
  VALIDATE_CODE_FAILURE = '[CODE] VALIDATE CODE FAILURE',
}

export class LoadCodeInitialState implements Action {
  readonly type: string = AuthActions.LOAD_CODE_INITIAL_STATE;
}

export class ValidateCodeAction implements Action {
  readonly type: string = AuthActions.VALIDATE_CODE_BEGINS;

  constructor(public payload: any) {}
}

export class ValidateCodeSuccessAction implements Action {
  readonly type: string = AuthActions.VALIDATE_CODE_SUCCESS;

  constructor(public payload: any) {}
}

export class ValidateCodeFailureAction implements Action {
  readonly type: string = AuthActions.VALIDATE_CODE_FAILURE;

  constructor(public payload: any) {}
}

export type AuthActionsType =
  | LoadCodeInitialState
  | ValidateCodeAction
  | ValidateCodeSuccessAction
  | ValidateCodeFailureAction;
