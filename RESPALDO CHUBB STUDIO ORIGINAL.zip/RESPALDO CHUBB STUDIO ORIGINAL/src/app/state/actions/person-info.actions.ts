import { Action } from '@ngrx/store';

export enum PersonInfoActions {
  LOAD_INITIAL_STATE = '[REGISTRATION] LOAD INITIAL STATE',
}

export class LoadInitialState implements Action {
  readonly type: string = PersonInfoActions.LOAD_INITIAL_STATE;
}

export type PersonInfoActionsType = LoadInitialState;
