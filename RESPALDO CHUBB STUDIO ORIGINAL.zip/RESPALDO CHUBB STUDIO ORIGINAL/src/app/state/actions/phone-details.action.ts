import { Action } from '@ngrx/store';
import { IPhoneDetails } from '../../models/phone-details.model';

export enum PhoneDetailsActions {
  LOAD_PHONE_DETAILS = '[PHONE-DETAILS] LOAD PHONE DETAILS',
  LOAD_PHONE_DETAILS_SUCCESS = '[PHONE-DETAILS] LOAD PHONE DETAILS SUCCESS',
  LOAD_PHONE_DETAILS_FAILURE = '[PHONE-DETAILS] LOAD PHONE DETAILS FAILURE',
  UPDATE_PHONE_IMEI = '[PHONE-DETAILS] UPDATE PHONE IMEI'
}

export class LoadPhoneDetailsAction implements Action {
  readonly type: string = PhoneDetailsActions.LOAD_PHONE_DETAILS;
}

export class LoadPhoneDetailsSuccessAction implements Action {
  readonly type: string = PhoneDetailsActions.LOAD_PHONE_DETAILS_SUCCESS;

  constructor(public payload: IPhoneDetails) {}
}

export class LoadQuoteFailureAction implements Action {
  readonly type: string = PhoneDetailsActions.LOAD_PHONE_DETAILS_FAILURE;

  constructor(public payload: any) {}
}

export class UpdateIMEIAction implements Action {
  readonly type: string = PhoneDetailsActions.UPDATE_PHONE_IMEI;

  constructor(public payload: string) {}
}

export type LoadPhoneDetailsActionsType =
  | LoadPhoneDetailsAction
  | LoadPhoneDetailsSuccessAction
  | LoadQuoteFailureAction
  | LoadQuoteFailureAction;
