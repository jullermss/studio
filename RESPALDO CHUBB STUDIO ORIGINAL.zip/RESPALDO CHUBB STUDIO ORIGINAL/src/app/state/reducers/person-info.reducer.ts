import {
  PersonInfoActionsType,
  PersonInfoActions,
} from '../actions/person-info.actions';
import { IUserModel } from '../../models/user.model';

export function personInfoReducer(
  state: IUserModel,
  action: PersonInfoActionsType
) {
  switch (action.type) {
    case PersonInfoActions.LOAD_INITIAL_STATE:
      return state;
    default:
      return state;
  }
}
