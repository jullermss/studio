import { PolicyActions, PolicyActionsType } from '../actions/policy.action';
import { IPolicyModel } from '../../models/policy.model';

export function policyReducer(state: IPolicyModel, action: PolicyActionsType) {
  switch (action.type) {
    case PolicyActions.LOAD_POLICY_INFO:
      // @ts-ignore
      return { ...state, ...action.payload };
    case PolicyActions.UPDATE_POLICY_INFO:
      // @ts-ignore
      return { ...state, ...action.payload };
    case PolicyActions.UPDATE_PERSON_INFO:
      // @ts-ignore
      return { ...state, personInfo: { ...state.personInfo, ...action.payload } };
    case PolicyActions.LOAD_POLICY_INITIAL_STATE:
    default:
      return state;
  }
}
