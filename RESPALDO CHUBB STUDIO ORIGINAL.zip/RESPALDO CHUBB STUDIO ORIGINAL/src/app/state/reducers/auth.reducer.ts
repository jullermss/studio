import { AuthActionsType, AuthActions } from '../actions/auth.actions';
import { IAuthModel } from '../../models/auth.model';

export function authReducer(state: IAuthModel, action: AuthActionsType) {
  switch (action.type) {
    case AuthActions.LOAD_CODE_INITIAL_STATE:
      return state;
    case AuthActions.VALIDATE_CODE_BEGINS:
      return state;
    case AuthActions.VALIDATE_CODE_SUCCESS:
      return {
        ...state,
        // @ts-ignore
        token: action.payload.data.accessToken,
        // @ts-ignore
        statusCode: action.payload.statusCode.code
      };
    case AuthActions.VALIDATE_CODE_FAILURE:
      return {
        ...state,
        token: '',
        // @ts-ignore
        statusCode: action.payload
      };
    default:
      return state;
  }
}
