import {
  LoadPhoneDetailsActionsType,
  PhoneDetailsActions,
} from '../actions/phone-details.action';

export function phoneDetailsReducer(
  state = [],
  action: LoadPhoneDetailsActionsType
) {
  switch (action.type) {
    case PhoneDetailsActions.LOAD_PHONE_DETAILS:
      return state;
    case PhoneDetailsActions.LOAD_PHONE_DETAILS_SUCCESS:
      // @ts-ignore
      return { ...state, ...action.payload };
    case PhoneDetailsActions.LOAD_PHONE_DETAILS_FAILURE:
      // @todo the spreading of error is temporary.
      // need to take appropriate action on failure.
      // @ts-ignore
      return [{ error: true }];
    case PhoneDetailsActions.UPDATE_PHONE_IMEI:
      // @ts-ignore
      return { ...state, imei: action.payload };
    default:
      return state;
  }
}
