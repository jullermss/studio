import {
  RedirectToActions,
  RedirectActionsType,
} from '../actions/redirect.action';

export function redirectToReducer(state = {}, action: RedirectActionsType) {
  switch (action.type) {
    case RedirectToActions.REDIRECT_TO:
    default:
      return state;
  }
}
