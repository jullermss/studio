import { StorageActions, StorageActionsType } from '../actions/storage.action';

export function storageReducer(state = {}, action: StorageActionsType) {
  switch (action.type) {
    case StorageActions.UPDATE_SELECTED_STORAGE:
      return { ...state, selectedStorage: action.payload };
    default:
      return state;
  }
}
