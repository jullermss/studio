import {
  StudioAppsActions,
  StudioAppsActionsType,
} from '../actions/studio-apps.action';

export function studioAppsyReducer(state = [], action: StudioAppsActionsType) {
  switch (action.type) {
    case StudioAppsActions.ADD_STUDIO_APPS:
      return state;
    case StudioAppsActions.ADD_STUDIO_APPS_SUCCESS:
    case StudioAppsActions.ADD_STUDIO_APPS_FAILURE:
    case StudioAppsActions.LOAD_STUDIO_APPS_SUCCESS:
    case StudioAppsActions.LOAD_STUDIO_APPS_FAILURE:
      // @ts-ignore
      return [...state, ...action.payload];
    case StudioAppsActions.LOAD_STUDIO_APPS:
    default:
      return state;
  }
}
