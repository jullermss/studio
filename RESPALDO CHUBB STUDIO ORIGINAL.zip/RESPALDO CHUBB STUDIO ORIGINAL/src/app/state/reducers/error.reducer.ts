import { ErrActionsType, ErrorActions } from '../actions/error.action';

export function errorReducer(state = {}, action: ErrActionsType) {
  switch (action.type) {
    case ErrorActions.UPDATE_ERROR_DETAILS:
      return { ...state, ...action.payload };
    case ErrorActions.LOAD_ERROR_DETAILS:
    default:
      return state;
  }
}
