import {
  LoadingIndicatorActions,
  LoadingIndicatorActionType,
} from '../actions/loading-indicator.action';

export function loadingIndicatorReducer(
  state = false,
  action: LoadingIndicatorActionType
) {
  switch (action.type) {
    case LoadingIndicatorActions.LOADING_INDICATOR_SHOW:
      return true;
    case LoadingIndicatorActions.LOADING_INDICATOR_HIDE:
      return false;
    default:
      return false;
  }
}
