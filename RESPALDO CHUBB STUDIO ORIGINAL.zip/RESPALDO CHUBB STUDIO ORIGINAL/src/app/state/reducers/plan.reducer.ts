import { PlansActions, PlanActionsType } from '../actions/plan-details.action';

export function planReducer(state = {}, action: PlanActionsType) {
  switch (action.type) {
    case PlansActions.LOAD_PLAN_DETAILS:
      return state;
    case PlansActions.UPDATE_PLAN_DETAILS:
      return { ...state, ...action.payload };
    case PlansActions.LOAD_PLAN_DETAILS_SUCCESS:
    default:
      return state;
  }
}
