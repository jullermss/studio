import { LoadQuoteActionsType, QuoteActions } from '../actions/quote.action';

export function quoteReducer(state = [], action: LoadQuoteActionsType) {
  switch (action.type) {
    case QuoteActions.LOAD_QUOTE:
      return state;
    case QuoteActions.LOAD_QUOTE_COMPLETED:
      return state;
    case QuoteActions.LOAD_QUOTE_SUCCESS:
      // @ts-ignore
      return { ...state, ...action.payload };
    case QuoteActions.LOAD_QUOTE_FAILURE:
      // @todo the spreading of error is temporary.
      // need to take appropriate action on failure.
      // @ts-ignore
      return [{ error: true }];
    default:
      return state;
  }
}
