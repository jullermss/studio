import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { catchError, concatMap, map, tap } from 'rxjs/operators';
import { Store } from '@ngrx/store';
import { StudioState } from '../intial-state';
import { of } from 'rxjs';
import { HttpErrorResponse } from '@angular/common/http';
import { ToastService } from '../../components/shared/toast/toast.service';
import { StudioErrorHandler } from '../../error-handlers/studio.error-handler';
import {
  LoadQuoteAction,
  LoadQuoteSuccessAction,
  QuoteActions,
} from '../actions/quote.action';
import { MockDataServicesService } from '../../services/mock-data-services.service';
import { IQuoteModel } from '../../models/quote.model';
import { QuoteService } from '../../services/quote.service';
import { ICurrentError, IErrorCustom } from '../../models/error.model';
import {
  RedirectToAction,
  RedirectToActions,
} from '../actions/redirect.action';
import { UpdateErrorAction } from '../actions/error.action';
import {
  StorageActions,
  UpdateSelectedStorageAction,
} from '../actions/storage.action';
import { LoadingIndicatorHideAction } from '../actions';

@Injectable()
export class QuoteEffects {
  @Effect()
  loadQuote$ = this._actions$.pipe(
    ofType(QuoteActions.LOAD_QUOTE),
    concatMap((action: LoadQuoteAction) =>
      this._quoteService.getQuote(action.payload.imei).pipe(
        tap(() => {
          // this._toastService.showSuccess('Got the quote..');
          console.log('Got the quote', action.payload);
        }),
        map((quote: IQuoteModel) => {
          if (quote) {
            this._store.dispatch(new LoadQuoteSuccessAction(quote));
            if (action.storage) {
              return {
                type: StorageActions.UPDATE_SELECTED_STORAGE,
                payload: action.storage,
              };
            } else {
              this._store.dispatch(new LoadingIndicatorHideAction(true));
              return {
                type: QuoteActions.LOAD_QUOTE_COMPLETED,
              };
            }
          } else {
            const errorObject: ICurrentError = {
              code: '002',
            };
            this._store.dispatch(new UpdateErrorAction(errorObject));
            return {
              type: RedirectToActions.REDIRECT_TO,
              payload: {
                routeName: 'error-page',
              },
            };
          }
        }),
        catchError((error: HttpErrorResponse) => {
          return of({
            type: RedirectToActions.REDIRECT_TO,
            payload: {
              routeName: 'error-page',
            },
          });
        })
      )
    )
  );

  constructor(
    private _actions$: Actions,
    private _store: Store<StudioState>,
    private _toastService: ToastService,
    private _errorHandler: StudioErrorHandler,
    private _mockDataServicesService: MockDataServicesService,
    private _quoteService: QuoteService
  ) {}
}
