import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { map, tap } from 'rxjs/operators';
import { Store } from '@ngrx/store';
import { StudioState } from '../intial-state';
import { StudioErrorHandler } from '../../error-handlers/studio.error-handler';
import { PlansActions, LoadPlansAction } from '../actions/plan-details.action';
import { IQuoteModel } from '../../models/quote.model';
import { QuoteActions } from '../actions/quote.action';
import { MapperService } from '../../services/mapper.service';
import { ISelectedPlanModel } from '../../models/selected-plan';

@Injectable()
export class PlanEffects {
  quote: IQuoteModel;
  storage: any;
  plans: ISelectedPlanModel;
  @Effect()
  loadPlan$ = this._actions$.pipe(
    ofType(PlansActions.LOAD_PLAN_DETAILS),
    tap((action: LoadPlansAction) => {
      console.log('obteniendo el quote en el effect', action.payload);
      this.quote = action.payload;
      this.storage = action.storage;
      this.plans = this.__mappingService.quoteToSelectedPlan(
        this.quote,
        this.storage
      );
    }),
    map(() => {
      return {
        type: PlansActions.UPDATE_PLAN_DETAILS,
        payload: this.plans,
      };
    })
  );

  constructor(
    private _actions$: Actions,
    private _store: Store<StudioState>,
    private _errorHandler: StudioErrorHandler,
    private __mappingService: MapperService
  ) {}
}
