import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { catchError, concatMap, map, tap } from 'rxjs/operators';
import { Store } from '@ngrx/store';
import { StudioState } from '../intial-state';
import { of } from 'rxjs';
import { HttpErrorResponse } from '@angular/common/http';
import { StudioHttpResponseError } from '../../error-handlers/studio-http-response.error';
import { ToastService } from '../../components/shared/toast/toast.service';
import { StudioErrorHandler } from '../../error-handlers/studio.error-handler';
import { MockDataServicesService } from '../../services/mock-data-services.service';
import { PhoneDetailsActions } from '../actions/phone-details.action';
import { IPhoneDetails } from '../../models/phone-details.model';

@Injectable()
export class PhoneDetailsEffects {
  @Effect()
  loadPhoneDetails$ = this._actions$.pipe(
    ofType(PhoneDetailsActions.LOAD_PHONE_DETAILS),
    concatMap(() =>
      this._mockDataServicesService.getPhoneDetails().pipe(
        map((phoneDetails: IPhoneDetails) => ({
          type: PhoneDetailsActions.LOAD_PHONE_DETAILS_SUCCESS,
          payload: phoneDetails,
        })),
        catchError((error: HttpErrorResponse) => {
          this._errorHandler.handleError(
            new StudioHttpResponseError(
              `Unable to get the phone details `,
              error
            )
          );

          return of({
            type: PhoneDetailsActions.LOAD_PHONE_DETAILS_FAILURE,
          });
        })
      )
    )
  );

  constructor(
    private _actions$: Actions,
    private _store: Store<StudioState>,
    private _toastService: ToastService,
    private _errorHandler: StudioErrorHandler,
    private _mockDataServicesService: MockDataServicesService
  ) {}
}
