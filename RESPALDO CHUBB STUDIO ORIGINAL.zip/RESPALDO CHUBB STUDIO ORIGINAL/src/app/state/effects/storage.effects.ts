import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { map, tap } from 'rxjs/operators';

import { StorageActions } from '../actions/storage.action';
import {
  RedirectToActions,
  RedirectToAction,
} from '../actions/redirect.action';

@Injectable()
export class StorageEffects {
  @Effect()
  loadQuote$ = this._actions$.pipe(
    ofType(StorageActions.UPDATE_SELECTED_STORAGE),
    tap((response) => {
      console.log(`StorageActions.UPDATE_SELECTED_STORAGE effect `, response);
    }),
    map(() => ({
      type: RedirectToActions.REDIRECT_TO,
      payload: {
        routeName: 'plan-details',
      },
    }))
  );

  constructor(private _actions$: Actions) {}
}
