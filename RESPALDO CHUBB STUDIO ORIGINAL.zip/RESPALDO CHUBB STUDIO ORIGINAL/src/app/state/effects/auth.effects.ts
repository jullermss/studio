import { Injectable } from '@angular/core';
import { Effect, Actions, ofType } from '@ngrx/effects';
import * as AuthActions from '../actions/auth.actions';
import { CodeValidationService } from '../../services/code-validation.service';
import { switchMap, catchError, tap } from 'rxjs/operators';
import { Store } from '@ngrx/store';
import { of, throwError } from 'rxjs';
import { RedirectToAction } from '../actions/redirect.action';
import {
  LoadingIndicatorShowAction,
  LoadingIndicatorHideAction,
  LoadingIndicatorActions,
} from '../actions';
import { StudioState } from '../intial-state';
import { IApiResponse } from '../../models/api-response';

@Injectable()
export class AuthEffects {
  constructor(
    private _actions$: Actions,
    private _codeValidationService: CodeValidationService,
    private _store: Store<StudioState>
  ) {}

  @Effect()
  validateCode$ = this._actions$.pipe(
    ofType(AuthActions.AuthActions.VALIDATE_CODE_BEGINS),
    tap(() => {
      this._store.dispatch(
        new LoadingIndicatorShowAction({
          title: 'Validando código',
        })
      );
    }),
    switchMap((action: AuthActions.ValidateCodeAction) =>
      this._codeValidationService.validateCode(action.payload).pipe(
        switchMap(response => {
          if (response.statusCode.code !== '0') {
            return throwError(response.statusCode.code);
          }

          return [
            new LoadingIndicatorHideAction(false),
            new AuthActions.ValidateCodeSuccessAction(response),
            new RedirectToAction({ routeName: 'choose-storage' }),
          ];
        }),
        catchError((error) => {
          this._store.dispatch(new LoadingIndicatorHideAction(false));
          return of(new AuthActions.ValidateCodeFailureAction(error));
        })
      )
    )
  );
}
