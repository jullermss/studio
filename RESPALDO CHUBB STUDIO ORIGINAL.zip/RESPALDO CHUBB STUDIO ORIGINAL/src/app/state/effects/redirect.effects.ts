import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { map, tap } from 'rxjs/operators';
import { Store } from '@ngrx/store';
import { StudioState } from '../intial-state';
import { ToastService } from '../../components/shared/toast/toast.service';
import { StudioErrorHandler } from '../../error-handlers/studio.error-handler';
import {
  RedirectToActions,
  RedirectToAction,
} from '../actions/redirect.action';
import { RedirectService } from '../../services/redirect.service';

@Injectable()
export class RedirectToEffects {
  @Effect()
  redirect$ = this._actions$.pipe(
    ofType(RedirectToActions.REDIRECT_TO),
    tap((action: RedirectToAction) => {
      console.log(`trying to redirect to provided route `, action.payload);
      this._redirectService.redirectTo(action.payload).then();
    }),
    map((redirectResponse) => ({
      type: RedirectToActions.REDIRECT_TO_SUCCESS,
    }))
  );

  constructor(
    private _actions$: Actions,
    private _store: Store<StudioState>,
    private _toastService: ToastService,
    private _errorHandler: StudioErrorHandler,
    private _redirectService: RedirectService
  ) {}
}
