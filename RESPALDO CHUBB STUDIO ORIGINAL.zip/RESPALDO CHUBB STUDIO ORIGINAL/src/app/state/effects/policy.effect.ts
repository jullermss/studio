import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { catchError, concatMap, map, tap } from 'rxjs/operators';
import { Store } from '@ngrx/store';
import { StudioState } from '../intial-state';
import { StudioErrorHandler } from '../../error-handlers/studio.error-handler';

import { LoadPolicyInfo, PolicyActions } from '../actions/policy.action';
import { IPolicyModel } from '../../models/policy.model';
import { ICreatePolicyResponse } from '../../models/ICreatePolicyResponse';
import { PolicyService } from '../../services/policy.service';
import { Observable, of } from 'rxjs';
import { HttpErrorResponse } from '@angular/common/http';
import { ICurrentError } from '../../models/error.model';
import { UpdateErrorAction } from '../actions/error.action';
import {
  RedirectToAction,
  RedirectToActions,
} from '../actions/redirect.action';
import { QuoteActions } from '../actions/quote.action';

@Injectable()
export class PolicyEffect {
  policyState: IPolicyModel;
  policyResponse: ICreatePolicyResponse;
  @Effect()
  policy$ = this._actions$.pipe(
    ofType(PolicyActions.LOAD_POLICY_INFO),
    concatMap((action: LoadPolicyInfo) =>
      this._policyService.createPolicy(action.payload).pipe(
        map((policyRes: ICreatePolicyResponse) => {
          action.payload.policyValidationResponse = policyRes;
          return {
            type: PolicyActions.UPDATE_POLICY_INFO,
            payload: action.payload,
          };
        }),
        catchError((error: HttpErrorResponse) => {
          return of({
            type: RedirectToActions.REDIRECT_TO,
            payload: {
              routeName: 'error-page',
            },
          });
        })
      )
    )
  );

  constructor(
    private _actions$: Actions,
    private _store: Store<StudioState>,
    private _errorHandler: StudioErrorHandler,
    private _policyService: PolicyService
  ) {}
}
