import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { map, tap } from 'rxjs/operators';
import { LoadingService } from '../../components/shared/loading/loading.service';
import {
  LoadingIndicatorActions,
  LoadingIndicatorShowAction,
} from '../actions';

@Injectable()
export class LoadingIndicatorEffects {
  @Effect()
  showLoadingIndicator$ = this._actions$.pipe(
    ofType(LoadingIndicatorActions.LOADING_INDICATOR_SHOW),
    tap((action: LoadingIndicatorShowAction) => {
      this._loadingService.open(action.payload.title, action.payload.message);
    }),
    map(() => ({
      type: LoadingIndicatorActions.LOADING_INDICATOR_SHOW_SUCCESS,
      payload: false,
    }))
  );

  @Effect()
  hideLoadingIndicator$ = this._actions$.pipe(
    ofType('[LOADING INDICATOR] LOADING INDICATOR HIDE'),
    tap(() => {
      this._loadingService.close();
    }),
    map(() => ({
      type: LoadingIndicatorActions.LOADING_INDICATOR_HIDE_SUCCESS,
      payload: false,
    }))
  );

  constructor(
    private _actions$: Actions,
    private _loadingService: LoadingService
  ) {}
}
