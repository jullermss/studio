import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { MediaQueryService } from '@crux/services';
import { FlexLayoutModule } from '@angular/flex-layout';
import { LayoutComponent } from './layout.component';
import {
  AppNavbarModule,
  AppFooterModule,
  GetInTouchModule,
} from '@studio/components';

@NgModule({
  imports: [
    CommonModule,
    FlexLayoutModule,
    RouterModule,
    AppNavbarModule,
    AppFooterModule,
    GetInTouchModule,
  ],
  declarations: [LayoutComponent],
  providers: [MediaQueryService],
})
export class LayoutModule {}
