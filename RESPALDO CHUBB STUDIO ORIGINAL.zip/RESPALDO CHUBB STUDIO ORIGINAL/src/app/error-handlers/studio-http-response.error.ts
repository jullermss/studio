import { HttpErrorResponse } from '@angular/common/http';

export class StudioHttpResponseError extends Error {
  httpErrorResponse: HttpErrorResponse;
  constructor(message: string, error?: HttpErrorResponse) {
    super(message);
    this.name = 'StudioHttpResponseError';
    this.httpErrorResponse = error;
    this.stack = `${error.statusText} ${error.status}: ${error.message}`;
  }
}
