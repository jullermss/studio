export class StudioError extends Error {
  constructor(message: string, error?: Error) {
    super(message);
    this.name = 'StudioError';

    this.stack = error ? error.stack : null;
  }
}
