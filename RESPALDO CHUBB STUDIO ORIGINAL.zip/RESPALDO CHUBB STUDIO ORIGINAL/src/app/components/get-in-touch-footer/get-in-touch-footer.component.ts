import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'studio-get-in-touch-footer',
  templateUrl: './get-in-touch-footer.component.html',
  styleUrls: ['./get-in-touch-footer.component.scss'],
})
export class GetInTouchFooterComponent implements OnInit {
  @Input() data;
  constructor() {}

  ngOnInit() {}
}
