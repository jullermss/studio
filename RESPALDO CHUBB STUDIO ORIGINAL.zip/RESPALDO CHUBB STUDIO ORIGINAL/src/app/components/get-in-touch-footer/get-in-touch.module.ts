import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GetInTouchFooterComponent } from './get-in-touch-footer.component';
import { FlexLayoutModule } from '@angular/flex-layout';

@NgModule({
  imports: [CommonModule, FlexLayoutModule],
  declarations: [GetInTouchFooterComponent],
  exports: [GetInTouchFooterComponent],
})
export class GetInTouchModule {}
