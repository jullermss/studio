import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetInTouchFooterComponent } from './get-in-touch-footer.component';

xdescribe('GetInTouchFooterComponent', () => {
  let component: GetInTouchFooterComponent;
  let fixture: ComponentFixture<GetInTouchFooterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [GetInTouchFooterComponent],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetInTouchFooterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
