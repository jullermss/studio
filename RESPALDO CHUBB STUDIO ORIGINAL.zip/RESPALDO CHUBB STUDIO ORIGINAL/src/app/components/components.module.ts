import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
/**
 * CRUX imports
 */
import { CardModule, FooterModule } from '@crux/components';
/**
 * Component Imports
 */
import { AppNavbarModule } from './navbar/navbar.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { GetInTouchModule } from '@studio/components/get-in-touch-footer';
import { AppFooterModule } from './footer/footer.module';
import { SectionModule } from './shared/section/section.module';

@NgModule({
  imports: [
    FlexLayoutModule,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    CardModule,
    FooterModule,
    AppNavbarModule,
    GetInTouchModule,
    AppFooterModule,
    SectionModule,
  ],
  declarations: [],
  providers: [],
  exports: [
    /**
     * Footer
     */
    FooterModule,
    /**
     * Navbar
     */
    AppNavbarModule,
    GetInTouchModule,
  ],
  entryComponents: [],
})
export class ComponentsModule {}
