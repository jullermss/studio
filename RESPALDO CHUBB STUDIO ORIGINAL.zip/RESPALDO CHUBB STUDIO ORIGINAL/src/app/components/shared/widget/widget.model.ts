import { LoadModuleContext as CruxLazyLoadedModuleContext } from '@crux/components';

export interface Widget {
  /**
   * Name of one of pre-build widgets (like showing claim estimations,
   * showing documents, changing user-profile stuff, Content Header etc)
   */
  name: string;

  /**
   * This is going to be an object with properties that should match name
   * with @Input parameters for widget
   */
  context: CruxLazyLoadedModuleContext;
}
