import { WidgetModule } from './widget.module';

xdescribe('WidgetModule', () => {
  let widgetModule: WidgetModule;

  beforeEach(() => {
    widgetModule = new WidgetModule();
  });

  it('should create an instance', () => {
    expect(widgetModule).toBeTruthy();
  });
});
