/**
 * Key-value pair for widgets that are currently ready
 * @example
 * {
 *   ...
 *   'userContactDetails': true,
 *   ...
 * }
 */
export interface SectionReady {
  [key: string]: boolean;
}
