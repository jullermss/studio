import { SectionReady } from './section-ready.model';

/**
 * State object for states readiness
 * @example
 * {
 *   'user-profile-middle-section': {
 *     'userContactDetails': true,
 *     'userSecurityDetails': true
 *   }
 * }
 */
export interface SectionsReady {
  /**
   * Key-value pair for widgets that are currently ready
   * @example
   * {
   *   ...
   *   'userContactDetails': true,
   *   ...
   * }
   */
  [key: string]: SectionReady;
}
