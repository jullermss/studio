import { SectionModule } from './section.module';

xdescribe('SectionModule', () => {
  let sectionModule: SectionModule;

  beforeEach(() => {
    sectionModule = new SectionModule();
  });

  it('should create an instance', () => {
    expect(sectionModule).toBeTruthy();
  });
});
