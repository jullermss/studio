import { Widget } from '../widget/widget.model';

export interface Section {
  /**
   Unique key for section on page (needed for internal stuff,
   not meant for end-user, only if he will want to add css to
   customization.scss file and use selector like 'section section--<key>'
   */
  key: string;
  content: SectionContent[];

  /**
   * Should be an object compatible with `ngStyles` directive and have type
   * `[key: string]: string;`
   */
  styles?: any;
}

export interface SectionContent {
  /**
   * Any number `3`, `6`, `9`, `12`
   */
  size: 3 | 6 | 9 | 12;

  widget: Widget;
}
