import { Injectable } from '@angular/core';
import { Overlay, OverlayRef } from '@angular/cdk/overlay';
import { LoadingComponent } from './loading.component';
import { ComponentPortal } from '@angular/cdk/portal';

@Injectable({
  providedIn: 'root',
})
export class LoadingService {
  private _overlayRef: OverlayRef;

  constructor(private _overlay: Overlay) {
    this._overlayRef = this._overlay.create({
      hasBackdrop: false,
      scrollStrategy: this._overlay.scrollStrategies.noop(),
      positionStrategy: this._overlay.position().global(),
    });
  }

  open(title: string, message?: string): void {
    if (this._overlayRef.hasAttached()) {
      this._overlayRef.detach();
    }

    const portal = new ComponentPortal(LoadingComponent);
    const componentRef = this._overlayRef.attach(portal);
    componentRef.instance.message = message;
    componentRef.instance.title = title;
  }

  close(): void {
    this._overlayRef.detach();
  }
}
