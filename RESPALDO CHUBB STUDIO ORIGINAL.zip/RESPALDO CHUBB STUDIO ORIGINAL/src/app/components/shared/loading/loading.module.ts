import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoadingComponent } from './loading.component';
import { SpinnerModule } from '@crux/components';

@NgModule({
  imports: [CommonModule, SpinnerModule],
  declarations: [LoadingComponent],
  entryComponents: [LoadingComponent],
})
export class LoadingModule {}
