/**
 * Model for modal loading indicator
 */
export interface Loading {
  title: string;
  message?: string;
}
