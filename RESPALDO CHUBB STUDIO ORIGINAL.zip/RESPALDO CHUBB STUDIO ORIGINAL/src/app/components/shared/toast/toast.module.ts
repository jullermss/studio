import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ToastService } from './toast.service';
import { MatSnackBarModule } from '@angular/material';

@NgModule({
  declarations: [],
  imports: [CommonModule, MatSnackBarModule],
  providers: [ToastService],
})
export class ToastModule {}
