import { Component } from '@angular/core';
import { AppContextService } from '@studio/app.context.service';
import { Footer } from '@studio/components';
import { VERSION } from '../../version';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'studio-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss'],
})
export class FooterComponent {
  appVersionDetails = VERSION;
  showAppVersion = !environment.production;

  constructor(private _appContext: AppContextService) {}

  get footer(): Footer {
    if (!this._footer) {
      this._footer = this._appContext.get('common.footer');
    }

    return this._footer;
  }

  private _footer: Footer;
}
