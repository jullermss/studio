export interface FooterSocialLink {
  href: string;
  imgAlt: string;
  imgSrc: string;
}
