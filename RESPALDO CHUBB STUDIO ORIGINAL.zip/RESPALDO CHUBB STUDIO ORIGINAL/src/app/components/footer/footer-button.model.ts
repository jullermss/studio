export interface FooterButton {
  id: string;
  label: string;
  iconName?: string;
  iconPath?: string;
}
