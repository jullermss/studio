export interface FooterLink {
  id: string;
  type: 'route' | 'url' | 'callback';
  target: string;
  routeOrUrl: string;
  label: string;
}
