import { FooterButton, FooterLink, FooterSocialLink } from '@studio/components';

export interface Footer {
  label: string;

  copyrightLabel: string;

  buttons: FooterButton[];

  links: FooterLink[];

  socialLinks: FooterSocialLink[];

  copyrightText: string;
}
