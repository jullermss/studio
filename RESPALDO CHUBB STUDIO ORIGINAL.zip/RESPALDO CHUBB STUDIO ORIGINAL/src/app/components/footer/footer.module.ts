import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FooterComponent } from './footer.component';
import { FooterModule } from '@crux/components';

@NgModule({
  imports: [CommonModule, FooterModule],
  declarations: [FooterComponent],
  exports: [FooterComponent],
})
export class AppFooterModule {}
