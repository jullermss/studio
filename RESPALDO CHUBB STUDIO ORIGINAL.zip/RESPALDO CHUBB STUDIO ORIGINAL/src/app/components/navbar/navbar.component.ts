import { Component, Inject, OnInit } from '@angular/core';
import { NavbarService } from '@crux/components';
import { Router } from '@angular/router';
import { AppContextService } from '../../app.context.service';
import { STUDIO_BASE_HREF } from '@studio/constants/studio-base-href';

@Component({
  selector: 'studio-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss'],
})
export class NavbarComponent implements OnInit {
  constructor(
    private _navbarService: NavbarService,
    private _router: Router,
    private _appContext: AppContextService,
    @Inject(STUDIO_BASE_HREF) private _baseHref
  ) {}

  ngOnInit(): void {
    const { items, logo, logoAltText } = this._appContext.get(`common.navbar`);

    this._navbarService.emptyNavItems();
    this._navbarService.updateLogo({
      src: logo,
      alt: logoAltText,
      routeOrFunction: this._baseHref + '/home',
      navigationType: 'route',
    });

    for (const navItem of items) {
      if (!navItem.type) {
        navItem.type = 'route';
        navItem.routeOrFunction =
          this._baseHref + '/' + navItem.routeOrFunction;
      }
      this._navbarService.addRightNavItem(navItem);
    }
  }

  navbarItemClick(e): void {}
}
