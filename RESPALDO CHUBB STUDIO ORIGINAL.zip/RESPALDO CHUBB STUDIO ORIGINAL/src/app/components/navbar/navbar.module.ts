import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavbarModule } from '@crux/components';
import { NavbarComponent } from './navbar.component';

@NgModule({
  imports: [
    CommonModule,
    NavbarModule.forRoot({
      location: 'left',
      icons: {
        sidenavClose: '/assets/icons/sidenav_close.svg',
        sidenavToggle: '/assets/icons/sidenav_toggle_hamburger.svg',
      },
    }),
  ],
  declarations: [NavbarComponent],
  exports: [NavbarModule, NavbarComponent],
})
export class AppNavbarModule {}
