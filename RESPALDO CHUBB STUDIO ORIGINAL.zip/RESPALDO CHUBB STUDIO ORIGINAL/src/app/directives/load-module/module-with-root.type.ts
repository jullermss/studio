import { Type } from '@angular/core';

export type ModuleWithRoot = Type<any> & { rootComponent: Type<any> };
