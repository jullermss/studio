import { InjectionToken } from '@angular/core';

/**
 * provide name of module here to use in directive like 'studioLoadModule=widget'
 * <name>: string;
 */
// tslint:disable-next-line:class-name
export interface LAZY_LOAD_MODULES {
  contentHeader: string;
  contentNavigation: string;
  documentsWidget: string;
  ourProductsWidget: string;
  policiesWidget: string;
  stepsAccordionWidget: string;
  claimProcessWidget: string;
  claimsWidget: string;
  coisWidget: string;
  policycontentWidget: string;
  policydisclaimerWidget: string;
  inactivepolicycontentWidget: string;
  createCoiForm: string;
  userContactDetails: string;
  userSecurityDetails: string;
}

/**
 * provide path to module with chosen name from `LAZY_LOAD_MODULES`
 * <name>: <path_to_module>;
 */
export const lazyLoadModules: Partial<LAZY_LOAD_MODULES> = {
  contentHeader:
    'src/app/components/shared/content-header/content-header.module#ContentHeaderModule',
  contentNavigation:
    'src/app/components/widgets/content-navigation/content-navigation.module#ContentNavigationModule',
  documentsWidget:
    'src/app/components/widgets/documents/documents.module#DocumentsModule',
  ourProductsWidget:
    'src/app/components/widgets/our-products/our-products.module#OurProductsModule',
  policiesWidget:
    'projects/studio-widgets/src/lib/widgets/policies/policies.module#PoliciesModule',
  stepsAccordionWidget:
    'src/app/components/widgets/steps-accordion/steps-accordion.module#StepsAccordionModule',
  claimProcessWidget:
    'src/app/components/widgets/claim-process/claim-process.module#ClaimProcessModule',
  claimsWidget: 'src/app/components/widgets/claims/claims.module#ClaimsModule',
  coisWidget: 'src/app/components/widgets/cois/cois.module#CoisModule',
  policycontentWidget:
    'src/app/components/widgets/active-policy/active-policy.module#ActivePoliciesModule',
  policydisclaimerWidget:
    'src/app/components/widgets/policy-disclaimer/policy-disclaimer.module#PolicyDisclaimerModule',
  inactivepolicycontentWidget:
    'src/app/components/widgets/inactive-policy/inactive-policy.module#InactivePolicyModule',
  createCoiForm:
    'src/app/components/create-coi-form/create-coi-form.module#CreateCoiFormModule',
  userContactDetails:
    'src/app/components/widgets/user-contact-details/user-contact-details.module#UserContactDetailsModule',
  userSecurityDetails:
    'src/app/components/widgets/user-security-details/user-security-details.module#UserSecurityDetailsModule',
};

export const LAZY_LOAD_MODULES_MAP = new InjectionToken(
  'LAZY_LOAD_MODULES_MAP',
  {
    factory: () => lazyLoadModules,
  }
);
