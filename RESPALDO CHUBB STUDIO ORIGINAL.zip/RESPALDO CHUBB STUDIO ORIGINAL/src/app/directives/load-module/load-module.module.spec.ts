import { LoadModuleModule } from './load-module.module';

xdescribe('LoadModuleModule', () => {
  let loadModuleModule: LoadModuleModule;

  beforeEach(() => {
    loadModuleModule = new LoadModuleModule();
  });

  it('should create an instance', () => {
    expect(loadModuleModule).toBeTruthy();
  });
});
