// ToDo: add all base class types for this
export type LoadModuleContext = any;
