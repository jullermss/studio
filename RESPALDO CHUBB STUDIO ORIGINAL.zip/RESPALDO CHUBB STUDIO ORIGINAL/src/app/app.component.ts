import { Component, OnInit } from '@angular/core';
import {
  GoogleTagManagerService,
  ApplicationInsightsService,
} from '@crux/services';
import { AppContextService } from './app.context.service';
import {
  LoadPhoneDetailsAction,
  PhoneDetailsActions,
} from './state/actions/phone-details.action';
import { Store } from '@ngrx/store';
import { StudioState } from './state/intial-state';

@Component({
  selector: 'studio-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit {
  private initializeApp() {}
  constructor(
    private _gtm: GoogleTagManagerService,
    private _ai: ApplicationInsightsService,
    private _appContext: AppContextService,
    private _store: Store<StudioState>
  ) {}

  ngOnInit() {
    this.initializeApp();

    this._appContext.trackRouterEvents();
    this._store.dispatch(new LoadPhoneDetailsAction());
  }
}
