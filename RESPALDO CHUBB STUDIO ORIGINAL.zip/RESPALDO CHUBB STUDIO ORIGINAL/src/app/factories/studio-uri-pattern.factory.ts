import { Injectable, Injector } from '@angular/core';
import { Location } from '@angular/common';

@Injectable()
export class StudioUriPatternFactory {
  private _location: Location;

  constructor(private injector: Injector) {
    this._location = injector.get('Location');
  }

  getPattern(): string {
    return this._location.path();
  }

  setPattern() {}
}

export function studioUriPattern(): void {
  // return new StudioUriPatternFactory().getPattern();
}
