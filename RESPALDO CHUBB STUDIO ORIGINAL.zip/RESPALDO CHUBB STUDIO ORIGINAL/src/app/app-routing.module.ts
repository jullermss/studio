import { ModuleWithProviders, NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
// @ts-ignore
import { appRoutes } from '@studio/app-routes';

@NgModule({
  imports: [RouterModule.forRoot(appRoutes)],
  exports: [RouterModule],
})
export class AppRoutingModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: AppRoutingModule,
    };
  }
}
