import { Injectable } from '@angular/core';
import {
  ActivatedRouteSnapshot,
  Router,
  RouterStateSnapshot,
  CanActivateChild,
} from '@angular/router';
import { AppContextService } from '@studio/app.context.service';
import { environment } from '../../environments/environment';

@Injectable()
export class RouteGuard implements CanActivateChild {
  constructor(
    private _router: Router,
    private _appContext: AppContextService
  ) {}

  canActivateChild(
    childRoute: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): boolean {
    const activeRoutes = this._appContext.get('common.routes.active');
    if (!activeRoutes) {
      return false;
    }

    const path = childRoute.routeConfig.path;
    if (path && path.length > 0) {
      const toCompare = path.indexOf('/') > 0 ? path.split('/')[0] : path;
      if (activeRoutes.includes(toCompare)) {
        return true;
      } else {
        this._router.navigate([environment.uri.pageNotFound]);
        return false;
      }
    } else {
      return true;
    }
  }
}
