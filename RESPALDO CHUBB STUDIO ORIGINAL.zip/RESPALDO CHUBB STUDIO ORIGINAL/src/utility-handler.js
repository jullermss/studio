window.scxmlHandler = window.scxmlHandler || {};
(function(scxmlHandler) {
  var pendingEventPromises = [];
  /**
   * Get Language set on the device
   */

  function getUserLanguage() {
    var app_language = 'en';
    if (navigator.language) {
      if (navigator.language.indexOf('-') != -1) {
        var toks = navigator.language.split('-');
        app_language = toks[0];
      } else app_language = navigator.language;
    }

    return app_language;
  }
  scxmlHandler.getUserLanguage = getUserLanguage;

  /**
   * Read device details including IMEI
   */
  function getCellularDetails() {
    return new Promise((resolve, reject) => {
      if (window.sendCUEMEevent) {
        var p = {
          _resolve: resolve,
          _reject: reject,
        };

        pendingEventPromises.push(p);
        sendCUEMEevent('click', 'getCellularDetails', null);
      }
    });
  }
  scxmlHandler.getCellularDetails = getCellularDetails;

  /**
   * Internal callback function
   */
  function showCellularDetailsSuccess(cellularDetail) {
    console.log('scxmlHandler.showCellularDetailsSuccess ', cellularDetail);
    var p = pendingEventPromises.shift();

    if (p) {
      p._resolve(cellularDetail);
    }
  }
  scxmlHandler.showCellularDetailsSuccess = showCellularDetailsSuccess;

  function showCellularDetailsFail() {
    console.log('scxmlHandler.showCellularDetailsFail ');
    var p = pendingEventPromises.shift();
    if (p) {
      p._reject();
    }
  }
  scxmlHandler.showCellularDetailsFail = showCellularDetailsFail;

  scxmlHandler.getDeviceStorageInfo = function() {
    if (window.sendCUEMEevent) {
      sendCUEMEevent('click', 'getStorageDetails', null);
    }
  };

  scxmlHandler.onGetStorageDetailsSuccess = function(data) {
    window.SettingsPageRef.component.updateDeviceStorageInfo(data);
  };

  scxmlHandler.onGetStorageDetailsFail = function(data) {
    console.log('Failed to get device details');
  };
})(window.scxmlHandler);
