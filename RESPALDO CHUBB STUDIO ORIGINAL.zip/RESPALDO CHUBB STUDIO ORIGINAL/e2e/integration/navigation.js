describe(`Navbar Route Navigation`, () => {
  it(`navigate to dashboard`, () => {
    cy.visit(`/`);
  });

  it(`navigate to policies`, () => {
    cy.visit(`/foobar`);
  });
});
