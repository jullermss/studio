const fs = require('fs');
const path = require('path');
const util = require('util');
const readFile = util.promisify(fs.readFile);
const pjson = require('./package.json');

const reportStartTime = new Date().getTime();
console.log('CRUX stats: starting script...');

const fileExtensions = ['.ts', '.html'];
let writeToFile = false;

function loopAllFiles(dir, done) {
  let results = [];

  fs.readdir(dir, function(err, list) {
    if (err) return done(err);

    var pending = list.length;

    if (!pending) return done(null, results);

    list.forEach(function(file) {
      file = path.resolve(dir, file);

      fs.stat(file, function(err, stat) {
        // If directory, execute a recursive call
        if (stat && stat.isDirectory()) {
          // Add directory to array [comment if you need to remove the directories from the array]
          //results.push(file);

          loopAllFiles(file, function(err, res) {
            results = results.concat(res);
            if (!--pending) done(null, results);
          });
        } else {
          let extension = path.extname(file);
          if (fileExtensions.includes(extension)) {
            results.push(file);
          }

          if (!--pending) done(null, results);
        }
      });
    });
  });
}

function getComponentsCount(values, valuesToCountIn) {
  let components = [];
  for (let i = 0; i < values.length; i++) {
    let count = 0;
    for (let z = 0; z < valuesToCountIn.length; z++) {
      if (valuesToCountIn[z] === values[i]) count++;
    }
    components.push({ component: values[i], count: count });
  }

  return components;
}

function onlyUnique(value, index, self) {
  return self.indexOf(value) === index;
}

/**
 * Just method
 * @param file
 * @returns {*}
 */
function readB(file) {
  return readFile(file, 'utf8')
    .then((fileText) => {
      let components = fileText.match(/(<crux-[a-z|\-$>]+)/g);
      if (!components) {
        return new Promise((resolve, reject) => {
          resolve({ fbStats: false, components: null });
        });
      }

      let formBuilderResults;
      if (
        fileText.indexOf('<crux-form-builder') !== -1 &&
        path.extname(file) === '.html'
      ) {
        formBuilderResults = getFormBuilderStats(file);
      }

      for (let i = 0; i < components.length; i++) {
        components[i] = components[i]
          .trim()
          .toLowerCase()
          .replace('<', '')
          .replace('>', '');
      }

      if (formBuilderResults) {
        return formBuilderResults;
      } else {
        return new Promise((resolve, reject) => {
          resolve({ fbStats: false, components: components });
        });
      }
    })
    .catch((err) => {
      console.log(err);
    });
}

/**
 * FormBuilder stats: entry point for FormBuilder stats:
 * @param templateFile (.html)
 */
function getFormBuilderStats(templateFile) {
  let componentFile = templateFile.replace('.html', '.ts');
  let propertiesPromise = getFormBuilderProperties(templateFile);

  return propertiesPromise
    .then((properties) => {
      return getFormBuilderComponents(componentFile, properties);
    })
    .catch((err) => {
      console.log('propertiesPromise err: ' + err);
    });
}

/**
 * FormBuilder stats: Gets components from FormBuilder component file (.ts);
 * @param componentFile
 * @param properties
 * @returns array of components
 */
function getFormBuilderComponents(componentFile, properties) {
  return readFile(componentFile, 'utf8')
    .then((componentFileText) => {
      let fbStats = {
        fbStats: true,
        fbUsageCount: properties.length,
        components: [],
      };

      properties.forEach((property) => {
        const propertyPositions = getPropertyPositionsInComponent(
          componentFileText,
          property
        );
        propertyPositions.forEach((propertyPosition, index) => {
          let c = getFormBuilderComponentsFrom(
            componentFileText,
            property,
            propertyPosition
          );

          if (c) {
            fbStats.components.push(...c);
          }
        });
      });

      return fbStats;
    })
    .catch((err) => {
      console.log('getFormBuilderComponents ' + err);
      //return [];
    });
}

/**
 * FormBuilder stats: Gets components from component class
 * @param componentText
 * @param propertyName
 * @param propertyStartPosition
 * @returns array of components being used in FormBuilder in this component
 */
function getFormBuilderComponentsFrom(
  componentText,
  propertyName,
  propertyStartPosition
) {
  const startPosition = propertyStartPosition + propertyName.length + 1;

  // curly opening brackets
  let cobCount = 0;

  // curly closing brackets
  let ccbCount = 0;

  let formBuilderConfig = '';

  let currentChar = '';
  for (let i = startPosition; i < componentText.length; i++) {
    currentChar = componentText.charAt(i);

    if (
      !(
        currentChar === ' ' ||
        currentChar === '\n' ||
        currentChar === '\r' ||
        currentChar === '\r\n'
      )
    ) {
      formBuilderConfig += currentChar;

      if (currentChar === '{') {
        cobCount++;
      }

      if (currentChar === '}') {
        ccbCount++;
      }

      if (currentChar === ';' && cobCount === 0) {
        return [];
      }

      if (
        cobCount === ccbCount &&
        (cobCount !== 0 || ccbCount !== 0) &&
        currentChar === ';'
      ) {
        if (formBuilderConfig) i = componentText.length;
      }
    }
  }

  return getFbComponentsFromFormBuilderConfig(formBuilderConfig);
}

/**
 * FormBuilder stats: Parsing FormBuilder configuration from variable
 * @param componentText
 * @returns array of CRUX components (['crux-input', ...])
 */
function getFbComponentsFromFormBuilderConfig(componentText) {
  let fbComponentTypes = [];
  let myRegexp = /(type: *[\'|\"]([\w\-]*)[\'\"])/g;
  let match = myRegexp.exec(componentText);

  while (match) {
    fbComponentTypes.push(match[2]);
    match = myRegexp.exec(componentText);
  }

  let result = [];
  for (let i = 0; i < fbComponentTypes.length; i++) {
    switch (fbComponentTypes[i].toLowerCase()) {
      case 'input':
        result.push('crux-input');
        break;
      case 'calendar':
        result.push('crux-calendar');
        break;
      case 'radio':
        result.push('crux-radio');
        break;
      case 'checkbox':
        result.push('crux-checkbox');
        break;
      case 'dropdown':
        result.push('crux-dropdown');
        break;
      case 'autocomplete':
        result.push('crux-autocomplete');
        break;
      case 'addresslookup':
        result.push('crux-addresslookup');
        break;
      case 'zipcode':
        result.push('crux-zipcode');
        break;
      case 'paypal':
        result.push('crux-paypal');
        break;
      case 'toggle':
        result.push('crux-toggle');
        break;
      case 'button-toggle':
        result.push('crux-button-toggle');
        break;
      case 'textarea':
        result.push('crux-textarea');
        break;
    }
  }

  return result;
}

/**
 * FormBuilder stats: Gets position of property in component's class
 * @param componentText
 * @param propertyName
 * @returns {Array}[int]
 */
function getPropertyPositionsInComponent(componentText, propertyName) {
  let regex = new RegExp(propertyName, 'gi'),
    result,
    indices = [];
  while ((result = regex.exec(componentText))) {
    indices.push(result.index);
  }

  return indices;
}

/**
 * FormBuilder stats: Gets properties names from html template file
 * @param templateFile
 * @returns {Promise} with array of properties names
 */
function getFormBuilderProperties(templateFile) {
  return readFile(templateFile, 'utf8')
    .then((data) => {
      let fbConfigPropertiesNames = [];
      let myRegexp = /(crux-form-builder)*(\[config\]=\"([\w\-]*)\")/g;
      let match = myRegexp.exec(data);

      while (match) {
        fbConfigPropertiesNames.push(match[3]);
        match = myRegexp.exec(data);
      }

      return fbConfigPropertiesNames;
    })
    .catch((err) => {
      console.log(err);
    });
}

function getFileName() {
  const today = new Date();
  let dd = today.getDate();
  let mm = today.getMonth() + 1;
  let yyyy = today.getFullYear();

  return (
    'crux-stats' +
    '__' +
    yyyy +
    '-' +
    (mm < 10 ? '0' + mm : mm) +
    '-' +
    (dd < 10 ? '0' + dd : dd) +
    '__' +
    today.getHours() +
    '-' +
    today.getMinutes() +
    '-' +
    today.getSeconds() +
    '.json'
  );
}

function fillArgs() {
  process.argv.forEach(function(val, index, array) {
    if (val === 'write-to-file') {
      writeToFile = true;
    }
  });
}

/**
 * Entry point: loops through all files in project
 */
loopAllFiles('./src/app/', function(err, data) {
  if (err) {
    throw err;
  }

  fillArgs();

  let promises = [];
  let components = [];

  data.forEach((file) => {
    let read = readB(file);
    promises.push(read);
  });

  Promise.all(promises).then((values) => {
    let templatesComponents = [];
    let fbComponents = [];
    let fbUsagesCount = 0;
    values.forEach((data) => {
      if (data.fbStats === true) {
        fbUsagesCount += data.fbUsageCount || 0;
        fbComponents.push(...data.components);
      } else if (data.components && data.components.length > 0) {
        templatesComponents.push(...data.components);
      }
    });

    const occurrences = templatesComponents.concat(fbComponents);
    const uniqueComponents = occurrences.filter(onlyUnique);
    components = getComponentsCount(uniqueComponents, occurrences);

    const fbUniqueComponents = fbComponents.filter(onlyUnique);
    const fbComponentsStats = getComponentsCount(
      fbUniqueComponents,
      fbComponents
    );

    const cruxDependencies = [];
    if (pjson.dependencies['@crux/components']) {
      cruxDependencies.push({
        dep: 'components',
        ver: pjson.dependencies['@crux/components'],
      });
    }
    if (pjson.dependencies['@crux/services']) {
      cruxDependencies.push({
        dep: 'services',
        ver: pjson.dependencies['@crux/services'],
      });
    }
    if (pjson.dependencies['@crux/themes']) {
      cruxDependencies.push({
        dep: 'themes',
        ver: pjson.dependencies['@crux/themes'],
      });
    }
    if (pjson.dependencies['@crux/toolkit']) {
      cruxDependencies.push({
        dep: 'toolkit',
        ver: pjson.dependencies['@crux/toolkit'],
      });
    }

    const reportEndTime = new Date().getTime();

    const result = {
      appName: pjson.name,
      appVersion: pjson.version,
      cruxDependencies: cruxDependencies,
      cruxComponentsUsageCount: components.length || 0,
      cruxComponents: components,
      cruxFormBuilderUsage: {
        usageCount: fbUsagesCount,
        cruxComponents: fbComponentsStats,
      },
      reportExecutionTime: (reportEndTime - reportStartTime) / 1000 + ' s.',
    };

    console.log(result);

    if (writeToFile === true) {
      const fileName = getFileName();
      fs.writeFile(fileName, JSON.stringify(result), 'utf8', () => {
        console.log('Stats are written to file `' + fileName + '`');
      });
    }

    console.log('CRUX stats: done');
  });
});
