/**
 * A stupid script to update lazyModules in angular.json
 * and sync it with modulesRegistry from studio.json
 */

const _fs = require(`fs-extra`);
const _ = require(`lodash`);
const klawSync = require(`klaw-sync`);

const getLazyLoadedModulePath = (lazyLoadedModules) => {
  const lazyLoadedModulePaths = _.values(lazyLoadedModules);

  return _.map(lazyLoadedModulePaths, (lazyLoadedModulePaths) => {
    return lazyLoadedModulePaths.split(`#`)[0];
  });
};

const readStudioConfig = async () => {
  let lazyLoadModules = [];
  const paths = klawSync(`${process.cwd()}/config`, {
    nodir: true,
  });
  const angularConfig = await _fs.readJSON(`${process.cwd()}/angular.json`);

  for (const x of paths) {
    const studioConfig = await _fs.readJSON(x.path);

    lazyLoadModules = [
      ...lazyLoadModules,
      ...getLazyLoadedModulePath(studioConfig.moduleRegistry),
    ];
  }

  angularConfig.projects[
    'sales-mobile-ui'
  ].architect.build.options.lazyModules = _.uniq(lazyLoadModules);

  await _fs.writeJson(`${process.cwd()}/angular.json`, angularConfig, {
    spaces: '\t',
  });
};

const syncLazyLoadedModules = async () => {
  await readStudioConfig();
};

syncLazyLoadedModules();
