# Coding Guidelines
### Common
* Follow [Angular Styleguide](https://angular.io/guide/styleguide)
* Every component should have it’s own folder. Any directive and/or service related to the component should be placed in the same folder as the component.
* Unsubscribe Custom Observables
* Every Component should have it’s own module. This brings in clear separation of code.
* Every object should have it's type: usage of `any` type is allowed only in cases:
  * object is coming from non-ES6 library
* Each class/interface/factory/adapter/mediator/etc. should be in a separate file
* Avoid side-effects
* Variables should be initialized nearest to first usage
* Use `const` whenever it is possible
* Don’t use `public` accessor within classes
* All methods/properties/objects that are not meant to be exposed should have `private` accessor
* All private methods/properties/objects names should start with `_` (i.e. `private readonly _myProperty: string;`)
* Don’t use camelCase/PascalCase for file names. File names should be lowercased with `-` split character.
* No unused variables – this one catches tons of bugs!
* Use `2` spaces. Not **tabs**.
* Space after keywords `if (condition) { ... }`
* Always use `===` instead of `==`. But `obj == null` is allowed to check `null` || `undefined`.
* Infix operators must be spaced.
* Keep else statements on the same line as their curly braces.
* For multi-line if statements, use curly braces.
* Multiple blank lines not allowed.
* For the ternary operator in a multi-line setting, place ? and : on their own lines.
* Prefer single quotes (') unless escaping.
```typescript
const location = env.development
  ? 'localhost'
  : 'www.api.com'
```
* Add spaces inside single line blocks.
* Dot should be on the same line as property.
* See full list [here](https://standardjs.com/rules.html)... 

### Class items order
Within a class, struct or interface
* Constant Fields
* Fields
* Constructors
* Events
* Enums
* Interfaces (interface implementations)
* Properties
* Indexers
* Methods
* Structs
* Classes

Within each of these groups order by access
* public
* internal
* protected internal
* protected
* private

Within each of the access groups, order by static, then non-static
* static
* non-static

Within each of the static/non-static groups of fields, order by readonly, then non-readonly
* readonly
* non-readonly

### Array
* Annotate arrays as foos:Foo[] instead of foos:Array<Foo>.

### Comments
Use JSDoc style comments for functions, interfaces, enums, and classes. Whitespace is mandatory after opening construction (i.e. Good `/** my comment`, Bad: `/**mycomment`).

### CSS
* Use BEM 
  * http://getbem.com/
  * https://zellwk.com/blog/css-architecture-1/
  * https://spaceninja.com/2018/09/17/what-is-modular-css/
  * every tag should have it's own class: avoid overcomplicating markup
  * **THERE ARE NO GRAND CHILDREN IN BEM**
* Usage of `~styles.scss` is **not allow** in any component.
* Every css class should be separated by an empty line 
* Never rely on tags in CSS: add css class to it if you need to change it's style
* When measurement includes `0`, it should not contain measurement unit. (i.e. Good: `padding: 0;`, Bad: `padding: 0px`)
* Every component should have it's own SCSS file
* Use **ViewEncapsulation** as *none* so it would be easier to change this component's styles from parent component.
  * Be advised that in this case you shouldn't use too common class names (i.e. `header`, `button`, `table`, etc) as it will create issues in future
* Import only needed styles in component's SCSS file. Never import `styles.css` file.
* Use SASS features:
  * Use variables
  * Reference symbol `&`
  * Partials and `@import` directive
  * Interpolation
  * Lists and @each directive
  * Control directives
  
### HTML
* No usage of **FlexLayout** is allowed in templates
* No usage of **Bootstrap** is allowed
* No usage of `!important` is allowed
* All tags should be aligned, there shouldn't be any additional whitespaces (more then one), there shouldn't be any additional empty lines.
* Event methods for controls (i.e. `(click), (focusout)`, etc.) should contain only **one** method invocation. Constructions like this `(click)="next > 1 && next() && dropDatabase()"` are not allowed.

### Images
* Images should be located in `./assets/*`. When referring to image from your code it is mandatory to use absolute uri path
* Image names should be lowercased, with `_` character
* Image names should be self-explanatory

# Commits Guidelines
Commit messages are very important during contribution and play a crucial role if any feature or bug needs to be traced/tracked.

### Basic Rules
* Commit related features
* Don’t Commit Half-Done Work
* Test Your Code Before You Commit
* Write Good Commit Messages
* Use Branches
* Agree on A Workflow

### Formatting Rules
* Lowercased, short (50 chars or less) summary
* Write your commit message in the imperative: “Fix bug” and not “fixed bug” or “fixes bug”.
* Always leave the second line blank

### List of commit types:
* feat: a new feature
* fix: a bug fix
* docs: changes to documentation
* style: formatting, missing semi colons, etc; no code change
* refactor: refactoring production code
* test: adding tests, refactoring test; no production code change
* chore: updating build tasks, package manager configs, etc; no production code change

### Commit summary format:
`<commit type>(<scope>): <commit summary>`

i.e. `feat(DCRUX-555): add dialog component`, `fix(DCRUX-555): fix close button in dialog component`

### Branch name format:
`<scope>/<commit type>`

i.e. `DCRUX-555/feature`, `DCRUX-555/fix`, etc

### New Module/Widget
* Make sure to add the module/widget as part of `projects > studio-widgets`. **Do Not** add it as part of the project `src`.
* **Do Not** make any HTTP or third party SDK calls within the module unless necessary. HTTP calls will be made by the container and the data returned and/or required will be passed on to the widget as an `Observable`.

