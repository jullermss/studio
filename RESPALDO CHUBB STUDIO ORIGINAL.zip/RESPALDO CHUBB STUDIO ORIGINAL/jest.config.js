const globalFrontendJestConfig = require(`./node_modules/@crux/config/jest/jest.config.json`);

module.exports = {
  ...globalFrontendJestConfig,
};
