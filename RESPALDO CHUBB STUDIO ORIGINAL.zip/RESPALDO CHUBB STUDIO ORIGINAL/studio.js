var STUDIOJS = {
  pages: {
    coi: {
      header: {
        title: {
          content: 'Create a',
        },
        description: {
          content:
            "It only takes a few moments to request a new Certificate of Insurance. Just fill in the fields below and we'll get back to you within one business day.",
        },
      },
      sections: [
        {
          key: 'coi-form-section',
          content: [
            {
              widget: {
                name: 'createCoiForm',
                context: {
                  coiFormControls: [
                    {
                      key: 'horizontalLineTemplate',
                      name: 'horizontalLineTemplate',
                      type: 'template',
                    },
                    {
                      key: 'description',
                      name: 'description',
                      type: 'textarea',
                      label:
                        "Business description (this doesn't represent coverage) (optional)",
                      placeholder: '',
                      required: false,
                      layout: 'row',
                      validationMessages: {
                        required: 'Please enter the description',
                      },
                      options: {
                        type: 'text',
                        appearance: 'legacy',
                        floatLabel: 'auto',
                        hideRequiredMarker: true,
                        maxlength: 400,
                      },
                    },
                    {
                      key: 'horizontalLineTemplate',
                      name: 'horizontalLineTemplate',
                      type: 'template',
                    },
                    {
                      key: 'name',
                      name: 'name',
                      type: 'input',
                      label: "Certificate holder's name",
                      placeholder: '',
                      required: true,
                      cssClass: 'coi-crux-form__name',
                      layout: 'column',
                      validationMessages: {
                        required: "Please enter the certificate holder's name.",
                      },
                      options: {
                        type: 'text',
                        appearance: 'legacy',
                        floatLabel: 'auto',
                        hideRequiredMarker: true,
                        maxlength: 60,
                      },
                    },
                    {
                      key: 'addressLine1',
                      name: 'addressLine1',
                      type: 'addresslookup',
                      label: 'Address line 1',
                      placeholder: '',
                      required: true,
                      cssClass: 'coi-crux-form__address1',
                      layout: 'column',
                      validationMessages: {
                        required: 'Please enter the address',
                      },
                      expressions: {
                        change: (formState) => {
                          if (
                            formState.addressLine1.value &&
                            formState.addressLine1.status.toLowerCase() ===
                              'valid'
                          ) {
                            if (
                              formState.addressLine1.value.City &&
                              formState.addressLine1.value.StateProvince
                            ) {
                              this.coiFormControls
                                .find(
                                  (cityControl) => cityControl.key === 'city'
                                )
                                .formControl.patchValue(
                                  formState.addressLine1.value.City
                                );
                              this.coiFormControls
                                .find(
                                  (stateControl) => stateControl.key === 'state'
                                )
                                .formControl.patchValue(
                                  formState.addressLine1.value.StateProvince
                                );
                            }
                            if (formState.addressLine1.value.PostalCode) {
                              this.coiFormControls
                                .find(
                                  (stateControl) =>
                                    stateControl.key === 'zipcode'
                                )
                                .formControl.patchValue(
                                  formState.addressLine1.value.PostalCode
                                );
                            }
                          }
                        },
                      },

                      options: {
                        dataUrl:
                          'https://commercialservice-sit.chubb.com/api/lookupAddress?Data.AddressLine1=$searchTerm$',
                        addressParam: '$searchTerm$',
                        countryParam: '$country$',
                        country: 'USA',
                        postalCodeParam: '$postalCode$',
                        numberOfRowsParam: '$numRows$',
                        numberOfRows: '10',
                        appearance: 'legacy',
                        floatLabel: 'auto',
                      },
                    },
                    {
                      key: 'addressLine2',
                      name: 'addressLine2',
                      type: 'input',
                      label: 'Address line 2 (optional)',
                      required: false,
                      cssClass: 'coi-crux-form__address2',
                      layout: 'column',
                      options: {
                        floatLabel: 'auto',
                        maxlength: 60,
                        appearance: 'legacy',
                      },
                    },
                    {
                      key: 'city',
                      name: 'city',
                      type: 'input',
                      label: 'City',
                      required: true,
                      cssClass: 'coi-crux-form__city',
                      layout: 'column',
                      validationMessages: {
                        required: 'Please enter a city.',
                      },
                      options: {
                        floatLabel: 'auto',
                        maxlength: 60,
                        appearance: 'legacy',
                      },
                    },
                    {
                      key: 'state',
                      name: 'state',
                      type: 'dropdown',
                      label: 'State',
                      placeholder: 'Please Select',
                      required: true,
                      layout: 'column',
                      cssClass: 'coi-crux-form__state',
                      validationMessages: {
                        required: 'Please enter a state.',
                      },
                      options: {
                        floatLabel: 'auto',
                        maxlength: 60,
                        appearance: 'legacy',
                      },
                    },
                    {
                      key: 'zipcode',
                      name: 'zipcode',
                      type: 'input',
                      label: 'Zip code',
                      required: true,
                      layout: 'column',
                      cssClass: 'coi-crux-form__zipcode',
                      validationMessages: {
                        required: 'Please enter a zip code.',
                        maskValidator: 'Please enter a valid zip code',
                      },
                      options: {
                        floatLabel: 'auto',
                        maxlength: 60,
                        appearance: 'legacy',
                        hideRequiredMarker: true,
                        mask: 'zipCode',
                      },
                    },
                    {
                      key: 'horizontalLineTemplate',
                      name: 'horizontalLineTemplate',
                      type: 'template',
                    },
                    {
                      key: 'emailAddressContentTemplate',
                      name: 'emailAddressContentTemplate',
                      type: 'template',
                    },
                    {
                      key: 'emailAddress',
                      name: 'emailAddress',
                      type: 'input',
                      label: 'Their email address',
                      required: true,
                      layout: 'column',
                      cssClass: 'coi-crux-form__email-address',
                      validationMessages: {
                        required: 'Please enter a valid email address.',
                        email: 'Please enter a valid email address.',
                      },
                      options: {
                        type: 'email',
                        floatLabel: 'auto',
                        maxlength: 60,
                        appearance: 'legacy',
                      },
                    },
                    {
                      key: 'yourMessage',
                      name: 'yourMessage',
                      type: 'textarea',
                      label: 'Your message (optional)',
                      placeholder: '',
                      required: false,
                      layout: 'column',
                      cssClass: 'coi-crux-form__message',
                      options: {
                        floatLabel: 'auto',
                        maxlength: 60,
                        appearance: 'legacy',
                      },
                    },
                    {
                      key: 'phoneNumberContentTemplate',
                      name: 'phoneNumberContentTemplate',
                      type: 'template',
                      options: {
                        content:
                          'We might need to talk to you about your certificate, so please make sure your contact details are correct.',
                      },
                    },
                    {
                      key: 'horizontalLineTemplate',
                      name: 'horizontalLineTemplate',
                      type: 'template',
                    },
                    {
                      key: 'usersPhoneNumber',
                      name: 'usersPhoneNumber',
                      type: 'input',
                      label: 'Phone number',
                      placeholder: '',
                      required: true,
                      layout: 'column',
                      validationMessages: {
                        required: 'Please enter a valid phone number',
                        maskValidator: 'Please enter a valid phone number',
                      },
                      options: {
                        type: 'tel',
                        floatLabel: 'auto',
                        maxlength: 60,
                        appearance: 'legacy',
                        minlength: 10,
                        mask: 'phoneNumber',
                      },
                    },
                  ],
                },
              },
            },
          ],
        },
      ],
    },
    endorsements: {
      sections: [
        {
          key: 'endorsements-top',
          content: [
            {
              widget: {
                name: 'endorsementsWidget',
                context: {
                  mapping: {
                    'Workers Compensation Policy': {
                      'Waiver of Subrogation': {
                        header: 'Entity Details',
                        showSubmit: false,
                        controls: [
                          {
                            key: 'entityName',
                            name: 'entityName',
                            type: 'input',
                            label: 'Entity name',
                            layout: 'column',
                            required: true,
                            options: {
                              appearance: 'legacy',
                              type: 'text',
                            },
                          },
                          {
                            key: 'hasContract',
                            name: 'hasContract',
                            layout: 'column',
                            type: 'button-toggle',
                            defaultValue: false,
                            label:
                              'Do you already have a contract in place with them?',
                            options: {
                              items: [
                                {
                                  buttonText: 'Yes',
                                  name: 'yes',
                                  value: true,
                                },
                                {
                                  buttonText: 'No',
                                  name: 'no',
                                  value: false,
                                },
                              ],
                            },
                          },
                          {
                            key: 'entityAddress1',
                            name: 'entityAddress1',
                            type: 'input',
                            label: 'Entity address line 1',
                            layout: 'column',
                            required: true,
                            options: {
                              appearance: 'legacy',
                              type: 'text',
                            },
                          },
                          {
                            key: 'additionalContractDetails',
                            name: 'additionalContractDetails',
                            type: 'textarea',
                            label:
                              'Please provide additional details about the contract.',
                            layout: 'column',
                            required: true,
                            options: {
                              appearance: 'legacy',
                            },
                          },
                          {
                            key: 'entityAddress2',
                            name: 'entityAddress2',
                            type: 'input',
                            label: 'Entity address line 2',
                            layout: 'column',
                            required: true,
                            options: {
                              appearance: 'legacy',
                              type: 'text',
                            },
                          },
                          {
                            key: 'state',
                            name: 'state',
                            type: 'dropdown',
                            label: 'State',
                            placeholder: 'Please Select',
                            required: true,
                            layout: 'column',
                            validationMessages: {
                              required: 'Please enter a state.',
                            },
                            options: {
                              appearance: 'legacy',
                              displayProp: 'code',
                              valueProp: 'name',
                              items: [
                                {
                                  code: 'Alabama',
                                  name: 'AL',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Alaska',
                                  name: 'AK',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Arizona',
                                  name: 'AZ',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Arkansas',
                                  name: 'AR',
                                  type: 'STATE',
                                },
                                {
                                  code: 'California',
                                  name: 'CA',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Colorado',
                                  name: 'CO',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Connecticut',
                                  name: 'CT',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Delaware',
                                  name: 'DE',
                                  type: 'STATE',
                                },
                                {
                                  code: 'District of Columbia',
                                  name: 'DC',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Florida',
                                  name: 'FL',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Georgia',
                                  name: 'GA',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Hawaii',
                                  name: 'HI',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Idaho',
                                  name: 'ID',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Illinois',
                                  name: 'IL',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Indiana',
                                  name: 'IN',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Iowa',
                                  name: 'IA',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Kansas',
                                  name: 'KS',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Kentucky',
                                  name: 'KY',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Louisiana',
                                  name: 'LA',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Maine',
                                  name: 'ME',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Maryland',
                                  name: 'MD',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Massachusetts',
                                  name: 'MA',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Michigan',
                                  name: 'MI',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Minnesota',
                                  name: 'MN',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Mississippi',
                                  name: 'MS',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Missouri',
                                  name: 'MO',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Montana',
                                  name: 'MT',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Nebraska',
                                  name: 'NE',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Nevada',
                                  name: 'NV',
                                  type: 'STATE',
                                },
                                {
                                  code: 'New Hampshire',
                                  name: 'NH',
                                  type: 'STATE',
                                },
                                {
                                  code: 'New Jersey',
                                  name: 'NJ',
                                  type: 'STATE',
                                },
                                {
                                  code: 'New Mexico',
                                  name: 'NM',
                                  type: 'STATE',
                                },
                                {
                                  code: 'New York',
                                  name: 'NY',
                                  type: 'STATE',
                                },
                                {
                                  code: 'North Carolina',
                                  name: 'NC',
                                  type: 'STATE',
                                },
                                {
                                  code: 'North Dakota',
                                  name: 'ND',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Ohio',
                                  name: 'OH',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Oklahoma',
                                  name: 'OK',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Oregon',
                                  name: 'OR',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Pennsylvania',
                                  name: 'PA',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Rhode Island',
                                  name: 'RI',
                                  type: 'STATE',
                                },
                                {
                                  code: 'South Carolina',
                                  name: 'SC',
                                  type: 'STATE',
                                },
                                {
                                  code: 'South Dakota',
                                  name: 'SD',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Tennessee',
                                  name: 'TN',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Texas',
                                  name: 'TX',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Utah',
                                  name: 'UT',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Vermont',
                                  name: 'VT',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Virginia',
                                  name: 'VA',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Washington',
                                  name: 'WA',
                                  type: 'STATE',
                                },
                                {
                                  code: 'West Virginia',
                                  name: 'WV',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Wisconsin',
                                  name: 'WI',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Wyoming',
                                  name: 'WY',
                                  type: 'STATE',
                                },
                              ],
                            },
                          },
                          {
                            key: 'city',
                            name: 'city',
                            type: 'input',
                            label: 'City',
                            layout: 'column',
                            required: true,
                            options: {
                              appearance: 'legacy',
                              type: 'text',
                            },
                          },
                          {
                            key: 'zip',
                            name: 'zip',
                            type: 'input',
                            label: 'Zip Code',
                            layout: 'column',
                            required: true,
                            options: {
                              appearance: 'legacy',
                              type: 'text',
                            },
                          },
                          {
                            key: 'wantToUpdateCOI',
                            name: 'wantToUpdateCOI',
                            layout: 'column',
                            type: 'button-toggle',
                            defaultValue: false,
                            label:
                              'Do you want to update your Certificate of Insurance?',
                            options: {
                              items: [
                                {
                                  buttonText: 'Yes',
                                  name: 'yes',
                                  value: true,
                                },
                                {
                                  buttonText: 'No',
                                  name: 'no',
                                  value: false,
                                },
                              ],
                            },
                          },
                          {
                            key: 'businessDescription',
                            name: 'businessDescription',
                            type: 'textarea',
                            label: `Business description (this doesn't represent coverage) (optional)`,
                            options: {
                              appearance: 'legacy',
                            },
                            expressions: {
                              hide: (formState) => {
                                return (
                                  !formState.wantToUpdateCOI ||
                                  !formState.wantToUpdateCOI.value
                                );
                              },
                            },
                          },
                          {
                            key: 'businessEmailAddress',
                            name: 'businessEmailAddress',
                            type: 'input',
                            label: `When the new certificate's ready, who do you want us to send it to?`,
                            placeholder: `Their email address`,
                            required: true,
                            options: {
                              appearance: 'legacy',
                              type: 'text',
                            },
                            expressions: {
                              hide: (formState) => {
                                return (
                                  !formState.wantToUpdateCOI ||
                                  !formState.wantToUpdateCOI.value
                                );
                              },
                            },
                          },
                          {
                            key: 'businessMessage',
                            name: 'businessMessage',
                            type: 'textarea',
                            label: `Your message (optional)`,
                            options: {
                              appearance: 'legacy',
                            },
                            expressions: {
                              hide: (formState) => {
                                return (
                                  !formState.wantToUpdateCOI ||
                                  !formState.wantToUpdateCOI.value
                                );
                              },
                            },
                          },
                        ],
                      },
                      Other: {
                        showSubmit: false,
                        controls: [
                          {
                            key: 'textarea',
                            name: 'textarea',
                            type: 'textarea',
                            label: `Describe the change you'd like to request.`,
                            options: {
                              appearance: 'legacy',
                            },
                          },
                        ],
                      },
                    },
                    'Commercial General Liability Policy': {
                      'Add an additional insured': {
                        header: 'Additional insured details',
                        showSubmit: false,
                        controls: [
                          {
                            key: 'additionalInsuredType',
                            name: 'additionalInsuredType',
                            type: 'dropdown',
                            label: 'Type of additional insured',
                            placeholder: 'Please Select',
                            required: true,
                            layout: 'column',
                            validationMessages: {
                              required: 'Please select an answer.',
                            },
                            options: {
                              appearance: 'legacy',
                              displayProp: 'code',
                              valueProp: 'value',
                              items: [
                                {
                                  code: 'Mortgagee',
                                  value: 'Mortgagee',
                                  type: 'AIType',
                                },
                                {
                                  code: 'Landlord',
                                  value: 'Landlord',
                                  type: 'AIType',
                                },
                                {
                                  code: 'Loss Payee',
                                  value: 'Loss Payee',
                                  type: 'AIType',
                                },
                                {
                                  code: 'Other',
                                  value: 'Other',
                                  type: 'AIType',
                                },
                              ],
                            },
                          },
                          {
                            key: 'additionalInsuredName',
                            name: 'additionalInsuredName',
                            layout: 'column',
                            type: 'input',
                            required: true,
                            label: "Additional insured's name",
                            options: {
                              appearance: 'legacy',
                              type: 'text',
                            },
                          },
                          {
                            key: 'addressLine1',
                            name: 'addressLine1',
                            type: 'addresslookup',
                            label: 'Address line 1',
                            placeholder: '',
                            required: true,
                            cssClass: 'crux-form-builder__address1',
                            layout: 'column',
                            validationMessages: {
                              required: 'Please enter the address',
                            },
                            expressions: {},
                            options: {
                              dataUrl:
                                'https://commercialservice-sit.chubb.com/api/lookupAddress?Data.AddressLine1=$searchTerm$',
                              addressParam: '$searchTerm$',
                              countryParam: '$country$',
                              country: 'USA',
                              postalCodeParam: '$postalCode$',
                              numberOfRowsParam: '$numRows$',
                              numberOfRows: '10',
                              appearance: 'legacy',
                              floatLabel: 'auto',
                            },
                          },
                          {
                            key: 'addressLine2',
                            name: 'addressLine2',
                            type: 'input',
                            label: 'Address line 2 (optional)',
                            required: false,
                            cssClass: 'crux-form-builder__address2',
                            layout: 'column',
                            options: {
                              floatLabel: 'auto',
                              maxlength: 60,
                              appearance: 'legacy',
                            },
                          },
                          {
                            key: 'city',
                            name: 'city',
                            type: 'input',
                            label: 'City',
                            required: true,
                            cssClass: 'crux-form-builder__city',
                            layout: 'column',
                            validationMessages: {
                              required: 'Please enter a city.',
                            },
                            options: {
                              floatLabel: 'auto',
                              maxlength: 60,
                              appearance: 'legacy',
                            },
                          },
                          {
                            key: 'state',
                            name: 'state',
                            type: 'dropdown',
                            label: 'State',
                            placeholder: 'Please Select',
                            required: true,
                            layout: 'column',
                            cssClass: 'crux-form-builder__state',
                            validationMessages: {
                              required: 'Please enter a state.',
                            },
                            options: {
                              appearance: 'legacy',
                              displayProp: 'code',
                              valueProp: 'name',
                              items: [
                                {
                                  code: 'Alabama',
                                  name: 'AL',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Alaska',
                                  name: 'AK',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Arizona',
                                  name: 'AZ',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Arkansas',
                                  name: 'AR',
                                  type: 'STATE',
                                },
                                {
                                  code: 'California',
                                  name: 'CA',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Colorado',
                                  name: 'CO',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Connecticut',
                                  name: 'CT',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Delaware',
                                  name: 'DE',
                                  type: 'STATE',
                                },
                                {
                                  code: 'District of Columbia',
                                  name: 'DC',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Florida',
                                  name: 'FL',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Georgia',
                                  name: 'GA',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Hawaii',
                                  name: 'HI',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Idaho',
                                  name: 'ID',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Illinois',
                                  name: 'IL',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Indiana',
                                  name: 'IN',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Iowa',
                                  name: 'IA',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Kansas',
                                  name: 'KS',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Kentucky',
                                  name: 'KY',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Louisiana',
                                  name: 'LA',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Maine',
                                  name: 'ME',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Maryland',
                                  name: 'MD',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Massachusetts',
                                  name: 'MA',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Michigan',
                                  name: 'MI',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Minnesota',
                                  name: 'MN',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Mississippi',
                                  name: 'MS',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Missouri',
                                  name: 'MO',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Montana',
                                  name: 'MT',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Nebraska',
                                  name: 'NE',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Nevada',
                                  name: 'NV',
                                  type: 'STATE',
                                },
                                {
                                  code: 'New Hampshire',
                                  name: 'NH',
                                  type: 'STATE',
                                },
                                {
                                  code: 'New Jersey',
                                  name: 'NJ',
                                  type: 'STATE',
                                },
                                {
                                  code: 'New Mexico',
                                  name: 'NM',
                                  type: 'STATE',
                                },
                                {
                                  code: 'New York',
                                  name: 'NY',
                                  type: 'STATE',
                                },
                                {
                                  code: 'North Carolina',
                                  name: 'NC',
                                  type: 'STATE',
                                },
                                {
                                  code: 'North Dakota',
                                  name: 'ND',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Ohio',
                                  name: 'OH',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Oklahoma',
                                  name: 'OK',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Oregon',
                                  name: 'OR',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Pennsylvania',
                                  name: 'PA',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Rhode Island',
                                  name: 'RI',
                                  type: 'STATE',
                                },
                                {
                                  code: 'South Carolina',
                                  name: 'SC',
                                  type: 'STATE',
                                },
                                {
                                  code: 'South Dakota',
                                  name: 'SD',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Tennessee',
                                  name: 'TN',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Texas',
                                  name: 'TX',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Utah',
                                  name: 'UT',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Vermont',
                                  name: 'VT',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Virginia',
                                  name: 'VA',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Washington',
                                  name: 'WA',
                                  type: 'STATE',
                                },
                                {
                                  code: 'West Virginia',
                                  name: 'WV',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Wisconsin',
                                  name: 'WI',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Wyoming',
                                  name: 'WY',
                                  type: 'STATE',
                                },
                              ],
                            },
                          },
                          {
                            key: 'zipcode',
                            name: 'zipcode',
                            type: 'input',
                            label: 'Zip code',
                            required: true,
                            layout: 'column',
                            cssClass: 'crux-form-builder__zipcode',
                            validationMessages: {
                              required: 'Please enter a zip code.',
                              maskValidator: 'Please enter a valid zip code',
                            },
                            options: {
                              floatLabel: 'auto',
                              maxlength: 60,
                              appearance: 'legacy',
                              hideRequiredMarker: true,
                              mask: 'zipCode',
                            },
                          },
                          {
                            key: 'wantToUpdateCOI',
                            name: 'wantToUpdateCOI',
                            layout: 'column',
                            type: 'button-toggle',
                            defaultValue: false,
                            label:
                              'Do you want to update your Certificate of Insurance?',
                            options: {
                              items: [
                                {
                                  buttonText: 'Yes',
                                  name: 'yes',
                                  value: true,
                                },
                                {
                                  buttonText: 'No',
                                  name: 'no',
                                  value: false,
                                },
                              ],
                            },
                          },
                          {
                            key: 'businessDescription',
                            name: 'businessDescription',
                            type: 'textarea',
                            label: `Business description (this doesn't represent coverage) (optional)`,
                            options: {
                              appearance: 'legacy',
                            },
                            expressions: {
                              hide: (formState) => {
                                return (
                                  !formState.wantToUpdateCOI ||
                                  !formState.wantToUpdateCOI.value
                                );
                              },
                            },
                          },
                          {
                            key: 'businessEmailAddress',
                            name: 'businessEmailAddress',
                            type: 'input',
                            label: `When the new certificate's ready, who do you want us to send it to?`,
                            placeholder: `Their email address`,
                            required: true,
                            options: {
                              appearance: 'legacy',
                              type: 'text',
                            },
                            expressions: {
                              hide: (formState) => {
                                return (
                                  !formState.wantToUpdateCOI ||
                                  !formState.wantToUpdateCOI.value
                                );
                              },
                            },
                          },
                          {
                            key: 'businessMessage',
                            name: 'businessMessage',
                            type: 'textarea',
                            label: `Your message (optional)`,
                            options: {
                              appearance: 'legacy',
                            },
                            expressions: {
                              hide: (formState) => {
                                return (
                                  !formState.wantToUpdateCOI ||
                                  !formState.wantToUpdateCOI.value
                                );
                              },
                            },
                          },
                        ],
                      },
                      Other: {
                        showSubmit: false,
                        controls: [
                          {
                            key: 'textarea',
                            name: 'textarea',
                            type: 'textarea',
                            label: `Describe the change you'd like to request.`,
                          },
                        ],
                      },
                    },
                    'Miscellaneous Professional Liability Policy': {
                      'Add an additional insured': {
                        header: 'Additional insured details',
                        showSubmit: false,
                        controls: [
                          {
                            key: 'additionalInsuredType',
                            name: 'additionalInsuredType',
                            type: 'dropdown',
                            label: 'Type of additional insured',
                            placeholder: 'Please Select',
                            required: true,
                            layout: 'column',
                            validationMessages: {
                              required: 'Please select an answer.',
                            },
                            options: {
                              appearance: 'legacy',
                              displayProp: 'code',
                              valueProp: 'value',
                              items: [
                                {
                                  code: 'Vicarious Liability',
                                  value: 'Vicarious',
                                  type: 'AIType',
                                },
                                {
                                  code: 'Other',
                                  value: 'Other',
                                  type: 'AIType',
                                },
                              ],
                            },
                          },
                          {
                            key: 'additionalInsuredName',
                            name: 'additionalInsuredName',
                            layout: 'column',
                            type: 'input',
                            required: true,
                            label: "Additional insured's name",
                            options: {
                              appearance: 'legacy',
                              type: 'text',
                            },
                          },
                          {
                            key: 'addressLine1',
                            name: 'addressLine1',
                            type: 'addresslookup',
                            label: 'Address line 1',
                            placeholder: '',
                            required: true,
                            cssClass: 'crux-form-builder__address1',
                            layout: 'column',
                            validationMessages: {
                              required: 'Please enter the address',
                            },
                            expressions: {},
                            options: {
                              dataUrl:
                                'https://commercialservice-sit.chubb.com/api/lookupAddress?Data.AddressLine1=$searchTerm$',
                              addressParam: '$searchTerm$',
                              countryParam: '$country$',
                              country: 'USA',
                              postalCodeParam: '$postalCode$',
                              numberOfRowsParam: '$numRows$',
                              numberOfRows: '10',
                              appearance: 'legacy',
                              floatLabel: 'auto',
                            },
                          },
                          {
                            key: 'addressLine2',
                            name: 'addressLine2',
                            type: 'input',
                            label: 'Address line 2 (optional)',
                            required: false,
                            cssClass: 'crux-form-builder__address2',
                            layout: 'column',
                            options: {
                              floatLabel: 'auto',
                              maxlength: 60,
                              appearance: 'legacy',
                            },
                          },
                          {
                            key: 'city',
                            name: 'city',
                            type: 'input',
                            label: 'City',
                            required: true,
                            cssClass: 'crux-form-builder__city',
                            layout: 'column',
                            validationMessages: {
                              required: 'Please enter a city.',
                            },
                            options: {
                              floatLabel: 'auto',
                              maxlength: 60,
                              appearance: 'legacy',
                            },
                          },
                          {
                            key: 'state',
                            name: 'state',
                            type: 'dropdown',
                            label: 'State',
                            placeholder: 'Please Select',
                            required: true,
                            layout: 'column',
                            cssClass: 'crux-form-builder__state',
                            validationMessages: {
                              required: 'Please enter a state.',
                            },
                            options: {
                              appearance: 'legacy',
                              displayProp: 'code',
                              valueProp: 'name',
                              items: [
                                {
                                  code: 'Alabama',
                                  name: 'AL',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Alaska',
                                  name: 'AK',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Arizona',
                                  name: 'AZ',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Arkansas',
                                  name: 'AR',
                                  type: 'STATE',
                                },
                                {
                                  code: 'California',
                                  name: 'CA',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Colorado',
                                  name: 'CO',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Connecticut',
                                  name: 'CT',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Delaware',
                                  name: 'DE',
                                  type: 'STATE',
                                },
                                {
                                  code: 'District of Columbia',
                                  name: 'DC',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Florida',
                                  name: 'FL',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Georgia',
                                  name: 'GA',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Hawaii',
                                  name: 'HI',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Idaho',
                                  name: 'ID',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Illinois',
                                  name: 'IL',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Indiana',
                                  name: 'IN',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Iowa',
                                  name: 'IA',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Kansas',
                                  name: 'KS',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Kentucky',
                                  name: 'KY',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Louisiana',
                                  name: 'LA',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Maine',
                                  name: 'ME',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Maryland',
                                  name: 'MD',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Massachusetts',
                                  name: 'MA',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Michigan',
                                  name: 'MI',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Minnesota',
                                  name: 'MN',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Mississippi',
                                  name: 'MS',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Missouri',
                                  name: 'MO',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Montana',
                                  name: 'MT',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Nebraska',
                                  name: 'NE',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Nevada',
                                  name: 'NV',
                                  type: 'STATE',
                                },
                                {
                                  code: 'New Hampshire',
                                  name: 'NH',
                                  type: 'STATE',
                                },
                                {
                                  code: 'New Jersey',
                                  name: 'NJ',
                                  type: 'STATE',
                                },
                                {
                                  code: 'New Mexico',
                                  name: 'NM',
                                  type: 'STATE',
                                },
                                {
                                  code: 'New York',
                                  name: 'NY',
                                  type: 'STATE',
                                },
                                {
                                  code: 'North Carolina',
                                  name: 'NC',
                                  type: 'STATE',
                                },
                                {
                                  code: 'North Dakota',
                                  name: 'ND',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Ohio',
                                  name: 'OH',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Oklahoma',
                                  name: 'OK',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Oregon',
                                  name: 'OR',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Pennsylvania',
                                  name: 'PA',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Rhode Island',
                                  name: 'RI',
                                  type: 'STATE',
                                },
                                {
                                  code: 'South Carolina',
                                  name: 'SC',
                                  type: 'STATE',
                                },
                                {
                                  code: 'South Dakota',
                                  name: 'SD',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Tennessee',
                                  name: 'TN',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Texas',
                                  name: 'TX',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Utah',
                                  name: 'UT',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Vermont',
                                  name: 'VT',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Virginia',
                                  name: 'VA',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Washington',
                                  name: 'WA',
                                  type: 'STATE',
                                },
                                {
                                  code: 'West Virginia',
                                  name: 'WV',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Wisconsin',
                                  name: 'WI',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Wyoming',
                                  name: 'WY',
                                  type: 'STATE',
                                },
                              ],
                            },
                          },
                          {
                            key: 'zipcode',
                            name: 'zipcode',
                            type: 'input',
                            label: 'Zip code',
                            required: true,
                            layout: 'column',
                            cssClass: 'crux-form-builder__zipcode',
                            validationMessages: {
                              required: 'Please enter a zip code.',
                              maskValidator: 'Please enter a valid zip code',
                            },
                            options: {
                              floatLabel: 'auto',
                              maxlength: 60,
                              appearance: 'legacy',
                              hideRequiredMarker: true,
                              mask: 'zipCode',
                            },
                          },
                          {
                            key: 'wantToUpdateCOI',
                            name: 'wantToUpdateCOI',
                            layout: 'column',
                            type: 'button-toggle',
                            defaultValue: false,
                            label:
                              'Do you want to update your Certificate of Insurance?',
                            options: {
                              items: [
                                {
                                  buttonText: 'Yes',
                                  name: 'yes',
                                  value: true,
                                },
                                {
                                  buttonText: 'No',
                                  name: 'no',
                                  value: false,
                                },
                              ],
                            },
                          },
                          {
                            key: 'businessDescription',
                            name: 'businessDescription',
                            type: 'textarea',
                            label: `Business description (this doesn't represent coverage) (optional)`,
                            options: {
                              appearance: 'legacy',
                            },
                            expressions: {
                              hide: (formState) => {
                                return (
                                  !formState.wantToUpdateCOI ||
                                  !formState.wantToUpdateCOI.value
                                );
                              },
                            },
                          },
                          {
                            key: 'businessEmailAddress',
                            name: 'businessEmailAddress',
                            type: 'input',
                            label: `When the new certificate's ready, who do you want us to send it to?`,
                            placeholder: `Their email address`,
                            required: true,
                            options: {
                              appearance: 'legacy',
                              type: 'text',
                            },
                            expressions: {
                              hide: (formState) => {
                                return (
                                  !formState.wantToUpdateCOI ||
                                  !formState.wantToUpdateCOI.value
                                );
                              },
                            },
                          },
                          {
                            key: 'businessMessage',
                            name: 'businessMessage',
                            type: 'textarea',
                            label: `Your message (optional)`,
                            options: {
                              appearance: 'legacy',
                            },
                            expressions: {
                              hide: (formState) => {
                                return (
                                  !formState.wantToUpdateCOI ||
                                  !formState.wantToUpdateCOI.value
                                );
                              },
                            },
                          },
                        ],
                      },
                      Other: {
                        showSubmit: false,
                        controls: [
                          {
                            key: 'textarea',
                            name: 'textarea',
                            type: 'textarea',
                            label: `Describe the change you'd like to request.`,
                          },
                        ],
                      },
                    },
                    'Cyber ERM Policy': {
                      'Add an additional insured': {
                        header: 'Additional insured details',
                        showSubmit: false,
                        controls: [
                          {
                            key: 'additionalInsuredType',
                            name: 'additionalInsuredType',
                            type: 'dropdown',
                            label: 'Type of additional insured',
                            placeholder: 'Please Select',
                            required: true,
                            layout: 'column',
                            validationMessages: {
                              required: 'Please select an answer.',
                            },
                            options: {
                              appearance: 'legacy',
                              displayProp: 'code',
                              valueProp: 'value',
                              items: [
                                {
                                  code: 'Vicarious Liability',
                                  value: 'Vicarious',
                                  type: 'AIType',
                                },
                                {
                                  code: 'Other',
                                  value: 'Other',
                                  type: 'AIType',
                                },
                              ],
                            },
                          },
                          {
                            key: 'additionalInsuredName',
                            name: 'additionalInsuredName',
                            layout: 'column',
                            type: 'input',
                            required: true,
                            label: "Additional insured's name",
                            options: {
                              appearance: 'legacy',
                              type: 'text',
                            },
                          },
                          {
                            key: 'addressLine1',
                            name: 'addressLine1',
                            type: 'addresslookup',
                            label: 'Address line 1',
                            placeholder: '',
                            required: true,
                            cssClass: 'crux-form-builder__address1',
                            layout: 'column',
                            validationMessages: {
                              required: 'Please enter the address',
                            },
                            expressions: {},
                            options: {
                              dataUrl:
                                'https://commercialservice-sit.chubb.com/api/lookupAddress?Data.AddressLine1=$searchTerm$',
                              addressParam: '$searchTerm$',
                              countryParam: '$country$',
                              country: 'USA',
                              postalCodeParam: '$postalCode$',
                              numberOfRowsParam: '$numRows$',
                              numberOfRows: '10',
                              appearance: 'legacy',
                              floatLabel: 'auto',
                            },
                          },
                          {
                            key: 'addressLine2',
                            name: 'addressLine2',
                            type: 'input',
                            label: 'Address line 2 (optional)',
                            required: false,
                            cssClass: 'crux-form-builder__address2',
                            layout: 'column',
                            options: {
                              floatLabel: 'auto',
                              maxlength: 60,
                              appearance: 'legacy',
                            },
                          },
                          {
                            key: 'city',
                            name: 'city',
                            type: 'input',
                            label: 'City',
                            required: true,
                            cssClass: 'crux-form-builder__city',
                            layout: 'column',
                            validationMessages: {
                              required: 'Please enter a city.',
                            },
                            options: {
                              floatLabel: 'auto',
                              maxlength: 60,
                              appearance: 'legacy',
                            },
                          },
                          {
                            key: 'state',
                            name: 'state',
                            type: 'dropdown',
                            label: 'State',
                            placeholder: 'Please Select',
                            required: true,
                            layout: 'column',
                            cssClass: 'crux-form-builder__state',
                            validationMessages: {
                              required: 'Please enter a state.',
                            },
                            options: {
                              appearance: 'legacy',
                              displayProp: 'code',
                              valueProp: 'name',
                              items: [
                                {
                                  code: 'Alabama',
                                  name: 'AL',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Alaska',
                                  name: 'AK',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Arizona',
                                  name: 'AZ',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Arkansas',
                                  name: 'AR',
                                  type: 'STATE',
                                },
                                {
                                  code: 'California',
                                  name: 'CA',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Colorado',
                                  name: 'CO',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Connecticut',
                                  name: 'CT',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Delaware',
                                  name: 'DE',
                                  type: 'STATE',
                                },
                                {
                                  code: 'District of Columbia',
                                  name: 'DC',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Florida',
                                  name: 'FL',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Georgia',
                                  name: 'GA',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Hawaii',
                                  name: 'HI',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Idaho',
                                  name: 'ID',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Illinois',
                                  name: 'IL',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Indiana',
                                  name: 'IN',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Iowa',
                                  name: 'IA',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Kansas',
                                  name: 'KS',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Kentucky',
                                  name: 'KY',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Louisiana',
                                  name: 'LA',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Maine',
                                  name: 'ME',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Maryland',
                                  name: 'MD',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Massachusetts',
                                  name: 'MA',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Michigan',
                                  name: 'MI',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Minnesota',
                                  name: 'MN',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Mississippi',
                                  name: 'MS',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Missouri',
                                  name: 'MO',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Montana',
                                  name: 'MT',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Nebraska',
                                  name: 'NE',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Nevada',
                                  name: 'NV',
                                  type: 'STATE',
                                },
                                {
                                  code: 'New Hampshire',
                                  name: 'NH',
                                  type: 'STATE',
                                },
                                {
                                  code: 'New Jersey',
                                  name: 'NJ',
                                  type: 'STATE',
                                },
                                {
                                  code: 'New Mexico',
                                  name: 'NM',
                                  type: 'STATE',
                                },
                                {
                                  code: 'New York',
                                  name: 'NY',
                                  type: 'STATE',
                                },
                                {
                                  code: 'North Carolina',
                                  name: 'NC',
                                  type: 'STATE',
                                },
                                {
                                  code: 'North Dakota',
                                  name: 'ND',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Ohio',
                                  name: 'OH',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Oklahoma',
                                  name: 'OK',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Oregon',
                                  name: 'OR',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Pennsylvania',
                                  name: 'PA',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Rhode Island',
                                  name: 'RI',
                                  type: 'STATE',
                                },
                                {
                                  code: 'South Carolina',
                                  name: 'SC',
                                  type: 'STATE',
                                },
                                {
                                  code: 'South Dakota',
                                  name: 'SD',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Tennessee',
                                  name: 'TN',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Texas',
                                  name: 'TX',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Utah',
                                  name: 'UT',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Vermont',
                                  name: 'VT',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Virginia',
                                  name: 'VA',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Washington',
                                  name: 'WA',
                                  type: 'STATE',
                                },
                                {
                                  code: 'West Virginia',
                                  name: 'WV',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Wisconsin',
                                  name: 'WI',
                                  type: 'STATE',
                                },
                                {
                                  code: 'Wyoming',
                                  name: 'WY',
                                  type: 'STATE',
                                },
                              ],
                            },
                          },
                          {
                            key: 'zipcode',
                            name: 'zipcode',
                            type: 'input',
                            label: 'Zip code',
                            required: true,
                            layout: 'column',
                            cssClass: 'crux-form-builder__zipcode',
                            validationMessages: {
                              required: 'Please enter a zip code.',
                              maskValidator: 'Please enter a valid zip code',
                            },
                            options: {
                              floatLabel: 'auto',
                              maxlength: 60,
                              appearance: 'legacy',
                              hideRequiredMarker: true,
                              mask: 'zipCode',
                            },
                          },
                          {
                            key: 'wantToUpdateCOI',
                            name: 'wantToUpdateCOI',
                            layout: 'column',
                            type: 'button-toggle',
                            defaultValue: false,
                            label:
                              'Do you want to update your Certificate of Insurance?',
                            options: {
                              items: [
                                {
                                  buttonText: 'Yes',
                                  name: 'yes',
                                  value: true,
                                },
                                {
                                  buttonText: 'No',
                                  name: 'no',
                                  value: false,
                                },
                              ],
                            },
                          },
                          {
                            key: 'businessDescription',
                            name: 'businessDescription',
                            type: 'textarea',
                            label: `Business description (this doesn't represent coverage) (optional)`,
                            options: {
                              appearance: 'legacy',
                            },
                            expressions: {
                              hide: (formState) => {
                                return (
                                  !formState.wantToUpdateCOI ||
                                  !formState.wantToUpdateCOI.value
                                );
                              },
                            },
                          },
                          {
                            key: 'businessEmailAddress',
                            name: 'businessEmailAddress',
                            type: 'input',
                            label: `When the new certificate's ready, who do you want us to send it to?`,
                            placeholder: `Their email address`,
                            required: true,
                            options: {
                              appearance: 'legacy',
                              type: 'text',
                            },
                            expressions: {
                              hide: (formState) => {
                                return (
                                  !formState.wantToUpdateCOI ||
                                  !formState.wantToUpdateCOI.value
                                );
                              },
                            },
                          },
                          {
                            key: 'businessMessage',
                            name: 'businessMessage',
                            type: 'textarea',
                            label: `Your message (optional)`,
                            options: {
                              appearance: 'legacy',
                            },
                            expressions: {
                              hide: (formState) => {
                                return (
                                  !formState.wantToUpdateCOI ||
                                  !formState.wantToUpdateCOI.value
                                );
                              },
                            },
                          },
                        ],
                      },
                      Other: {
                        showSubmit: false,
                        controls: [
                          {
                            key: 'textarea',
                            name: 'textarea',
                            type: 'textarea',
                            label: `Describe the change you'd like to request.`,
                          },
                        ],
                      },
                    },
                  },
                },
              },
            },
          ],
        },
      ],
    },
  },
};
module.exports = STUDIOJS;
