# Studio UI Starter

[![Conventional Commits](https://img.shields.io/badge/Conventional%20Commits-1.0.0-yellow.svg)](https://conventionalcommits.org)


### Before starting development:

Follow project's [guidelines and conventions](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/blob/dev/CONTRIBUTING.md).


### URLs
DEV: https://latammicrohomeawaydevweb.latammicrowebdevase.p.azurewebsites.net

UAT: https://latammicrohomeawayuatweb.latammicrowebuatase.p.azurewebsites.net
