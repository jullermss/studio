# Change Log

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

<a name="0.0.1"></a>
## 0.0.1 (2019-08-12)



<a name="0.0.3-beta.3"></a>
## [0.0.3-beta.3](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/compare/v0.0.3-beta.2...v0.0.3-beta.3) (2019-08-11)


### Bug Fixes

* **#130:** fix to show errors only when Studio errors are thrown ([#227](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/227)) ([c48ae34](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/c48ae34))



<a name="0.0.3-beta.2"></a>
## [0.0.3-beta.2](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/compare/v0.0.3-beta.1...v0.0.3-beta.2) (2019-08-09)


### Bug Fixes

* **csr:** fix issue with policy search in CSR Dashboard ([903d1ab](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/903d1ab))


### Features

* **dbiz-3897:** Csr search policy API integration ([#223](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/223)) ([5bd981b](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/5bd981b))
* **policies:** add different appearances for policies page ([943ff99](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/943ff99))



<a name="0.0.3-beta.1"></a>
## [0.0.3-beta.1](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/compare/v0.0.3-beta.0...v0.0.3-beta.1) (2019-08-08)


### Bug Fixes

* **policies:** remove spinner from policies page, add loading indicator ([8d96975](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/8d96975))



<a name="0.0.3-beta.0"></a>
## [0.0.3-beta.0](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/compare/v0.0.2...v0.0.3-beta.0) (2019-08-08)


### Bug Fixes

* **#119:** Mimic endorsements form groups ([#141](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/141)) ([b84c8ff](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/b84c8ff)), closes [#119](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/119)


### Features

* **csr dashboard:** Policy Search in CSR Dashboard ([#107](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/107)) ([7f254c9](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/7f254c9))



<a name="0.0.2"></a>
## [0.0.2](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/compare/v0.0.1...v0.0.2) (2019-08-08)


### Bug Fixes

* **#115:** fix claim process ([a58c8c1](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/a58c8c1))
* **#209:** fix broken navigation links in dashboard ([2d1df47](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/2d1df47))
* **#209:** fix broken navigation links in dashboard ([#210](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/210)) ([95dbbc5](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/95dbbc5))
* **#26:** schema fix & small styling fixes ([49d2e4b](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/49d2e4b))
* **#39:** fix issue with material control styles ([#52](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/52)) ([ee12e5e](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/ee12e5e))
* **#91:** apierror message removed in verification ([#128](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/128)) ([8c4f406](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/8c4f406)), closes [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91)
* **#dev:** fix the syntax issue in studio ([9c4b148](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/9c4b148))
* **card:** fix card margin-bottom style ([d974618](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/d974618))
* **coi:** create coi form auto populate issue fix ([#211](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/211)) ([74249b9](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/74249b9))
* **config:** use angular path and not use base href ([321327a](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/321327a))
* **contribution:** fix contributing.md formatting ([8afe0a1](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/8afe0a1))
* **contribution:** fix contributing.md formatting ([ecaa10c](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/ecaa10c))
* **css:** fix responsiveness and ie compatibility for user profile page ([#124](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/124)) ([09866c7](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/09866c7))
* **css:** fix responsiveness and ie compatibility in policies page ([#122](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/122)) ([0b78f44](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/0b78f44))
* **css:** fix styling on policy widget ([#102](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/102)) ([7927f63](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/7927f63))
* **css:** fix styling on policy widget ([#104](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/104)) ([d50b6a9](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/d50b6a9))
* **dbiz-4022:** csr search box feature ([#103](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/103)) ([90744e2](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/90744e2))
* **endorsements:** fix endorsements page ([d8888ac](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/d8888ac))
* **Lint & Test:** fix lint and test scripts ([#47](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/47)) ([68b7776](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/68b7776))
* **policies widget:** fix naming for policies widget's naming ([6029004](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/6029004))
* **state:** fix initial state for user policies ([1b02ae5](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/1b02ae5))
* **state:** fix issue with ngRx state in AOT mode ([f3fa763](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/f3fa763))
* fix an issue with relative import of sections ([#78](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/78)) ([be8c73e](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/be8c73e))


### Features

* **#105:** add global error handling ([#106](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/106)) ([0dfabd4](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/0dfabd4)), closes [#105](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/105)
* **#108:** add app context configuration for footer ([#109](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/109)) ([9a9c90c](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/9a9c90c)), closes [#108](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/108)
* **#126:** added route gaurd to allow only applicable routes ([#127](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/127)) ([91d09d5](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/91d09d5)), closes [#126](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/126) [#126](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/126)
* **#29:** Policy Content screen rendered based on widgets configured in studio JSON ([#65](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/65)) ([d0ff827](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/d0ff827)), closes [#29](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/29)
* **#31:** Document Center Refactoring ([#82](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/82)) ([6b46864](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/6b46864)), closes [#31](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/31) [#31](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/31) [#31](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/31) [#31](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/31) [#31](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/31) [#31](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/31) [#31](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/31) [#31](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/31) [#31](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/31) [#31](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/31) [#31](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/31) [#31](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/31) [#31](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/31) [#31](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/31) [#31](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/31) [#31](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/31) [#31](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/31) [#31](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/31) [#31](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/31) [#31](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/31) [#31](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/31)
* **#33:** coi lazy loading with app context - refactor ([#64](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/64)) ([a3da25f](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/a3da25f)), closes [#33](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/33) [#33](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/33) [#33](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/33) [#33](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/33) [#33](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/33)
* **#40:** dynamic http header interceptor ([#55](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/55)) ([088ce67](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/088ce67)), closes [#40](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/40) [#40](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/40) [#40](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/40) [#40](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/40)
* **#69:** added Studio.js and refactored app context ([#80](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/80)) ([184203d](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/184203d)), closes [#69](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/69)
* **#72:** implement reactive patter for user contact details widget ([1d62873](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/1d62873)), closes [#72](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/72)
* **#85:** Replace usage of moment.js with date-fns ([#87](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/87)) ([3d6b11d](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/3d6b11d)), closes [#85](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/85)
* **#91:** Refactor Registration Component ([#118](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/118)) ([17fe5fe](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/17fe5fe)), closes [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91) [#91](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/91)
* **#97:** add toast (snackbar) ([#101](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/101)) ([27733c1](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/27733c1)), closes [#97](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/97)
* **72:** add reactive pattern to container components ([#89](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/89)) ([e17c094](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/e17c094))
* **app context:** add initial changes for app context in store ([de631fd](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/de631fd))
* **app context:** load app context in store ([9f6ee94](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/9f6ee94))
* **crux v3:** upgrade to CRUX v3 ([#81](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/81)) ([a543f42](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/a543f42))
* **DBIZ-3808:** CSR Dashboard Product Type and Policy Status filter ([#66](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/66)) ([a4b9fc0](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/a4b9fc0))
* **DBIZ-3809:** CSR Dashboard, table for search result ([#54](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/54)) ([476e9af](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/476e9af))
* **locale:** add locale pipes from CRUX ([8ff6cdf](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/8ff6cdf))
* **modules:** move modules as part of library ([#75](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/75)) ([1d7a43f](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/1d7a43f))
* **page not found:** update page not found component ([2d1b65e](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/2d1b65e))
* **title:** add title service & update page not found ([b200d04](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/b200d04))


### Performance Improvements

* **#112:** optimize scss imports ([#113](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/113)) ([4b274a0](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/commits/4b274a0)), closes [#112](https://nausp-aapp0001.aceins.com/Digital-Beatles/chubb-studio-servicing/issues/112)



<a name="0.0.1"></a>
## 0.0.1 (2019-06-11)


### Bug Fixes

* **environment:** Fix backend api URL ([60138c1](https://nausp-aapp0001.aceins.com/Digital-Beatles/ServicingPortal/commits/60138c1))
* **user profile:** Fix unable to update user from user profile page ([fe6b483](https://nausp-aapp0001.aceins.com/Digital-Beatles/ServicingPortal/commits/fe6b483))


### Features

* **#12:** Add section component ([ae57982](https://nausp-aapp0001.aceins.com/Digital-Beatles/ServicingPortal/commits/ae57982)), closes [#12](https://nausp-aapp0001.aceins.com/Digital-Beatles/ServicingPortal/issues/12)
* **#2:** Decompose DataService ([#37](https://nausp-aapp0001.aceins.com/Digital-Beatles/ServicingPortal/issues/37)) ([67c74ff](https://nausp-aapp0001.aceins.com/Digital-Beatles/ServicingPortal/commits/67c74ff)), closes [#2](https://nausp-aapp0001.aceins.com/Digital-Beatles/ServicingPortal/issues/2)
* **#30:** Add Content Header component ([#41](https://nausp-aapp0001.aceins.com/Digital-Beatles/ServicingPortal/issues/41)) ([f570480](https://nausp-aapp0001.aceins.com/Digital-Beatles/ServicingPortal/commits/f570480)), closes [#30](https://nausp-aapp0001.aceins.com/Digital-Beatles/ServicingPortal/issues/30)
* **AppContext:** Add AppContextService, studio.json and schema for it ([#27](https://nausp-aapp0001.aceins.com/Digital-Beatles/ServicingPortal/issues/27)) ([b2147d1](https://nausp-aapp0001.aceins.com/Digital-Beatles/ServicingPortal/commits/b2147d1))
* **authentication:** Improve authentication ([a1f6e88](https://nausp-aapp0001.aceins.com/Digital-Beatles/ServicingPortal/commits/a1f6e88))
* **card:** Add card component and navigation button component ([f997008](https://nausp-aapp0001.aceins.com/Digital-Beatles/ServicingPortal/commits/f997008))
* **card:** Add functionality to position icon on any side of card ([9504266](https://nausp-aapp0001.aceins.com/Digital-Beatles/ServicingPortal/commits/9504266))
* **dashboard:** add implementation for cards ([c71221d](https://nausp-aapp0001.aceins.com/Digital-Beatles/ServicingPortal/commits/c71221d))
* **dashboard:** Make use of card component for three main cards ([59b4b8f](https://nausp-aapp0001.aceins.com/Digital-Beatles/ServicingPortal/commits/59b4b8f))
* **document center:** Refactor document center ([432ce54](https://nausp-aapp0001.aceins.com/Digital-Beatles/ServicingPortal/commits/432ce54))
* **document center:** Refactor resource file ([405457d](https://nausp-aapp0001.aceins.com/Digital-Beatles/ServicingPortal/commits/405457d))
* **lazy loading:** Add dynamic loading for modules ([c056dc2](https://nausp-aapp0001.aceins.com/Digital-Beatles/ServicingPortal/commits/c056dc2))
* **Module Prefix:** Update Component & Directive prefix to use `studio` ([#43](https://nausp-aapp0001.aceins.com/Digital-Beatles/ServicingPortal/issues/43)) ([0019c07](https://nausp-aapp0001.aceins.com/Digital-Beatles/ServicingPortal/commits/0019c07))
* **refactor:** Refactor dashboard + user profile contracts ([abf8a63](https://nausp-aapp0001.aceins.com/Digital-Beatles/ServicingPortal/commits/abf8a63))
* **user:** Change user info storage method ([db1f8d9](https://nausp-aapp0001.aceins.com/Digital-Beatles/ServicingPortal/commits/db1f8d9))
* **user policies:** Add contract, refactor code using it ([05583bb](https://nausp-aapp0001.aceins.com/Digital-Beatles/ServicingPortal/commits/05583bb))


### Performance Improvements

* **Lazy loading:** Refactor code to perform lazy loading of modules ([f84ba1c](https://nausp-aapp0001.aceins.com/Digital-Beatles/ServicingPortal/commits/f84ba1c))
